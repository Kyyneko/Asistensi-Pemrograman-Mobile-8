package com.example.tp2_h071231059;

import android.os.Parcel;
import android.os.Parcelable;


public class User implements Parcelable {

    private String name, location, website, bannerUri, profileUri, birthday, bio;

    public User(String name, String bio, String birthday, String location, String website, String bannerUri, String profileUri) {
        this.name = name;
        this.bio = bio;
        this.birthday = birthday;
        this.location = location;
        this.website = website;
        this.bannerUri = bannerUri;
        this.profileUri = profileUri;
    }

    public String getName() {
        return name;
    }

    public String getBio() {
        return bio;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getLocation() {
        return location;
    }

    public String getWebsite() {
        return website;
    }

    public String getBannerUri() {
        return bannerUri;
    }

    public String getProfileUri() {
        return profileUri;
    }

    public void setName(String name) {
        this.name = name;
    }

    public  void setBio(String bio) {
        this.bio = bio;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public void setBannerUri(String bannerUri) {
        this.bannerUri = bannerUri;
    }

    public void setProfileUri(String profileUri) {
        this.profileUri = profileUri;
    }

    protected User(Parcel in) {
        name = in.readString();
        bio = in.readString();
        birthday = in.readString();
        location = in.readString();
        website = in.readString();
        bannerUri = in.readString();
        profileUri = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(bio);
        dest.writeString(birthday);
        dest.writeString(location);
        dest.writeString(website);
        dest.writeString(bannerUri);
        dest.writeString(profileUri);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };
}

