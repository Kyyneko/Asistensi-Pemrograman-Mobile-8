package com.example.tp2_h071231059;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EditProfile extends AppCompatActivity {

    private ImageView bannerImage, profileImage;
    private EditText et_name, et_bio, et_location, et_website, et_birthday;
    private ActivityResultLauncher<Intent> imagePickerLauncher;
    private Uri profileUri, bannerUri;
    private Button btnSave, btnRemoveDate;
    private boolean isBannerSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnSave = findViewById(R.id.btnSave);
        btnRemoveDate = findViewById(R.id.btnRemoveDate);
        bannerImage = findViewById(R.id.imgBanner);
        profileImage = findViewById(R.id.imgProfile);
        et_name = findViewById(R.id.et_name);
        et_bio = findViewById(R.id.et_bio);
        et_location = findViewById(R.id.et_location);
        et_website = findViewById(R.id.et_website);
        et_birthday = findViewById(R.id.et_birthday);

        et_birthday.setOnClickListener(v -> {
                    showDatePickerDialog();
                });

        if (et_birthday.getText().toString().trim().isEmpty()) {
            btnRemoveDate.setVisibility(View.GONE);
        } else {
            btnRemoveDate.setVisibility(View.VISIBLE);
        }

        btnRemoveDate.setOnClickListener(v -> {
            et_birthday.setText("");
            btnRemoveDate.setVisibility(View.GONE);
        });

        User user = getIntent().getParcelableExtra("USER_DATA");

        if (user != null) {
            et_name.setText(user.getName());
            et_bio.setText(user.getBio());
            et_location.setText(user.getLocation());
            et_website.setText(user.getWebsite());
            et_birthday.setText(user.getBirthday());

            if (user.getBannerUri() != null && !user.getBannerUri().isEmpty()) {
                bannerUri = Uri.parse(user.getBannerUri());
                bannerImage.setImageURI(bannerUri);
            }

            if (user.getProfileUri() != null && !user.getProfileUri().isEmpty()) {
                profileUri = Uri.parse(user.getProfileUri());
                profileImage.setImageURI(profileUri);
            }

            if (!et_birthday.getText().toString().trim().isEmpty() || et_birthday.equals("")) {
                btnRemoveDate.setVisibility(View.VISIBLE);
            }
        }

        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri imageUri = result.getData().getData();
                        if (imageUri != null) {
                            final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
                            getContentResolver().takePersistableUriPermission(imageUri, takeFlags);

                            if (isBannerSelected) {
                                bannerUri = imageUri;
                                bannerImage.setImageURI(bannerUri);
                            } else {
                                profileUri = imageUri;
                                profileImage.setImageURI(profileUri);
                            }
                        }
                    }
                });

        findViewById(R.id.btn_Banner).setOnClickListener(v -> {
            isBannerSelected = true;
            openGallery();
        });

        findViewById(R.id.btn_profile).setOnClickListener(v -> {
            isBannerSelected = false;
            openGallery();
        });

        ImageButton backButton = findViewById(R.id.backButton);

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(EditProfile.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        btnSave.setOnClickListener(v -> {
            String name = "";
            String bio = "";
            String location = "";
            String website = "";
            String birthday = "";
            String bannerUriString = "";
            String profileUriString = "";

            if (et_name.getText() != null && !et_name.getText().toString().trim().isEmpty()) {
                if (et_name.getText().length() <= 50) {
                    name = et_name.getText().toString();
                } else {
                    Toast.makeText(EditProfile.this, "Maks. Character is 50", Toast.LENGTH_SHORT).show();
                    return;
                }
            } else {
                Toast.makeText(EditProfile.this, "Name Cannot Be Blank", Toast.LENGTH_SHORT).show();
                return;
            }

            if (et_location.getText() != null) {
                if (et_location.getText().length() <= 30) {
                    location = et_location.getText().toString();
                } else {
                    Toast.makeText(EditProfile.this, "Maks. Character is 30", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            if (et_bio.getText() != null) {
                if (et_bio.getText().length() <= 160) {
                    bio = et_bio.getText().toString();
                } else {
                    Toast.makeText(EditProfile.this, "Maks. Character is 160", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            if (et_website.getText() != null) {
                website = et_website.getText().toString();
                if (!website.isEmpty() && !Patterns.WEB_URL.matcher(website).matches()) {
                    Toast.makeText(EditProfile.this, "Input valid URL", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            if (et_birthday.getText() != null) {
                birthday = et_birthday.getText().toString();
            }

            if (bannerUri != null) {
                bannerUriString = bannerUri.toString();
            }

            if (profileUri != null) {
                profileUriString = profileUri.toString();
            }

            User user1 = new User(name, bio, birthday, location, website, bannerUriString, profileUriString);
            Intent intent = new Intent(EditProfile.this, MainActivity.class);
            intent.putExtra("USER_DATA", user1);
            setResult(Activity.RESULT_OK, intent);
            finish();
        });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        imagePickerLauncher.launch(Intent.createChooser(intent, "Pilih Gambar"));
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    calendar.set(selectedYear, selectedMonth, selectedDay);

                    SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault());
                    String formattedDate = sdf.format(calendar.getTime());

                    et_birthday.setText(formattedDate);
                    btnRemoveDate.setVisibility(View.VISIBLE);
                },
                year, month, day
        );

        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis() - 1000);

        datePickerDialog.show();
    }

}