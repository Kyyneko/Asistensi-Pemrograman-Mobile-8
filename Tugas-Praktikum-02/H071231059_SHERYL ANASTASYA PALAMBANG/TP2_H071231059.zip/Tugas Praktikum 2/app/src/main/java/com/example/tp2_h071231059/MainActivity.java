package com.example.tp2_h071231059;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.util.Log;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ImageView imgBanner, imgProfile, tweetImgProfile1, tweetImgProfile2, tweetImgProfile3, tweetImgProfile4;
    private TextView tvName, tvBio, tvLocation, tvWebsite, tvBirthday, tweetTvName1, tweetTvName2, tweetTvName3, tweetTvName4;
    private View tweetLayout1, tweetLayout2, tweetLayout3, tweetLayout4;
    private static final int REQUEST_EDIT_PROFILE = 1;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button editProfilButton = findViewById(R.id.editProfilButton);
        imgBanner = findViewById(R.id.imgBanner);
        imgProfile = findViewById(R.id.imgProfile);
        tvName = findViewById(R.id.tvName);
        tvBio = findViewById(R.id.tvBio);
        tvLocation = findViewById(R.id.tvLocation);
        tvWebsite = findViewById(R.id.tvWebsite);
        tvBirthday = findViewById(R.id.tvBirthday);

        tweetLayout1 = findViewById(R.id.tweetLayout1);
        tweetImgProfile1 = tweetLayout1.findViewById(R.id.imgProfile);
        tweetTvName1 = tweetLayout1.findViewById(R.id.tvName);

        tweetLayout2 = findViewById(R.id.tweetLayout2);
        tweetImgProfile2 = tweetLayout2.findViewById(R.id.imgProfile);
        tweetTvName2 = tweetLayout2.findViewById(R.id.tvName);

        tweetLayout3 = findViewById(R.id.tweetLayout3);
        tweetImgProfile3 = tweetLayout3.findViewById(R.id.imgProfile);
        tweetTvName3 = tweetLayout3.findViewById(R.id.tvName);

        tweetLayout4 = findViewById(R.id.tweetLayout4);
        tweetImgProfile4 = tweetLayout4.findViewById(R.id.imgProfile);
        tweetTvName4 = tweetLayout4.findViewById(R.id.tvName);

        user = new User(
                "さぶまちすいせい",
                "見たな。フォローしてなかったら、今夜なにかがくる…",
                "",
                "",
                "",
                "",
                ""
        );

        updateUI();

        editProfilButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditProfile.class);
            intent.putExtra("USER_DATA", user);
            startActivityForResult(intent, REQUEST_EDIT_PROFILE);
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_EDIT_PROFILE && resultCode == RESULT_OK && data != null) {
            User updatedUser = data.getParcelableExtra("USER_DATA");

            if (updatedUser != null) {
                if (updatedUser.getBannerUri() == null || updatedUser.getBannerUri().isEmpty()) {
                    updatedUser.setBannerUri(user.getBannerUri());
                }

                if (updatedUser.getProfileUri() == null || updatedUser.getProfileUri().isEmpty()) {
                    updatedUser.setProfileUri(user.getProfileUri());
                }
                user = updatedUser;
            }

            updateUI();
        }
    }

    private void updateUI() {

        if (user != null) {
            /// Get the included layout view
            View profileHeaderView = findViewById(R.id.profileHeaderSection);

            // Get the inner constraint layout
            ConstraintLayout constraintLayout = profileHeaderView.findViewById(R.id.profileInnerSection);

            // Make sure we're getting views from the inner constraint layout
            TextView tvLocation = constraintLayout.findViewById(R.id.tvLocation);
            TextView tvWebsite = constraintLayout.findViewById(R.id.tvWebsite);
            TextView tvBirthday = constraintLayout.findViewById(R.id.tvBirthday);
//            TextView tvJoinedDate = constraintLayout.findViewById(R.id.tvJoinedDate);
//            TextView followingCount = constraintLayout.findViewById(R.id.followingCount);

            ImageView birthdayIcon = constraintLayout.findViewById(R.id.birthdayIcon);
//            ImageView calenderIcon = constraintLayout.findViewById(R.id.calenderIcon);
            ImageView locationIcon = constraintLayout.findViewById(R.id.locationIcon);
            ImageView websiteIcon = constraintLayout.findViewById(R.id.websiteIcon);

            String location = formatDisplay(user.getLocation());
            String website = formatDisplay(user.getWebsite());
            String birthday = user.getBirthday();

            tvLocation.setText(location);
            tvWebsite.setText(website);
            tvBirthday.setText(birthday);
            tvBio.setText(user.getBio());

            if (!location.isEmpty() && website.isEmpty() && birthday.isEmpty()) {
                tvLocation.setText(user.getLocation());

                locationIcon.setVisibility(View.VISIBLE);
                tvLocation.setVisibility(View.VISIBLE);

                birthdayIcon.setVisibility(View.GONE);
                tvBirthday.setVisibility(View.GONE);
                websiteIcon.setVisibility(View.GONE);
                tvWebsite.setVisibility(View.GONE);

                // Setup constraints
                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);

                // Clear existing constraints
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.START);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.START);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.TOP);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.followingCount, ConstraintSet.TOP);

                // Set new constraints
                constraintSet.connect(R.id.calenderIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.calenderIcon, ConstraintSet.TOP, R.id.locationIcon, ConstraintSet.BOTTOM, 30);

                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.START, R.id.calenderIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.BOTTOM, R.id.calenderIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.followingCount, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.followingCount, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.BOTTOM, 35);

                // Apply constraints
                constraintSet.applyTo(constraintLayout);
            } else if (location.isEmpty() && !website.isEmpty() && birthday.isEmpty()) {
                if (user.getWebsite().length() <= 40) {
                    tvWebsite.setText(user.getWebsite());
                }

                websiteIcon.setVisibility(View.VISIBLE);
                tvWebsite.setVisibility(View.VISIBLE);

                birthdayIcon.setVisibility(View.GONE);
                tvBirthday.setVisibility(View.GONE);
                locationIcon.setVisibility(View.GONE);
                tvLocation.setVisibility(View.GONE);

                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);

                constraintSet.clear(R.id.websiteIcon, ConstraintSet.START);
                constraintSet.clear(R.id.websiteIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.websiteIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.calenderIcon, ConstraintSet.START);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.START);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.TOP);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.followingCount, ConstraintSet.TOP);

                constraintSet.connect(R.id.websiteIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.websiteIcon, ConstraintSet.TOP, R.id.translateBio, ConstraintSet.BOTTOM, 35);

                constraintSet.connect(R.id.tvWebsite, ConstraintSet.START, R.id.websiteIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvWebsite, ConstraintSet.TOP, R.id.websiteIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvWebsite, ConstraintSet.BOTTOM, R.id.websiteIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.calenderIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.calenderIcon, ConstraintSet.TOP, R.id.websiteIcon, ConstraintSet.BOTTOM, 30);

                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.START, R.id.calenderIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.BOTTOM, R.id.calenderIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.followingCount, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.followingCount, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.BOTTOM, 35);

                constraintSet.applyTo(constraintLayout);

            } else if (location.isEmpty() && website.isEmpty() && !birthday.isEmpty()) {
                birthdayIcon.setVisibility(View.VISIBLE);
                tvBirthday.setVisibility(View.VISIBLE);

                websiteIcon.setVisibility(View.GONE);
                tvWebsite.setVisibility(View.GONE);
                locationIcon.setVisibility(View.GONE);
                tvLocation.setVisibility(View.GONE);

                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);

                constraintSet.clear(R.id.birthdayIcon, ConstraintSet.START);
                constraintSet.clear(R.id.birthdayIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.birthdayIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.calenderIcon, ConstraintSet.START);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.START);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.TOP);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.followingCount, ConstraintSet.TOP);

                constraintSet.connect(R.id.birthdayIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.birthdayIcon, ConstraintSet.TOP, R.id.translateBio, ConstraintSet.BOTTOM, 35);

                constraintSet.connect(R.id.tvBirthday, ConstraintSet.START, R.id.birthdayIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvBirthday, ConstraintSet.TOP, R.id.birthdayIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvBirthday, ConstraintSet.BOTTOM, R.id.birthdayIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.calenderIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.calenderIcon, ConstraintSet.TOP, R.id.birthdayIcon, ConstraintSet.BOTTOM, 30);

                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.START, R.id.calenderIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.BOTTOM, R.id.calenderIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.followingCount, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.followingCount, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.BOTTOM, 35);

                constraintSet.applyTo(constraintLayout);

            } else if (!location.isEmpty() && !website.isEmpty() && birthday.isEmpty()) {
                tvLocation.setText(user.getLocation());

                if (user.getWebsite().length() <= 40) {
                    tvWebsite.setText(user.getWebsite());
                }

                locationIcon.setVisibility(View.VISIBLE);
                tvLocation.setVisibility(View.VISIBLE);
                websiteIcon.setVisibility(View.VISIBLE);
                tvWebsite.setVisibility(View.VISIBLE);

                birthdayIcon.setVisibility(View.GONE);
                tvBirthday.setVisibility(View.GONE);

                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);

                constraintSet.clear(R.id.websiteIcon, ConstraintSet.START);
                constraintSet.clear(R.id.websiteIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.websiteIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.calenderIcon, ConstraintSet.START);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.START);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.TOP);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.followingCount, ConstraintSet.TOP);

                constraintSet.connect(R.id.websiteIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.websiteIcon, ConstraintSet.TOP, R.id.locationIcon, ConstraintSet.BOTTOM, 30);

                constraintSet.connect(R.id.tvWebsite, ConstraintSet.START, R.id.websiteIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvWebsite, ConstraintSet.TOP, R.id.websiteIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvWebsite, ConstraintSet.BOTTOM, R.id.websiteIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.calenderIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.calenderIcon, ConstraintSet.TOP, R.id.websiteIcon, ConstraintSet.BOTTOM, 30);

                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.START, R.id.calenderIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.BOTTOM, R.id.calenderIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.followingCount, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.followingCount, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.BOTTOM, 35);

                constraintSet.applyTo(constraintLayout);

            } else if (!location.isEmpty() && website.isEmpty() && !birthday.isEmpty()) {
                tvLocation.setText(user.getLocation());

                locationIcon.setVisibility(View.VISIBLE);
                tvLocation.setVisibility(View.VISIBLE);
                birthdayIcon.setVisibility(View.VISIBLE);
                tvBirthday.setVisibility(View.VISIBLE);

                websiteIcon.setVisibility(View.GONE);
                tvWebsite.setVisibility(View.GONE);

                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);

                constraintSet.clear(R.id.calenderIcon, ConstraintSet.START);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.START);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.TOP);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.followingCount, ConstraintSet.TOP);

                constraintSet.connect(R.id.websiteIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.websiteIcon, ConstraintSet.TOP, R.id.locationIcon, ConstraintSet.BOTTOM, 30);

                constraintSet.connect(R.id.tvWebsite, ConstraintSet.START, R.id.websiteIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvWebsite, ConstraintSet.TOP, R.id.websiteIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvWebsite, ConstraintSet.BOTTOM, R.id.websiteIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.calenderIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.calenderIcon, ConstraintSet.TOP, R.id.birthdayIcon, ConstraintSet.BOTTOM, 30);

                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.START, R.id.calenderIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.BOTTOM, R.id.calenderIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.followingCount, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.followingCount, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.BOTTOM, 35);

                constraintSet.applyTo(constraintLayout);

            } else if (location.isEmpty() && !website.isEmpty() && !birthday.isEmpty()) {
                if (user.getWebsite().length() <= 40) {
                    tvWebsite.setText(user.getWebsite());
                }

                birthdayIcon.setVisibility(View.VISIBLE);
                tvBirthday.setVisibility(View.VISIBLE);
                websiteIcon.setVisibility(View.VISIBLE);
                tvWebsite.setVisibility(View.VISIBLE);

                locationIcon.setVisibility(View.GONE);
                tvLocation.setVisibility(View.GONE);

                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);

                constraintSet.clear(R.id.websiteIcon, ConstraintSet.START);
                constraintSet.clear(R.id.websiteIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.websiteIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.birthdayIcon, ConstraintSet.START);
                constraintSet.clear(R.id.birthdayIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.birthdayIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.calenderIcon, ConstraintSet.START);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.START);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.TOP);
                constraintSet.clear(R.id.tvJoinedDate, ConstraintSet.BOTTOM);

                constraintSet.clear(R.id.followingCount, ConstraintSet.TOP);

                constraintSet.connect(R.id.websiteIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.websiteIcon, ConstraintSet.TOP, R.id.translateBio, ConstraintSet.BOTTOM, 35);

                constraintSet.connect(R.id.tvWebsite, ConstraintSet.START, R.id.websiteIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvWebsite, ConstraintSet.TOP, R.id.websiteIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvWebsite, ConstraintSet.BOTTOM, R.id.websiteIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.birthdayIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.birthdayIcon, ConstraintSet.TOP, R.id.websiteIcon, ConstraintSet.BOTTOM, 30);

                constraintSet.connect(R.id.tvBirthday, ConstraintSet.START, R.id.birthdayIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvBirthday, ConstraintSet.TOP, R.id.birthdayIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvBirthday, ConstraintSet.BOTTOM, R.id.birthdayIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.calenderIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.calenderIcon, ConstraintSet.TOP, R.id.birthdayIcon, ConstraintSet.BOTTOM, 30);

                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.START, R.id.calenderIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.BOTTOM, R.id.calenderIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.followingCount, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.followingCount, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.BOTTOM, 35);

                constraintSet.applyTo(constraintLayout);
            } else if (!location.isEmpty() && !website.isEmpty() && !birthday.isEmpty()) {
                if (user.getLocation().length() >= 15 ) {
                    tvLocation.setText(user.getLocation());

                    birthdayIcon.setVisibility(View.VISIBLE);
                    tvBirthday.setVisibility(View.VISIBLE);
                    websiteIcon.setVisibility(View.VISIBLE);
                    tvWebsite.setVisibility(View.VISIBLE);
                    locationIcon.setVisibility(View.VISIBLE);
                    tvLocation.setVisibility(View.VISIBLE);

                    ConstraintSet constraintSet = new ConstraintSet();
                    constraintSet.clone(constraintLayout);

                    constraintSet.clear(R.id.calenderIcon, ConstraintSet.START);
                    constraintSet.clear(R.id.calenderIcon, ConstraintSet.TOP);
                    constraintSet.clear(R.id.calenderIcon, ConstraintSet.BOTTOM);

                    constraintSet.clear(R.id.websiteIcon, ConstraintSet.START);
                    constraintSet.clear(R.id.websiteIcon, ConstraintSet.TOP);
                    constraintSet.clear(R.id.websiteIcon, ConstraintSet.BOTTOM);

                    constraintSet.clear(R.id.birthdayIcon, ConstraintSet.START);
                    constraintSet.clear(R.id.birthdayIcon, ConstraintSet.TOP);
                    constraintSet.clear(R.id.birthdayIcon, ConstraintSet.BOTTOM);

                    constraintSet.connect(R.id.websiteIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                    constraintSet.connect(R.id.websiteIcon, ConstraintSet.TOP, R.id.locationIcon, ConstraintSet.BOTTOM, 30);
                    constraintSet.connect(R.id.tvWebsite, ConstraintSet.START, R.id.websiteIcon, ConstraintSet.END, 4);
                    constraintSet.connect(R.id.tvWebsite, ConstraintSet.TOP, R.id.websiteIcon, ConstraintSet.TOP, 0);
                    constraintSet.connect(R.id.tvWebsite, ConstraintSet.BOTTOM, R.id.websiteIcon, ConstraintSet.BOTTOM, 0);

                    constraintSet.connect(R.id.birthdayIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                    constraintSet.connect(R.id.birthdayIcon, ConstraintSet.TOP, R.id.websiteIcon, ConstraintSet.BOTTOM, 30);
                    constraintSet.connect(R.id.tvBirthday, ConstraintSet.START, R.id.birthdayIcon, ConstraintSet.END, 4);
                    constraintSet.connect(R.id.tvBirthday, ConstraintSet.TOP, R.id.birthdayIcon, ConstraintSet.TOP, 0);
                    constraintSet.connect(R.id.tvBirthday, ConstraintSet.BOTTOM, R.id.birthdayIcon, ConstraintSet.BOTTOM, 0);

                    constraintSet.connect(R.id.calenderIcon, ConstraintSet.START, R.id.tvBirthday, ConstraintSet.END, 20);
                    constraintSet.connect(R.id.calenderIcon, ConstraintSet.BOTTOM, R.id.tvBirthday, ConstraintSet.BOTTOM, 0);
                    constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.START, R.id.calenderIcon, ConstraintSet.END, 4);
                    constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.TOP, 0);
                    constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.BOTTOM, R.id.calenderIcon, ConstraintSet.BOTTOM, 0);

                    constraintSet.connect(R.id.followingCount, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                    constraintSet.connect(R.id.followingCount, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.BOTTOM, 35);

                    constraintSet.applyTo(constraintLayout);
                } else {
                    tvLocation.setText(location);
                    if (user.getWebsite().length() <= 20) {
                        tvWebsite.setText(user.getWebsite());
                    } else  {
                        tvWebsite.setText(user.getWebsite().substring(0, 20) + "...");
                    }


                    birthdayIcon.setVisibility(View.VISIBLE);
                    tvBirthday.setVisibility(View.VISIBLE);
                    websiteIcon.setVisibility(View.VISIBLE);
                    tvWebsite.setVisibility(View.VISIBLE);
                    locationIcon.setVisibility(View.VISIBLE);
                    tvLocation.setVisibility(View.VISIBLE);

                    ConstraintSet constraintSet = new ConstraintSet();
                    constraintSet.clone(constraintLayout);

                    constraintSet.clear(R.id.websiteIcon, ConstraintSet.START);
                    constraintSet.clear(R.id.websiteIcon, ConstraintSet.TOP);
                    constraintSet.clear(R.id.websiteIcon, ConstraintSet.BOTTOM);

                    constraintSet.clear(R.id.birthdayIcon, ConstraintSet.START);
                    constraintSet.clear(R.id.birthdayIcon, ConstraintSet.TOP);
                    constraintSet.clear(R.id.birthdayIcon, ConstraintSet.BOTTOM);

                    constraintSet.clear(R.id.calenderIcon, ConstraintSet.START);
                    constraintSet.clear(R.id.calenderIcon, ConstraintSet.TOP);
                    constraintSet.clear(R.id.calenderIcon, ConstraintSet.BOTTOM);

                    constraintSet.connect(R.id.websiteIcon, ConstraintSet.START, R.id.tvLocation, ConstraintSet.END, 10);
                    constraintSet.connect(R.id.websiteIcon, ConstraintSet.BOTTOM, R.id.locationIcon, ConstraintSet.BOTTOM, 0);

                    constraintSet.connect(R.id.birthdayIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                    constraintSet.connect(R.id.birthdayIcon, ConstraintSet.TOP, R.id.tvLocation, ConstraintSet.BOTTOM, 30);

                    constraintSet.connect(R.id.calenderIcon, ConstraintSet.START, R.id.tvBirthday, ConstraintSet.END, 10);
                    constraintSet.connect(R.id.calenderIcon, ConstraintSet.BOTTOM, R.id.tvBirthday, ConstraintSet.BOTTOM, 0);
                    constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.START, R.id.calenderIcon, ConstraintSet.END, 4);
                    constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.TOP, 0);
                    constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.BOTTOM, R.id.calenderIcon, ConstraintSet.BOTTOM, 0);

                    constraintSet.connect(R.id.followingCount, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                    constraintSet.connect(R.id.followingCount, ConstraintSet.TOP, R.id.birthdayIcon, ConstraintSet.BOTTOM, 35);

                    constraintSet.applyTo(constraintLayout);
                }

            } else {
                birthdayIcon.setVisibility(View.GONE);
                tvBirthday.setVisibility(View.GONE);
                websiteIcon.setVisibility(View.GONE);
                tvWebsite.setVisibility(View.GONE);
                locationIcon.setVisibility(View.GONE);
                tvLocation.setVisibility(View.GONE);

                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);

                constraintSet.clear(R.id.calenderIcon, ConstraintSet.START);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.TOP);
                constraintSet.clear(R.id.calenderIcon, ConstraintSet.BOTTOM);

                constraintSet.connect(R.id.calenderIcon, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.calenderIcon, ConstraintSet.TOP, R.id.translateBio, ConstraintSet.BOTTOM, 35);

                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.START, R.id.calenderIcon, ConstraintSet.END, 4);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.tvJoinedDate, ConstraintSet.BOTTOM, R.id.calenderIcon, ConstraintSet.BOTTOM, 0);

                constraintSet.connect(R.id.followingCount, ConstraintSet.START, R.id.translateBio, ConstraintSet.START, 0);
                constraintSet.connect(R.id.followingCount, ConstraintSet.TOP, R.id.calenderIcon, ConstraintSet.BOTTOM, 35);

                constraintSet.applyTo(constraintLayout);
            }

            tvWebsite.setPaintFlags(tvWebsite.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            tvWebsite.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(user.getWebsite()));
                v.getContext().startActivity(intent);
            });

            tvName.setText(user.getName());
            tweetTvName1.setText(nameFormatDisplay(user.getName()));
            tweetTvName2.setText(nameFormatDisplay(user.getName()));
            tweetTvName3.setText(nameFormatDisplay(user.getName()));
            tweetTvName4.setText(nameFormatDisplay(user.getName()));

            try {
                if (user.getBannerUri() != null && !user.getBannerUri().isEmpty()) {
                    Uri bannerUri = Uri.parse(user.getBannerUri());
                    imgBanner.setImageURI(null);
                    imgBanner.setImageURI(bannerUri);

                    if (imgBanner.getDrawable() == null) {
                        imgBanner.setImageResource(R.drawable.img_suibanner);
                    }
                }

                if (user.getProfileUri() != null && !user.getProfileUri().isEmpty()) {
                    Uri profileUri = Uri.parse(user.getProfileUri());

                    imgProfile.setImageURI(null);
                    imgProfile.setImageURI(profileUri);

                    tweetImgProfile1.setImageURI(null);
                    tweetImgProfile2.setImageURI(null);
                    tweetImgProfile3.setImageURI(null);
                    tweetImgProfile4.setImageURI(null);

                    tweetImgProfile1.setImageURI(profileUri);
                    tweetImgProfile2.setImageURI(profileUri);
                    tweetImgProfile3.setImageURI(profileUri);
                    tweetImgProfile4.setImageURI(profileUri);

                    if (imgProfile.getDrawable() == null) {
                        imgProfile.setImageResource(R.drawable.img_suiprofile);
                        tweetImgProfile1.setImageResource(R.drawable.img_suiprofile);
                        tweetImgProfile2.setImageResource(R.drawable.img_suiprofile);
                        tweetImgProfile3.setImageResource(R.drawable.img_suiprofile);
                        tweetImgProfile4.setImageResource(R.drawable.img_suiprofile);
                    }
                }
            } catch (Exception e) {
                Log.e("MainActivity", "Error loading images: " + e.getMessage());
                // Fallback ke gambar default jika terjadi error
                imgBanner.setImageResource(R.drawable.img_suibanner);
                imgProfile.setImageResource(R.drawable.img_suiprofile);
                tweetImgProfile1.setImageResource(R.drawable.img_suiprofile);
                tweetImgProfile2.setImageResource(R.drawable.img_suiprofile);
                tweetImgProfile3.setImageResource(R.drawable.img_suiprofile);
                tweetImgProfile4.setImageResource(R.drawable.img_suiprofile);
            }
        }
    }

    private Spannable nameFormatDisplay(String name) {
        int nameLen = name.length();
        String username = "@submati_suisei";
        String displayText;

        if ( name.equals("さぶまちすいせい")) {
            displayText = name + " " + "@subm...";
        } else if (nameLen < 11) {
            displayText = name + " " + username;
        } else if (nameLen < 23) {
            int dotsCount = nameLen - 8;
            dotsCount = Math.min(dotsCount, username.length() - 1);

            int keepLen = username.length() - dotsCount;
            String newUsername = username.substring(0, keepLen) + "...";

            displayText = name + " " + newUsername;
        } else {
            displayText = name.substring(0, 25) + "...";
        }

        SpannableString spannable = new SpannableString(displayText);
        spannable.setSpan(new StyleSpan(Typeface.BOLD), 0, Math.min(nameLen, displayText.length()), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        if (displayText.contains("@")) {
            int startIndex = displayText.indexOf("@");
            int endIndex = displayText.length();

            spannable.setSpan(new ForegroundColorSpan(Color.parseColor("#71767b")), startIndex, endIndex, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return spannable;
    }

    private String formatDisplay(String text) {
        if (text == null) return "";

        int textLen = text.length();

        if (textLen <= 15) {
            return text;
        } else if (textLen == 30) {
            return text;
        } else if (textLen > 15 && textLen < 30) {
            int endIndex = Math.min(15, textLen);
            return text.substring(0, endIndex) + "...";
        } else if (textLen > 40) {
            return text.substring(0, 36) + "...";
//            return text.substring(0, 20) + "...";
        } else {
            return text;
        }
    }
}
