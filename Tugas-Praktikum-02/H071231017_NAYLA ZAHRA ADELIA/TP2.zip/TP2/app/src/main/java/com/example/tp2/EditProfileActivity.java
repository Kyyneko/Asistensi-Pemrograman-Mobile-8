package com.example.tp2;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;


public class EditProfileActivity extends AppCompatActivity {

    private ImageView profileImage;
    private EditText editName, editUsername;
    private Button saveButton;
    private Uri selectedImageUri = null;

    ActivityResultLauncher<Intent> pickImageLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    selectedImageUri = result.getData().getData();
                    if (selectedImageUri != null) {
                        profileImage.setImageURI(selectedImageUri);
                    }
                }
            });

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        profileImage = findViewById(R.id.profilImage);
        editName = findViewById(R.id.edit_name);
        editUsername = findViewById(R.id.edit_usn);
        saveButton = findViewById(R.id.button_save);

        Intent intent = getIntent();
        if (intent != null) {
            String imageUriStr = intent.getStringExtra("IMAGE_URI");
            if (imageUriStr != null && !imageUriStr.isEmpty()) {
                try {
                    Uri imageUri = Uri.parse(imageUriStr);
                    profileImage.setImageURI(imageUri);
                    selectedImageUri = imageUri;
                } catch (Exception e) {
                    profileImage.setImageResource(R.drawable.img);
                }
            } else {
                profileImage.setImageResource(R.drawable.img);
            }

            editName.setText(intent.getStringExtra("NAME")); // dari main activity
            editUsername.setText(intent.getStringExtra("USERNAME"));
        }

        profileImage.setOnClickListener(v -> {
            Intent intent1 = new Intent(Intent.ACTION_GET_CONTENT);
            intent1.setType("image/*");
            pickImageLauncher.launch(intent1);
        });

        saveButton.setOnClickListener(v -> {
            String name = editName.getText().toString();
            String username = editUsername.getText().toString();

            Intent resultIntent = new Intent();

            if (!name.isEmpty()) resultIntent.putExtra("NAME", name);
            if (!username.isEmpty()) resultIntent.putExtra("USERNAME", username);
            if (selectedImageUri != null)
                resultIntent.putExtra("IMAGE_URI", selectedImageUri.toString());

            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}
