package com.example.tp2;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Uri currentImageUri;
    private String currentName, currentUsername;

    ActivityResultLauncher<Intent> editProfileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        if (data.hasExtra("NAME")) {
                            currentName = data.getStringExtra("NAME");
                            TextView profileName = findViewById(R.id.tv_name);
                            profileName.setText(currentName);
                        }

                        if (data.hasExtra("USERNAME")) {
                            currentUsername = data.getStringExtra("USERNAME");
                            TextView usernameView = findViewById(R.id.tv_usn);
                            usernameView.setText(currentUsername);
                        }

                        if (data.hasExtra("IMAGE_URI")) {
                            String imageUriStr = data.getStringExtra("IMAGE_URI");
                            if (imageUriStr != null && !imageUriStr.isEmpty()) {
                                currentImageUri = Uri.parse(imageUriStr);
                                ImageView profileImage = findViewById(R.id.profilImage);
                                profileImage.setImageURI(currentImageUri);
                            }
                        }

                        saveUserData(); // menyimpan sekaligus
                    }
                }
            });

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageEdit = findViewById(R.id.editProfil);
        imageEdit.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
            if (currentImageUri != null) {
                intent.putExtra("IMAGE_URI", currentImageUri.toString());
            }
            intent.putExtra("NAME", currentName != null ? currentName : "");
            intent.putExtra("USERNAME", currentUsername != null ? currentUsername : "");
            editProfileLauncher.launch(intent);
        });


    }

    private void loadUserData() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE);

        currentName = sharedPreferences.getString("NAME", "");
        currentUsername = sharedPreferences.getString("USERNAME", "");
        String imageUriString = sharedPreferences.getString("IMAGE_URI", "");

        TextView profileName = findViewById(R.id.tv_name);
        TextView usernameView = findViewById(R.id.tv_usn);
        ImageView profileImage = findViewById(R.id.profilImage);

        profileName.setText(currentName.isEmpty() ? "Nama kosong" : currentName);
        usernameView.setText(currentUsername.isEmpty() ? "Username kosong" : currentUsername);

        if (imageUriString != null && !imageUriString.isEmpty()) {
            try {
                currentImageUri = Uri.parse(imageUriString);
                profileImage.setImageURI(currentImageUri);
            } catch (Exception e) {
                profileImage.setImageResource(R.drawable.img);
            }
        } else {
            profileImage.setImageResource(R.drawable.img);
        }
    }

    private void saveUserData() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("NAME", currentName != null ? currentName : "");
        editor.putString("USERNAME", currentUsername != null ? currentUsername : "");
        editor.putString("IMAGE_URI", currentImageUri != null ? currentImageUri.toString() : "");

        editor.apply();
    }
}