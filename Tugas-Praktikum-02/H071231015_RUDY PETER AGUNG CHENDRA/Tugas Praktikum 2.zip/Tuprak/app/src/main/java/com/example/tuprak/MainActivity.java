package com.example.tuprak;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final String[] REQUIRED_PERMISSIONS = 
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ?
        new String[]{Manifest.permission.READ_MEDIA_IMAGES} :
        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    
    private TextView profileNameText;
    private TextView usernameText;
    private TextView bioText1;
    private TextView bioText2;
    private TextView bioText3;
    private TextView websiteText;
    private Button messageButton;
    private ImageView profilePic;
    private Uri profileImageUri;
    
    private String userGender = "Laki-laki";
    private String userKataGanti = "";
    private ProfilePreferencesManager preferencesManager;

    private final ActivityResultLauncher<Intent> editProfileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {

                    Intent data = result.getData();
                    String name = data.getStringExtra("name");
                    String username = data.getStringExtra("username");
                    String bio = data.getStringExtra("bio");
                    String links = data.getStringExtra("links");
                    
                    userGender = data.getStringExtra("gender");
                    userKataGanti = data.getStringExtra("kataganti");
                                        
                    preferencesManager.saveGender(userGender);
                    preferencesManager.saveKataGanti(userKataGanti);
                    
                    if (data.hasExtra("profileImageUri")) {
                        String imageUriString = data.getStringExtra("profileImageUri");
                        if (imageUriString != null && !imageUriString.isEmpty()) {
                            Uri receivedUri = Uri.parse(imageUriString);
                            try {
                                profileImageUri = createPersistentUri(receivedUri);
                                profilePic.setImageURI(profileImageUri);
                                preferencesManager.saveProfileImageUri(profileImageUri);
                            } catch (SecurityException e) {
                                Log.e(TAG, "Permission denied accessing image URI: " + receivedUri, e);
                                Toast.makeText(this, "Permission denied to access image", Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                Log.e(TAG, "Error loading image from URI: " + receivedUri, e);
                            }
                        }
                    }
                    
                    if (name != null && !name.isEmpty()) {
                        profileNameText.setText(name);
                        preferencesManager.saveProfileName(name);
                    }
                    
                    if (username != null && !username.isEmpty()) {
                        usernameText.setText(username);
                        preferencesManager.saveUsername(username);
                    }
                    
                    if (bio != null) {
                        String[] bioLines = bio.split("\n");
                        
                        bioText1.setText("");
                        bioText2.setText("");
                        bioText3.setText("");
                        
                        if (bioLines.length > 0) {
                            bioText1.setText(bioLines[0]);
                            preferencesManager.saveBioLine1(bioLines[0]);
                            
                            if (bioLines.length > 1) {
                                bioText2.setText(bioLines[1]);
                                preferencesManager.saveBioLine2(bioLines[1]);
                                
                                if (bioLines.length > 2) {
                                    bioText3.setText(bioLines[2]);
                                    preferencesManager.saveBioLine3(bioLines[2]);
                                } else {
                                    preferencesManager.saveBioLine3("");
                                }
                            } else {
                                preferencesManager.saveBioLine2("");
                                preferencesManager.saveBioLine3("");
                            }
                        } else {
                            preferencesManager.saveBioLine1("");
                            preferencesManager.saveBioLine2("");
                            preferencesManager.saveBioLine3("");
                        }
                    }
                    
                    if (links != null && !links.isEmpty()) {
                        websiteText.setText(links);
                        preferencesManager.saveWebsite(links);
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        profileNameText = findViewById(R.id.profileNameText);
        usernameText = findViewById(R.id.usernameText);
        bioText1 = findViewById(R.id.bioText1);
        bioText2 = findViewById(R.id.bioText2);
        bioText3 = findViewById(R.id.bioText3);
        websiteText = findViewById(R.id.websiteText);
        profilePic = findViewById(R.id.profilePic);
        
        preferencesManager = new ProfilePreferencesManager(this);
        
        checkAndRequestPermissions();
        
        loadProfileData();
        
        messageButton = findViewById(R.id.messageButton);
        
        messageButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
            intent.putExtra("name", profileNameText.getText().toString());
            intent.putExtra("username", usernameText.getText().toString());
            
            StringBuilder bioBuilder = new StringBuilder();
            if (bioText1 != null) bioBuilder.append(bioText1.getText());
            bioBuilder.append("\n");
            if (bioText2 != null) bioBuilder.append(bioText2.getText());
            bioBuilder.append("\n");
            if (bioText3 != null) bioBuilder.append(bioText3.getText());
            
            intent.putExtra("bio", bioBuilder.toString());
            intent.putExtra("links", websiteText.getText().toString());
            intent.putExtra("gender", userGender);
            intent.putExtra("kataganti", userKataGanti);
            
            Log.d(TAG, "Sending gender to EditProfileActivity: " + userGender);
            if (profileImageUri != null) {
                intent.putExtra("profileImageUri", profileImageUri.toString());
            }
            
            editProfileLauncher.launch(intent);
        });
    }
    
    
    private Uri createPersistentUri(Uri sourceUri) {
        try {
            File outputDir = new File(getFilesDir(), "profile_images");
            if (!outputDir.exists()) {
                outputDir.mkdirs();
            }
            
            String fileName = "profile_image_" + System.currentTimeMillis() + ".jpg";
            File outputFile = new File(outputDir, fileName);
            
            try (InputStream inputStream = getContentResolver().openInputStream(sourceUri);
                 OutputStream outputStream = new FileOutputStream(outputFile)) {
                
                if (inputStream == null) {
                    throw new IOException("Failed to open input stream");
                }
                
                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }
                outputStream.flush();
                
                return FileProvider.getUriForFile(
                    this,
                    getApplicationContext().getPackageName() + ".fileprovider",
                    outputFile
                );
            }
        } catch (IOException e) {
            Log.e(TAG, "Failed to create persistent URI", e);
            
            try {
                Bitmap bitmap = BitmapFactory.decodeStream(
                    getContentResolver().openInputStream(sourceUri));
                
                File outputDir = new File(getFilesDir(), "profile_images");
                if (!outputDir.exists()) {
                    outputDir.mkdirs();
                }
                
                String fileName = "profile_image_" + System.currentTimeMillis() + ".jpg";
                File outputFile = new File(outputDir, fileName);
                
                FileOutputStream fos = new FileOutputStream(outputFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
                fos.flush();
                fos.close();
                
                return FileProvider.getUriForFile(
                    this,
                    getApplicationContext().getPackageName() + ".fileprovider",
                    outputFile
                );
            } catch (Exception e2) {
                Log.e(TAG, "Failed backup attempt to create persistent URI", e2);
                return null;
            }
        }
    }
    
    private boolean checkAndRequestPermissions() {
        boolean allGranted = true;
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
            }
        }
        
        if (!allGranted) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, PERMISSION_REQUEST_CODE);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                loadProfileData();
            } else {
                Toast.makeText(this, "Storage permissions are required to load profile image", 
                              Toast.LENGTH_LONG).show();
            }
        }
    }
    
    private void loadProfileData() {
        String savedName = preferencesManager.getProfileName("");
        if (!savedName.isEmpty()) {
            profileNameText.setText(savedName);
        }
        
        String savedUsername = preferencesManager.getUsername("");
        if (!savedUsername.isEmpty()) {
            usernameText.setText(savedUsername);
        }
        
        bioText1.setText(preferencesManager.getBioLine1(""));
        bioText2.setText(preferencesManager.getBioLine2(""));
        bioText3.setText(preferencesManager.getBioLine3(""));
        
        String savedWebsite = preferencesManager.getWebsite("");
        if (!savedWebsite.isEmpty()) {
            websiteText.setText(savedWebsite);
        }
        
        userGender = preferencesManager.getGender("Laki-laki");
        userKataGanti = preferencesManager.getKataGanti("");
        
        profileImageUri = preferencesManager.getProfileImageUri();
        if (profileImageUri != null) {
            try {
                profilePic.setImageURI(profileImageUri);
            } catch (SecurityException e) {
                Log.e(TAG, "Permission denied accessing image URI: " + profileImageUri, e);
                profilePic.setImageResource(R.drawable.lab_logo);
            } catch (Exception e) {
                Log.e(TAG, "Error loading image from URI: " + profileImageUri, e);
                profilePic.setImageResource(R.drawable.lab_logo);
            }
        }
    }
}