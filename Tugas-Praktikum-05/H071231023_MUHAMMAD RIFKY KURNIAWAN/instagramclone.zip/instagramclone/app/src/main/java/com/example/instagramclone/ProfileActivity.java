package com.example.instagramclone;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagramclone.adapter.HighlightAdapter;
import com.example.instagramclone.adapter.FeedAdapter;
import com.example.instagramclone.model.FeedPost;
import com.example.instagramclone.model.StoryHighlight;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class ProfileActivity extends AppCompatActivity {

    private ImageView profileImage, backButton;
    private TextView username, postsCount, followersCount, followingCount;
    private RecyclerView highlightsRecyclerView, profileFeedRecyclerView;
    private List<StoryHighlight> highlightList;
    private List<FeedPost> profileFeedList;
    private FloatingActionButton addPostButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize views
        profileImage = findViewById(R.id.profileImage);
        username = findViewById(R.id.username);
        postsCount = findViewById(R.id.postsCount);
        followersCount = findViewById(R.id.followersCount);
        followingCount = findViewById(R.id.followingCount);
        highlightsRecyclerView = findViewById(R.id.highlightsRecyclerView);
        profileFeedRecyclerView = findViewById(R.id.profileFeedRecyclerView);
        backButton = findViewById(R.id.backButton);
        addPostButton = findViewById(R.id.addPostButton);

        // Get intent data
        String usernameText = getIntent().getStringExtra("username");
        int profilePic = getIntent().getIntExtra("profilePic", R.drawable.profile_1);

        // Set profile data
        username.setText(usernameText);
        profileImage.setImageResource(profilePic);
        postsCount.setText("5\nPosts");
        followersCount.setText("1,250\nFollowers");
        followingCount.setText("350\nFollowing");

        // Set up highlights RecyclerView
        highlightsRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        initHighlightsData();
        HighlightAdapter highlightAdapter = new HighlightAdapter(highlightList, this);
        highlightsRecyclerView.setAdapter(highlightAdapter);

        // Set up profile feed RecyclerView
        profileFeedRecyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        initProfileFeedData();
        FeedAdapter feedAdapter = new FeedAdapter(profileFeedList, this, true);
        profileFeedRecyclerView.setAdapter(feedAdapter);

        // Set click listeners
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        addPostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, PostActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Update profile feed in case new posts were added
        refreshProfileFeed();
    }

    private void initHighlightsData() {
        highlightList = new ArrayList<>();
        highlightList.add(new StoryHighlight(R.drawable.highlight_1, "Travel", "My trip to Paris last summer"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_2, "Food", "Favorite restaurants in town"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_3, "Pets", "My dog Max being cute"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_4, "Nature", "Beautiful landscapes from hikes"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_5, "Friends", "Good times with friends"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_6, "Fashion", "My style inspiration"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_7, "Art", "Museum visits and art projects"));
    }

    private void initProfileFeedData() {
        profileFeedList = new ArrayList<>();
        profileFeedList.add(new FeedPost(R.drawable.profile_1, "myUsername", R.drawable.profile_post_1, "My first post", 85));
        profileFeedList.add(new FeedPost(R.drawable.profile_1, "myUsername", R.drawable.profile_post_2, "Weekend vibes", 120));
        profileFeedList.add(new FeedPost(R.drawable.profile_1, "myUsername", R.drawable.profile_post_3, "Birthday celebration", 145));
        profileFeedList.add(new FeedPost(R.drawable.profile_1, "myUsername", R.drawable.profile_post_4, "Nature walk", 67));
        profileFeedList.add(new FeedPost(R.drawable.profile_1, "myUsername", R.drawable.profile_post_5, "Coffee time", 92));

        // Add any new posts from DataManager
        profileFeedList.addAll(DataManager.getInstance().getNewPosts());
    }

    private void refreshProfileFeed() {
        if (DataManager.getInstance().getNewPosts().size() > 0) {
            // Update posts count
            postsCount.setText(profileFeedList.size() + DataManager.getInstance().getNewPosts().size() + "\nPosts");

            // Reinitialize feed data to include new posts
            initProfileFeedData();

            // Update adapter
            FeedAdapter adapter = new FeedAdapter(profileFeedList, this, true);
            profileFeedRecyclerView.setAdapter(adapter);
        }
    }
}
