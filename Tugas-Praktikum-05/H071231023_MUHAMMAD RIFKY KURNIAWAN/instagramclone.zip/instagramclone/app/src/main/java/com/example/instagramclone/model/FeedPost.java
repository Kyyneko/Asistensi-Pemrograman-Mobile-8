package com.example.instagramclone.model;

public class FeedPost {
    private int userProfilePic;
    private String username;
    private int postImage;
    private String caption;
    private int likes;
    private boolean isLiked;

    public FeedPost(int userProfilePic, String username, int postImage, String caption, int likes) {
        this.userProfilePic = userProfilePic;
        this.username = username;
        this.postImage = postImage;
        this.caption = caption;
        this.likes = likes;
        this.isLiked = false;
    }

    public int getUserProfilePic() {
        return userProfilePic;
    }

    public String getUsername() {
        return username;
    }

    public int getPostImage() {
        return postImage;
    }

    public String getCaption() {
        return caption;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public boolean isLiked() {
        return isLiked;
    }

    public void setLiked(boolean liked) {
        isLiked = liked;
    }
}
