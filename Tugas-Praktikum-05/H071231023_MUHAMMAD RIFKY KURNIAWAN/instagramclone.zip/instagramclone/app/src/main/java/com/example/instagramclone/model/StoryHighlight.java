package com.example.instagramclone.model;

public class StoryHighlight {
    private int imageResource;
    private String title;
    private String content;

    public StoryHighlight(int imageResource, String title, String content) {
        this.imageResource = imageResource;
        this.title = title;
        this.content = content;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }
}