package com.example.instagramclone;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class StoryDetailActivity extends AppCompatActivity {

    private ImageView storyImage, closeButton;
    private TextView storyTitle, storyContent;
    private ProgressBar progressBar;
    private final long STORY_DURATION = 5000; // 5 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_detail);

        // Initialize views
        storyImage = findViewById(R.id.storyImage);
        storyTitle = findViewById(R.id.storyTitle);
        storyContent = findViewById(R.id.storyContent);
        closeButton = findViewById(R.id.closeButton);
        progressBar = findViewById(R.id.progressBar);

        // Get intent data
        String title = getIntent().getStringExtra("title");
        int image = getIntent().getIntExtra("image", R.drawable.highlight_1);
        String content = getIntent().getStringExtra("content");

        // Set data to views
        storyTitle.setText(title);
        storyImage.setImageResource(image);
        storyContent.setText(content);

        // Set click listener for close button
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Start progress and auto-close
        startProgress();
    }

    private void startProgress() {
        progressBar.setMax(100);
        progressBar.setProgress(0);

        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                finish();
            }
        };

        // Start progress animation
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                int progress = 0;
                while (progress <= 100) {
                    final int currentProgress = progress;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setProgress(currentProgress);
                        }
                    });
                    try {
                        Thread.sleep(STORY_DURATION / 100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    progress++;
                }
            }
        });
        thread.start();

        // Schedule auto-close
        handler.postDelayed(runnable, STORY_DURATION);
    }
}