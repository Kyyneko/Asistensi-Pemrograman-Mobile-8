package com.example.instagramclone;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagramclone.adapter.FeedAdapter;
import com.example.instagramclone.adapter.HighlightAdapter;
import com.example.instagramclone.model.FeedPost;
import com.example.instagramclone.model.StoryHighlight;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView feedRecyclerView, highlightsRecyclerView;
    private FeedAdapter feedAdapter;
    private HighlightAdapter highlightAdapter;
    private List<FeedPost> feedList;
    private List<StoryHighlight> highlightList;
    private ImageView profileButton;
    private FloatingActionButton addPostButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi view
        feedRecyclerView = findViewById(R.id.feedRecyclerView);
        highlightsRecyclerView = findViewById(R.id.highlightsRecyclerView);
        profileButton = findViewById(R.id.profileButton);
        addPostButton = findViewById(R.id.addPostButton);

        // Setup Feed RecyclerView
        feedRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        initFeedData();
        feedAdapter = new FeedAdapter(feedList, this, false);
        feedRecyclerView.setAdapter(feedAdapter);

        // Setup Highlights RecyclerView (horizontal)
        highlightsRecyclerView.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        initHighlightData();
        highlightAdapter = new HighlightAdapter(highlightList, this);
        highlightsRecyclerView.setAdapter(highlightAdapter);

        // Navigasi ke Profile
        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("username", "myUsername");
            intent.putExtra("profilePic", R.drawable.profile_1);
            startActivity(intent);
        });

        // Navigasi ke Post
        addPostButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PostActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshFeedData();
    }

    private void initFeedData() {
        feedList = new ArrayList<>();
        feedList.add(new FeedPost(R.drawable.profile_1, "user_one",        R.drawable.post_1, "Enjoying my weekend! #fun",            120));
        feedList.add(new FeedPost(R.drawable.profile_2, "travel_lover",    R.drawable.post_2, "Beautiful sunset at the beach",        234));
        feedList.add(new FeedPost(R.drawable.profile_3, "food_explorer",   R.drawable.post_3, "Delicious dinner with friends #foodie", 87));
        feedList.add(new FeedPost(R.drawable.profile_4, "photo_enthusiast",R.drawable.post_4, "Nature is amazing! #photography",       156));
        feedList.add(new FeedPost(R.drawable.profile_5, "fitness_guru",    R.drawable.post_5, "Morning workout done! #fitness #health",98));
        feedList.add(new FeedPost(R.drawable.profile_6, "art_lover",       R.drawable.post_6, "My latest painting #art #creativity",   211));
        feedList.add(new FeedPost(R.drawable.profile_7, "tech_geek",       R.drawable.post_7, "New gadget unboxing! #technology",      75));
        feedList.add(new FeedPost(R.drawable.profile_8, "bookworm",        R.drawable.post_8, "Current read. What are you reading? #books",63));
        feedList.add(new FeedPost(R.drawable.profile_9, "pet_lover",       R.drawable.post_9, "My cute dog! #pets #dogs",              189));
        feedList.add(new FeedPost(R.drawable.profile_10,"urban_explorer",  R.drawable.post_10,"City vibes #urban #city",               102));
    }

    private void refreshFeedData() {
        if (DataManager.getInstance().getNewPosts().size() > 0) {
            feedList.addAll(0, DataManager.getInstance().getNewPosts());
            feedAdapter.updateData(feedList);
        }
    }

    private void initHighlightData() {
        highlightList = new ArrayList<>();
        highlightList.add(new StoryHighlight(R.drawable.highlight_1, "Beach", "Chillin' at the beach 🌊"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_2, "Foodie", "Best burger in town 🍔"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_3, "Workout", "Leg day complete 🏋️"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_4, "Art", "My sketchbook today ✍️"));
        highlightList.add(new StoryHighlight(R.drawable.highlight_5, "Pet", "My cat is a mood 🐱"));
    }
}
