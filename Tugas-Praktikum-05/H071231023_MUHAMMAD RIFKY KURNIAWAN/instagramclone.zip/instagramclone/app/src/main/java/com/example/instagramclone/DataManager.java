package com.example.instagramclone;

import com.example.instagramclone.model.FeedPost;

import java.util.ArrayList;
import java.util.List;

public class DataManager {
    private static DataManager instance;
    private List<FeedPost> newPosts;

    private DataManager() {
        newPosts = new ArrayList<>();
    }

    public static synchronized DataManager getInstance() {
        if (instance == null) {
            instance = new DataManager();
        }
        return instance;
    }

    public void addNewPost(FeedPost post) {
        newPosts.add(0, post);  // Add to beginning of list
    }

    public List<FeedPost> getNewPosts() {
        return newPosts;
    }
}