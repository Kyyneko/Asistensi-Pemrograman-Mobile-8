package com.example.instagramclone;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailFeedActivity extends AppCompatActivity {

    private ImageView backButton, profilePicture, postImage, likeButton;
    private TextView username, caption, likeCount;
    private boolean isLiked = false;
    private int likes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_feed);

        // Initialize views
        backButton = findViewById(R.id.backButton);
        profilePicture = findViewById(R.id.profileImage);
        username = findViewById(R.id.username);
        postImage = findViewById(R.id.postImage);
        caption = findViewById(R.id.caption);
        likeButton = findViewById(R.id.likeButton);
        likeCount = findViewById(R.id.likeCount);

        // Get intent data
        int profilePic = getIntent().getIntExtra("profilePic", R.drawable.profile_1);
        String usernameText = getIntent().getStringExtra("username");
        int postImageRes = getIntent().getIntExtra("postImage", R.drawable.post_1);
        String captionText = getIntent().getStringExtra("caption");
        likes = getIntent().getIntExtra("likes", 0);

        // Set data to views
        profilePicture.setImageResource(profilePic);
        username.setText(usernameText);
        postImage.setImageResource(postImageRes);
        caption.setText(captionText);
        likeCount.setText(likes + " likes");

        // Set click listeners
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        likeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isLiked = !isLiked;
                if (isLiked) {
                    likes++;
                    likeButton.setImageResource(R.drawable.ic_liked);
                } else {
                    likes--;
                    likeButton.setImageResource(R.drawable.ic_like);
                }
                likeCount.setText(likes + " likes");
            }
        });
    }
}