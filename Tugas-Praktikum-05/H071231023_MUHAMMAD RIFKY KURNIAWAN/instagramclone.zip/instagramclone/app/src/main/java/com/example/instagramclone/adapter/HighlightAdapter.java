package com.example.instagramclone.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagramclone.R;
import com.example.instagramclone.StoryDetailActivity;
import com.example.instagramclone.model.StoryHighlight;

import java.util.List;

public class HighlightAdapter extends RecyclerView.Adapter<HighlightAdapter.HighlightViewHolder> {

    private List<StoryHighlight> highlightList;
    private Context context;

    public HighlightAdapter(List<StoryHighlight> highlightList, Context context) {
        this.highlightList = highlightList;
        this.context = context;
    }

    @NonNull
    @Override
    public HighlightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_highlight, parent, false);
        return new HighlightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HighlightViewHolder holder, int position) {
        StoryHighlight highlight = highlightList.get(position);

        holder.highlightImage.setImageResource(highlight.getImageResource());
        holder.highlightTitle.setText(highlight.getTitle());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, StoryDetailActivity.class);
            intent.putExtra("title", highlight.getTitle());
            intent.putExtra("image", highlight.getImageResource());
            intent.putExtra("content", highlight.getContent());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return highlightList.size();
    }

    public static class HighlightViewHolder extends RecyclerView.ViewHolder {
        ImageView highlightImage;
        TextView highlightTitle;

        public HighlightViewHolder(@NonNull View itemView) {
            super(itemView);
            highlightImage = itemView.findViewById(R.id.highlightImage);
            highlightTitle = itemView.findViewById(R.id.highlightTitle);
        }
    }
}