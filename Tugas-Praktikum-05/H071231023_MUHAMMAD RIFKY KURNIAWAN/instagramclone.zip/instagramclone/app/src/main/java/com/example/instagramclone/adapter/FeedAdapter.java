package com.example.instagramclone.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagramclone.DetailFeedActivity;
import com.example.instagramclone.ProfileActivity;
import com.example.instagramclone.R;
import com.example.instagramclone.model.FeedPost;

import java.util.List;

public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.FeedViewHolder> {

    private List<FeedPost> feedList;
    private Context context;
    private boolean isProfilePage;

    public FeedAdapter(List<FeedPost> feedList, Context context, boolean isProfilePage) {
        this.feedList = feedList;
        this.context = context;
        this.isProfilePage = isProfilePage;
    }

    @NonNull
    @Override
    public FeedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (isProfilePage) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_feed_image_only, parent, false); // Gambar saja untuk profil
        } else {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_feed, parent, false); // Layout lengkap untuk feed utama
        }
        return new FeedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedViewHolder holder, int position) {
        FeedPost post = feedList.get(position);

        holder.postImage.setImageResource(post.getPostImage());  // Set image for the post

        if (!isProfilePage) {
            // Tampilkan data feed lengkap
            holder.profileImage.setImageResource(post.getUserProfilePic());
            holder.username.setText(post.getUsername());
            holder.caption.setText(post.getCaption());
            holder.likeCount.setText(post.getLikes() + " likes");

            if (post.isLiked()) {
                holder.likeButton.setImageResource(R.drawable.ic_liked);
            } else {
                holder.likeButton.setImageResource(R.drawable.ic_like);
            }

            holder.likeButton.setOnClickListener(v -> {
                post.setLiked(!post.isLiked());
                if (post.isLiked()) {
                    post.setLikes(post.getLikes() + 1);
                    holder.likeButton.setImageResource(R.drawable.ic_liked);
                } else {
                    post.setLikes(post.getLikes() - 1);
                    holder.likeButton.setImageResource(R.drawable.ic_like);
                }
                holder.likeCount.setText(post.getLikes() + " likes");
            });

            holder.profileLayout.setOnClickListener(v -> {
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("username", post.getUsername());
                intent.putExtra("profilePic", post.getUserProfilePic());
                context.startActivity(intent);
            });

        } else {
            // Jika di halaman profil, klik gambar → DetailFeed
            holder.postImage.setOnClickListener(v -> {
                Intent intent = new Intent(context, DetailFeedActivity.class);
                intent.putExtra("username", post.getUsername());
                intent.putExtra("profilePic", post.getUserProfilePic());
                intent.putExtra("postImage", post.getPostImage());
                intent.putExtra("caption", post.getCaption());
                intent.putExtra("likes", post.getLikes());
                context.startActivity(intent);
            });
        }
    }

    @Override
    public int getItemCount() {
        return feedList.size();
    }

    // Tambahan method agar bisa update data secara dinamis
    public void updateData(List<FeedPost> newFeedList) {
        this.feedList = newFeedList;
        notifyDataSetChanged();
    }

    public static class FeedViewHolder extends RecyclerView.ViewHolder {
        ImageView profileImage, postImage, likeButton;
        TextView username, caption, likeCount;
        ConstraintLayout profileLayout;

        public FeedViewHolder(@NonNull View itemView) {
            super(itemView);

            postImage = itemView.findViewById(R.id.postImage);

            // Coba ambil elemen lainnya, jika ada (layout lengkap)
            try {
                profileImage = itemView.findViewById(R.id.profileImage);
                username = itemView.findViewById(R.id.username);
                caption = itemView.findViewById(R.id.caption);
                likeCount = itemView.findViewById(R.id.likeCount);
                likeButton = itemView.findViewById(R.id.likeButton);
                profileLayout = itemView.findViewById(R.id.profileLayout);
            } catch (Exception ignored) {
                // Jika layout hanya gambar (profil page), elemen-elemen ini tidak ada
            }
        }
    }
}
