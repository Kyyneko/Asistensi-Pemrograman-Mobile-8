package com.example.tp5_h071231059.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp5_h071231059.R;
import com.example.tp5_h071231059.activities.DetailBookActivity;
import com.example.tp5_h071231059.models.Book;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    public static final int TYPE_NORMAL = 0;
    public static final int TYPE_HIGHEST_RATING = 1;
    private List<Book> bookList;
    private int viewTypeMode;

    public BookAdapter(Context context, List<Book> bookList, int viewTypeMode) {
        this.context = context;
        this.bookList = bookList;
        this.viewTypeMode = viewTypeMode;
    }

    @Override
    public int getItemViewType(int position) {
        return viewTypeMode;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == TYPE_HIGHEST_RATING) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_highest_rating, parent, false);
            return new HighestRatingBookViewHolder(view);
        } else {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_books, parent, false);
            return new NormalBookViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Book book = bookList.get(position);

        if (holder instanceof HighestRatingBookViewHolder) {
            HighestRatingBookViewHolder viewHolder = (HighestRatingBookViewHolder) holder;

            String cutTitle = book.getTitle().length() > 50
                    ? book.getTitle().substring(0, 50) + "..."
                    : book.getTitle();

            viewHolder.tv_title.setText(cutTitle);
            viewHolder.tv_author.setText(book.getAuthor());

            if (book.isFromUser()) {
                viewHolder.iv_bookCover.setImageURI(book.getImageCoverUri());
            } else {
                viewHolder.iv_bookCover.setImageResource(book.getImageCover());
            }

        } else if (holder instanceof NormalBookViewHolder) {
            NormalBookViewHolder viewHolder = (NormalBookViewHolder) holder;

            viewHolder.tv_title.setText(book.getTitle());
            viewHolder.tv_blurb.setText(book.getBlurb());
            viewHolder.tv_author.setText("by: " + book.getAuthor());

            if (book.isFromUser()) {
                viewHolder.iv_bookCover.setImageURI(book.getImageCoverUri());
            } else {
                viewHolder.iv_bookCover.setImageResource(book.getImageCover());
            }
        }

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailBookActivity.class);
            intent.putExtra("BOOK_ID", book.getId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public class NormalBookViewHolder extends RecyclerView.ViewHolder {
        TextView tv_title, tv_author, tv_blurb;
        ImageView iv_bookCover;

        public NormalBookViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_author = itemView.findViewById(R.id.tv_author);
            tv_blurb = itemView.findViewById(R.id.tv_blurb);
            iv_bookCover = itemView.findViewById(R.id.iv_bookCover);
        }
    }

    public class HighestRatingBookViewHolder extends RecyclerView.ViewHolder {
        TextView tv_title, tv_author;
        ImageView iv_bookCover;

        public HighestRatingBookViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_author = itemView.findViewById(R.id.tv_author);
            iv_bookCover = itemView.findViewById(R.id.iv_bookCover);
        }
    }

    public void setBooks(List<Book> newBooks) {
        this.bookList = newBooks;
        notifyDataSetChanged();
    }

    public void updateData(List<Book> newFavoriteBooks) {
        this.bookList.clear();
        this.bookList.addAll(newFavoriteBooks);
        notifyDataSetChanged();
    }
}
