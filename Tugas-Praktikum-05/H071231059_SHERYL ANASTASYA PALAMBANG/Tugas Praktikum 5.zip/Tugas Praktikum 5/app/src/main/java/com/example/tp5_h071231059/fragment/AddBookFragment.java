package com.example.tp5_h071231059.fragment;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.tp5_h071231059.R;
import com.example.tp5_h071231059.adapters.GenreAdapter;
import com.example.tp5_h071231059.datasource.BookDataSource;
import com.example.tp5_h071231059.datasource.GenreDataSource;
import com.example.tp5_h071231059.models.Book;
import com.example.tp5_h071231059.models.Genre;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class AddBookFragment extends Fragment {
    private GenreAdapter genreAdapter;
    private Uri imageBook;
    private ActivityResultLauncher<Intent> imagePickerLauncher;
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public AddBookFragment() {
        // Required empty public constructor
    }

    public static AddBookFragment newInstance(String param1, String param2) {
        AddBookFragment fragment = new AddBookFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_add_book, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageView iv_imageCover = view.findViewById(R.id.btn_imageCover);
        EditText et_title = view.findViewById(R.id.et_title);
        EditText et_author = view.findViewById(R.id.et_author);
        EditText et_year = view.findViewById(R.id.et_year);
        EditText et_blurb = view.findViewById(R.id.et_blurb);
        EditText et_synopsis = view.findViewById(R.id.et_synopsis);
        Button btn_addBook = view.findViewById(R.id.btn_addBook);


        RecyclerView genreRecyclerView = view.findViewById(R.id.rv_selectGenre);
        genreRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        genreAdapter = new GenreAdapter(
                GenreDataSource.generateDummyGenreList(),
                GenreAdapter.MODE_SELECT
        );
        genreRecyclerView.setAdapter(genreAdapter);
        genreRecyclerView.setLayoutManager(new LinearLayoutManager(this.getContext(), LinearLayoutManager.VERTICAL, false));


        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri imageUri = result.getData().getData();
                        if (imageUri != null) {
                            final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
                            requireContext().getContentResolver().takePersistableUriPermission(imageUri, takeFlags);

                            imageBook = imageUri;
                            iv_imageCover.setImageURI(imageBook);
                        }
                    }
                });

        iv_imageCover.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            imagePickerLauncher.launch(Intent.createChooser(intent, "Pilih Gambar"));
        });

        btn_addBook.setOnClickListener(v -> {
            String bookId = "book" + (BookDataSource.getBookList().size() + 1);
            String title = et_title.getText().toString();
            String author = et_author.getText().toString();
            String year = et_year.getText().toString();
            String blurb = et_blurb.getText().toString();
            String synopsis = et_synopsis.getText().toString();
            Set<Integer> selectedGenreIds = genreAdapter.getSelectedGenresIds();

            List<Genre> allGenres = GenreDataSource.generateDummyGenreList();
            List<Genre> selectedGenres = new ArrayList<>();

            for (Genre genre : allGenres) {
                if (selectedGenreIds.contains(genre.getId())) {
                    selectedGenres.add(genre);
                }
            }

            int yearInt = 0;
            try {
                yearInt = Integer.parseInt(year);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid year", Toast.LENGTH_SHORT).show();
                return;
            }

            if (title.isEmpty() || author.isEmpty() || year.isEmpty() || blurb.isEmpty() || synopsis.isEmpty() || selectedGenres.isEmpty() || imageBook == null) {
                Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            } else if (year.length() != 4 || yearInt < 1000 || yearInt > 2025) {
                Toast.makeText(getContext(), "Invalid year", Toast.LENGTH_SHORT).show();
                return;
            } else if (blurb.length() >= 130) {
                Toast.makeText(getContext(), "Blurb must be less than 130 characters", Toast.LENGTH_SHORT).show();
                return;
            }

            Book newBook = new Book(bookId, title, author, year, blurb, synopsis, selectedGenres, false, 0, imageBook);
            BookDataSource.addBook(newBook);

            BottomNavigationView bottomNavigationView = requireActivity().findViewById(R.id.bottom_navigation);
            bottomNavigationView.setSelectedItemId(R.id.nav_home);
        });
    }
}