package com.example.tp5_h071231059.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.tp5_h071231059.R;
import com.example.tp5_h071231059.adapters.BookAdapter;
import com.example.tp5_h071231059.datasource.BookDataSource;
import com.example.tp5_h071231059.models.Book;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FavoriteListFragment extends Fragment {
    private RecyclerView rv_favoriteBooks;
    private TextView tv_noFavorite;
    private ProgressBar progressBar;
    private BookAdapter adapter;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public FavoriteListFragment() {
        // Required empty public constructor
    }

    public static FavoriteListFragment newInstance(String param1, String param2) {
        FavoriteListFragment fragment = new FavoriteListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorite_list, container, false);
        rv_favoriteBooks = view.findViewById(R.id.rv_favoriteBooks);
        rv_favoriteBooks.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        progressBar = view.findViewById(R.id.progressBar);
        tv_noFavorite = view.findViewById(R.id.tv_noFavorite);

        adapter = new BookAdapter(getContext(), BookDataSource.getFavoriteBooks(), BookAdapter.TYPE_NORMAL);
        rv_favoriteBooks.setAdapter(adapter);

        loadFavoriteBooks();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadFavoriteBooks();
    }

    private void loadFavoriteBooks() {
        progressBar.setVisibility(View.VISIBLE);
        tv_noFavorite.setVisibility(View.GONE);
        rv_favoriteBooks.setVisibility(View.GONE);

        executor.execute(() -> {
            try {
                Thread.sleep(300);

                List<Book> favoriteBooks = BookDataSource.getFavoriteBooks();

                handler.post(() -> {
                    adapter.updateData(favoriteBooks);
                    progressBar.setVisibility(View.GONE);
                    rv_favoriteBooks.setVisibility(View.VISIBLE);

                    if (!BookDataSource.getFavoriteBooks().isEmpty()) {
                        tv_noFavorite.setVisibility(View.GONE);
                    } else {
                        tv_noFavorite.setVisibility(View.VISIBLE);
                    }

                });

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        });
    }
}