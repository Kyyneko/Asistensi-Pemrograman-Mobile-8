package com.example.tp5_h071231059.datasource;

import com.example.tp5_h071231059.R;
import com.example.tp5_h071231059.models.Book;
import com.example.tp5_h071231059.models.Genre;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BookDataSource {
    public static List<Book> bookList = new ArrayList<>();
    public static List<Book> newBooks = new ArrayList<>();

    public static List<Book> getBookList() {
        return bookList;
    }

    public static Book getBookById(String bookId) {
        for (Book book : bookList) {
            if (book.getId().equals(bookId)) {
                return book;
            }
        }
        return null;
    }

    public static void addBook(Book book) {
        bookList.add(book);
    }

    public static List<Book> generateDummyBooks() {
        if (!bookList.isEmpty()) return bookList;

        List<Genre> allGenres = GenreDataSource.generateDummyGenreList();

        bookList.add(new Book("book1", "Le Petit Prince", "Antoine de Saint-Exupéry", "2013",
                "A young prince from a distant star teaches a lost aviator about love, loss, and the invisible truths that make life meaningful.",
                "After crash-landing in the Sahara Desert, a pilot meets a strange, otherworldly boy: the Little Prince. As the boy recounts his travels from his tiny home planet to distant worlds, he shares profound reflections on love, loneliness, friendship, and the nature of what truly matters. Through their conversations, the pilot is reminded of the innocence and wonder that adults often forget. Filled with gentle wisdom and poetic beauty, Le Petit Prince is a timeless story that speaks to the child hidden within every heart",
                Arrays.asList(allGenres.get(0), allGenres.get(7)),
                false, R.drawable.img_lepetit
        ));

//        booknya ada 10 tapi nanti terlalu panjang kalau saya kirim semua jadi 1 saja saya kirim

        bookList.add(new Book("book2", "Harry Potter and the Philosopher’s Stone", "J.K. Rowling", "1997",
                "A young boy discovers he's a wizard and enters a magical world filled with wonder, danger, and destiny.",
                "Harry Potter has lived an ordinary life, abused by his relatives and unaware of his true identity. On his 11th birthday, he learns he is a wizard and is invited to attend Hogwarts School of Witchcraft and Wizardry. There, he makes new friends, faces mysteries surrounding a magical object, and begins to uncover secrets about his parents and his own fate. The journey begins in this captivating tale of magic, courage, and the power of love.",
                Arrays.asList(allGenres.get(0), allGenres.get(8)),
                false, R.drawable.img_bc_hp1
        ));

        bookList.add(new Book("book3", "聖母 (Holy Mother)", "Rikako Akiyoshi", "2016",
                "A gripping psychological thriller that explores the thin line between maternal love and obsession.",
                "A high school boy is found murdered. As the investigation unfolds, attention turns to Seiko, a beautiful, elegant woman with a mysterious aura. She is known as the perfect mother—but beneath her composed surface lies a chilling truth. Told through multiple perspectives, this dark and unsettling story explores themes of abuse, secrets, and the terrifying power of unconditional devotion.",
                Arrays.asList(allGenres.get(3), allGenres.get(10)),
                false, R.drawable.img_bc_holymother
        ));

        bookList.add(new Book("book4", "新参者 (The Newcomer)", "Keigo Higashino", "2009",
                "A brilliant detective unravels a murder mystery by delving into the lives of ordinary people in Nihonbashi.",
                "Detective Kaga has just been transferred to Nihonbashi when a woman is found murdered. As he investigates, he visits various shops and homes across the neighborhood, piecing together clues hidden in mundane details and personal interactions. Each chapter reveals a different perspective, gradually unveiling a touching story behind the crime. More than just a whodunit, *Shinzanmono* is a quiet exploration of empathy, trust, and human connection.",
                Arrays.asList(allGenres.get(3), allGenres.get(7)),
                false, R.drawable.img_bc_thenewcomer
        ));

        bookList.add(new Book("book5", "86 -Eighty Six- Vol. 5: Death, Be Not Proud", "Asato Asato", "2019",
                "The Strike Package is sent to aid the United Kingdom of Roa Gracia, uncovering chilling truths and a new enemy.",
                "Shin and the Eighty-Six follow the trail left by the mysterious Legion developer, Zelene Birkenbaum, into the icy north. Amid harsh battles and new allies, they encounter a horrifying strategy that shakes their convictions and forces them to question what it means to be human—or a monster.",
                Arrays.asList(allGenres.get(1), allGenres.get(11)),
                false, R.drawable.img_bc_86v5
        ));

        bookList.add(new Book("book6", "86 -Eighty Six- Vol. 6: Darkest Before the Dawn", "Asato Asato", "2019",
                "As the battle for the Dragon Corpse Mountains reaches its climax, Shin and Lena must confront their inner demons.",
                "Shin's resolve begins to crumble as he questions the meaning behind their fight, while Lena struggles to understand the pain he carries. Surrounded by the chaos of war and the ghosts of their past, both must decide whether to bridge the growing distance between them—or let it consume them.",
                Arrays.asList(allGenres.get(1), allGenres.get(11)),
                false, R.drawable.img_bc_86v6
        ));

        bookList.add(new Book("book7", "The Apothecary Diaries: Volume 1", "Natsu Hyuuga", "2014",
                "In a palace where secrets are guarded like treasures, one girl’s knowledge of medicine becomes her greatest weapon.",
                "Maomao, a young apothecary’s daughter, is content with her quiet life in the red-light district—until she is kidnapped and sold into the imperial palace. Hidden among the Emperor’s consorts, Maomao tries to stay unnoticed, but her sharp mind and deep understanding of medicine soon catch the attention of Jinshi, the enigmatic head eunuch. Tasked with identifying poisons and uncovering strange illnesses, Maomao navigates the treacherous social web of the inner court. As she solves medical mysteries and unravels palace intrigues, she begins to realize that knowledge can be both power—and a trap. Blending historical drama with clever deduction, *The Apothecary Diaries* is a tale of intellect, resilience, and unexpected destiny.",
                Arrays.asList(allGenres.get(12), allGenres.get(3)),
                false, R.drawable.img_bc_knh1
        ));

        bookList.add(new Book("book8", "The Apothecary Diaries: Volume 2", "Natsu Hyuuga", "2015",
                "Maomao leaves the palace’s inner court behind—but the mysteries, poisons, and strange encounters only seem to multiply.",
                "After being dismissed from the rear palace, Maomao finds herself reassigned to the outer court, now serving directly under Jinshi, the elegant and inscrutable official who seems far too perfect. Her presence quickly stirs jealousy among other attendants, but Maomao has little time for politics. A suspicious fire in a warehouse, a poisoned bureaucrat, and the curious final message of a deceased artisan soon pull her back into a web of intrigue. As Maomao uncovers unsettling clues, she begins to suspect that these events are linked in ways no one dares to speak aloud. Meanwhile, a peculiar military officer shows up with unnerving interest in her, further complicating her already unusual new life. In this second volume, *The Apothecary Diaries* deepens its world of deception, deduction, and danger, where nothing is ever quite as it seems.",
                Arrays.asList(allGenres.get(12), allGenres.get(3)),
                false, R.drawable.img_bc_knh2
        ));

        bookList.add(new Book("book9", "Before the Coffee Gets Cold", "Toshikazu Kawaguchi", "2015",
                "A small café in Tokyo offers customers a unique opportunity—to travel back in time, but only under one strange condition.",
                "In a quiet alley of Tokyo, there exists a tiny, unassuming café where rumors swirl of a seat that allows its occupant to travel through time. However, the trip is bound by strict rules: nothing done will change the present, and you must return before the coffee gets cold. Across four subtly interwoven tales, patrons of the café confront unspoken regrets, lost love, and final goodbyes. With gentle prose and tender reflections, *Before the Coffee Gets Cold* invites readers to ask: what would you change if you could revisit the past, even knowing it wouldn’t alter the future? It's a story of heartache, healing, and fleeting moments that stay with you forever.",
                Arrays.asList(allGenres.get(7), allGenres.get(14)),
                false, R.drawable.img_bc_btcgc
        ));

        bookList.add(new Book("book10", "Lonely Castle in the Mirror", "Mizuki Tsujimura", "2017",
                "A surreal fairytale-like tale where seven isolated teens are transported to a mysterious castle through their mirrors.",
                "Kokoro, a middle school girl struggling with bullying and isolation, finds her bedroom mirror glowing one day. Upon touching it, she is pulled into a magical castle alongside six other students. The castle is beautiful, ruled by a masked girl known as the Wolf Queen, and holds a promise: whoever finds the hidden key may have one wish granted. But the true challenge lies not in the game, but in the quiet unraveling of each child’s heartache, secrets, and hopes. As the seven begin to connect in ways they never could in the real world, *Lonely Castle in the Mirror* becomes a moving story of empathy, healing, and what it means to be seen.",
                Arrays.asList(allGenres.get(7), allGenres.get(0), allGenres.get(10)),
                false, R.drawable.img_bc_lcim
        ));

        bookList.addAll(newBooks);


        for (Book book : bookList) {
            float avgRating = ReviewDataSource.calculateAverageRating(book.getId());
            book.setAverageRating(avgRating);
        }

        return bookList;
    }

    public static List<Book> getHighestRatedBooks() {
        List<Book> allBooks = generateDummyBooks();
        List<Book> highestRatedBooks = new ArrayList<>();

        for (Book book : allBooks) {
            if (ReviewDataSource.calculateAverageRating(book.getId()) >= 4.0f) {
                highestRatedBooks.add(book);
            }
        }

        return highestRatedBooks;
    }

    public static List<Book> getFavoriteBooks() {
        List<Book> favoriteBooks = new ArrayList<>();
        for (Book book : bookList) {
            if (book.isLiked()) {
                favoriteBooks.add(book);
            }
        }
        return favoriteBooks;
    }
}

