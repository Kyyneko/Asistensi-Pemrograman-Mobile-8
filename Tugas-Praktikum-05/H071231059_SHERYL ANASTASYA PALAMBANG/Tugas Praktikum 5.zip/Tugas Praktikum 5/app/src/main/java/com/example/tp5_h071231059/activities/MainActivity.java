package com.example.tp5_h071231059.activities;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.example.tp5_h071231059.R;
import com.example.tp5_h071231059.databinding.ActivityMainBinding;
import com.example.tp5_h071231059.fragment.AddBookFragment;
import com.example.tp5_h071231059.fragment.FavoriteListFragment;
import com.example.tp5_h071231059.fragment.HomeFragment;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
            return insets;
        });


        replaceFragment(new HomeFragment());

        binding.bottomNavigation.setOnItemSelectedListener( item -> {
            Fragment selectedFragment = null;

            int id = item.getItemId();
            if (id == R.id.nav_home) {
                Fragment homeFragment = new HomeFragment();
                selectedFragment = homeFragment;
            } else if (id == R.id.nav_addBook) {
                Fragment addBookFragment = new AddBookFragment();
                selectedFragment = addBookFragment;
            } else if (id == R.id.nav_favoriteList) {
                Fragment favoriteListFragment = new FavoriteListFragment();
                selectedFragment = favoriteListFragment;
            }
            return replaceFragment(selectedFragment);
        });
    }

    private boolean replaceFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}
