package com.example.tp5_h071231059.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp5_h071231059.R;
import com.example.tp5_h071231059.models.Review;

import java.util.List;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ReviewViewHolder> {

    private List<Review> reviewList;

    public ReviewAdapter(List<Review> reviewList) {
        this.reviewList = reviewList;
    }

    @NonNull
    @Override
    public ReviewAdapter.ReviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_reviews, parent, false);
        return new ReviewViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ReviewAdapter.ReviewViewHolder holder, int position) {
        Review review = reviewList.get(position);
        holder.tv_review.setText(review.getReviewText());
        int rating = review.getRating();
        if (rating == 1) {
            holder.iv_rate.setImageResource(R.drawable.ic_rating1);
        } else if (rating == 2) {
            holder.iv_rate.setImageResource(R.drawable.ic_rating2);
        } else if (rating == 3) {
            holder.iv_rate.setImageResource(R.drawable.ic_rating3);
        } else if (rating == 4) {
            holder.iv_rate.setImageResource(R.drawable.ic_rating4);
        } else if (rating == 5) {
            holder.iv_rate.setImageResource(R.drawable.ic_rating5);
        } else {
            holder.iv_rate.setImageResource(R.drawable.ic_favoritetrue);
        }
    }

    @Override
    public int getItemCount() {
        return reviewList.size();
    }

    public class ReviewViewHolder extends RecyclerView.ViewHolder {
        TextView tv_review;
        ImageView iv_rate;
        public ReviewViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_review = itemView.findViewById(R.id.tv_review);
            iv_rate = itemView.findViewById(R.id.iv_rate);
        }
    }
}
