package com.example.tp5_h071231059.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp5_h071231059.R;
import com.example.tp5_h071231059.models.Genre;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GenreAdapter extends RecyclerView.Adapter<GenreAdapter.ViewHolder> {
    private List<Genre> genres;
    private int mode;
    private Set<Integer> selectedGenreIds = new HashSet<>();
    private OnGenreClickListener listener;
    private Genre selectedGenre;
    public static final int MODE_FILTER = 0;
    public static final int MODE_SELECT = 1;
    public static final int MODE_DISPLAY_ONLY = 2;

    public interface OnGenreClickListener {
        void onGenreClick(Genre genre);
    }

    public GenreAdapter(List<Genre> genres, int mode) {
        this.genres = genres;
        this.mode = mode;
    }

    public GenreAdapter(List<Genre> genres, int mode, OnGenreClickListener listener) {
        this.genres = genres;
        this.mode = mode;
        this.listener = listener;
    }

    @NonNull
    @Override
    public GenreAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (mode == MODE_SELECT) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_genre_checkbox, parent, false);
        } else {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_genres, parent, false);
        }
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GenreAdapter.ViewHolder holder, int position) {
        Genre genre = genres.get(position);
        holder.bind(genre);
    }

    @Override
    public int getItemCount() {
        return genres.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        Button btnGenre;
        CheckBox cbGenre;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            if (mode == MODE_SELECT) {
                cbGenre = itemView.findViewById(R.id.cb_genre);
            } else {
                btnGenre = itemView.findViewById(R.id.btn_genre);
            }
        }

        public void bind(Genre genre) {
            if (mode == MODE_FILTER) {
                if (btnGenre != null) {
                    btnGenre.setText(genre.getName());
                    btnGenre.setEnabled(true);

                    boolean isSelected = genre.equals(selectedGenre);
                    Context context = itemView.getContext();
                    if (isSelected) {
                        btnGenre.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_genre_true));
                        btnGenre.setTextColor(ContextCompat.getColor(context, R.color.backgroundHome));
                    } else {
                        btnGenre.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_genre));
                        btnGenre.setTextColor(ContextCompat.getColor(context, R.color.gray_text));
                    }

                    btnGenre.setOnClickListener(v -> {
                        if (genre.equals(selectedGenre)) {
                            selectedGenre = null;
                            notifyDataSetChanged();
                            if (listener != null) listener.onGenreClick(null);
                        } else {
                            selectedGenre = genre;
                            notifyDataSetChanged();
                            if (listener != null) listener.onGenreClick(genre);
                        }
                    });
                }

            } else if (mode == MODE_SELECT) {
                if (cbGenre != null) {
                    cbGenre.setText(genre.getName());
                    cbGenre.setOnCheckedChangeListener(null);
                    cbGenre.setChecked(selectedGenreIds.contains(genre.getId()));
                    cbGenre.setOnCheckedChangeListener((buttonView, isChecked) -> {
                        if (isChecked) {
                            selectedGenreIds.add(genre.getId());
                        } else {
                            selectedGenreIds.remove(genre.getId());
                        }
                    });
                }
            } else if (mode == MODE_DISPLAY_ONLY) {
                btnGenre.setText(genre.getName());
                btnGenre.setEnabled(false);
            }

        }
    }

    public Set<Integer> getSelectedGenresIds() {
        return selectedGenreIds;
    }

    public List<Genre> getSelectedGenres() {
        List<Genre> selected = new ArrayList<>();
        for (Genre genre : genres) {
            if (selectedGenreIds.contains(genre.getId())) {
                selected.add(genre);
            }
        }
        return selected;
    }


}
