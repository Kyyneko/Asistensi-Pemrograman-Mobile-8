package com.example.tp5_h071231059.models;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.List;

public class Book implements Parcelable {
    private String id;
    private String title;
    private String author;
    private String year;
    private String blurb;
    private String synopsis;
    private int imageCover;
    private Uri imageCoverUri;
    private List<Genre> genres;
    private boolean isLiked;
    private float averageRating;

    public Book(String id, String title, String author, String year, String blurb, String synopsis, List<Genre> genres, boolean isLiked, int imageCover) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.year = year;
        this.blurb = blurb;
        this.synopsis = synopsis;
        this.genres = genres;
        this.isLiked = isLiked;
        this.imageCover = imageCover;
    }

    public Book(String id, String title, String author, String year, String blurb, String synopsis, List<Genre> genres, boolean isLiked, float averageRating, Uri imageCoverUri) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.year = year;
        this.blurb = blurb;
        this.synopsis = synopsis;
        this.genres = genres;
        this.isLiked = isLiked;
        this.averageRating = averageRating;
        this.imageCoverUri = imageCoverUri;
    }

    protected Book(Parcel in) {
        id = in.readString();
        title = in.readString();
        author = in.readString();
        year = in.readString();
        blurb = in.readString();
        synopsis = in.readString();
        genres = in.createTypedArrayList(Genre.CREATOR);
        isLiked = in.readByte() != 0;
        imageCover = in.readInt();
        averageRating = in.readFloat();
        imageCoverUri = in.readParcelable(Uri.class.getClassLoader());
    }

    public static final Creator<Book> CREATOR = new Creator<Book>() {
        @Override
        public Book createFromParcel(Parcel in) {
            return new Book(in);
        }

        @Override
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getBlurb() {
        return blurb;
    }

    public void setBlurb(String blurb) {
        this.blurb = blurb;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public int getImageCover() {
        return imageCover;
    }

    public void setImageCover(int imageCover) {
        this.imageCover = imageCover;
    }

    public Uri getImageCoverUri() {
        return imageCoverUri;
    }

    public void setImageCoverUri(Uri imageCoverUri) {
        this.imageCoverUri = imageCoverUri;
    }

    public List<Genre> getGenres() {
        return genres;
    }

    public void setGenres(List<Genre> genres) {
        this.genres = genres;
    }

    public boolean isLiked() {
        return isLiked;
    }

    public void setLiked(boolean liked) {
        isLiked = liked;
    }

    public float getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(float averageRating) {
        this.averageRating = averageRating;
    }

    public boolean isFromUser() {
        return imageCoverUri != null;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(title);
        dest.writeString(author);
        dest.writeString(year);
        dest.writeString(blurb);
        dest.writeString(synopsis);
        dest.writeTypedList(genres);
        dest.writeByte((byte) (isLiked ? 1 : 0));
        dest.writeInt(imageCover);
        dest.writeFloat(averageRating);
        dest.writeParcelable(imageCoverUri, flags);
    }
}

