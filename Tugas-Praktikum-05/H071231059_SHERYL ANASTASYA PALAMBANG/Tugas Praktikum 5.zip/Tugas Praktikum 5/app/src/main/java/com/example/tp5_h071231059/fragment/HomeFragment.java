package com.example.tp5_h071231059.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp5_h071231059.R;
import com.example.tp5_h071231059.adapters.BookAdapter;
import com.example.tp5_h071231059.adapters.GenreAdapter;
import com.example.tp5_h071231059.datasource.BookDataSource;
import com.example.tp5_h071231059.datasource.GenreDataSource;
import com.example.tp5_h071231059.datasource.ReviewDataSource;
import com.example.tp5_h071231059.models.Book;
import com.example.tp5_h071231059.models.Genre;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeFragment extends Fragment {
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private BookAdapter bookAdapter;
    private BookAdapter highestBookAdapter;
    private List<Book> allBooks;
    private Genre selectedGenre = null;
    private String currentQuery = "";
    private TextView tv_highestRating;
    private SearchView sv_book;
    private ProgressBar progressBar;
    private  RecyclerView rv_highestRating, rv_genres, rv_books;
    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        tv_highestRating = view.findViewById(R.id.tv_highestRating);
        rv_highestRating = view.findViewById(R.id.rv_highestRating);
        rv_genres = view.findViewById(R.id.rv_genres);
        rv_books = view.findViewById(R.id.rv_books);
        progressBar = view.findViewById(R.id.progressBar);

        ReviewDataSource.generateDummyReviews();
        BookDataSource.generateDummyBooks();
        GenreDataSource.generateDummyGenreList();

        List<Book> highestBooks = BookDataSource.getHighestRatedBooks();
        highestBookAdapter = new BookAdapter(getContext(), highestBooks, BookAdapter.TYPE_HIGHEST_RATING);
        rv_highestRating.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        rv_highestRating.setAdapter(highestBookAdapter);

        allBooks = BookDataSource.getBookList();
        bookAdapter = new BookAdapter(getContext(), new ArrayList<>(allBooks), BookAdapter.TYPE_NORMAL);
        rv_books.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        rv_books.setAdapter(bookAdapter);

        sv_book = view.findViewById(R.id.sv_book);

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());
        sv_book.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                currentQuery = newText.toLowerCase();

                if (!currentQuery.isEmpty()) {
                    progressBar.setVisibility(View.VISIBLE);
                    rv_books.setVisibility(View.GONE);

                    executor.execute(() -> {
                        try {
                            Thread.sleep(300);

                                List<Book> result = getFilteredBooks(currentQuery, selectedGenre);

                                handler.post(() -> {
                                    if (currentQuery.equals(newText.toLowerCase())) {
                                        bookAdapter.setBooks(result);
                                        rv_books.setVisibility(View.VISIBLE);
                                        tv_highestRating.setVisibility(View.GONE);
                                        rv_highestRating.setVisibility(View.GONE);
                                        rv_genres.setVisibility(View.VISIBLE);
                                        progressBar.setVisibility(View.GONE);
                                    }
                                });
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    });

                } else {
                    bookAdapter.setBooks(new ArrayList<>(allBooks));
                    tv_highestRating.setVisibility(View.VISIBLE);
                    rv_highestRating.setVisibility(View.VISIBLE);
                    rv_books.setVisibility(View.VISIBLE);
                    rv_genres.setVisibility(View.VISIBLE);
                    progressBar.setVisibility(View.GONE);
                }
                return true;
            }
        });

        List<Genre> genres = GenreDataSource.generateDummyGenreList();
        GenreAdapter genreAdapter = new GenreAdapter(genres, GenreAdapter.MODE_FILTER ,genre -> {
            selectedGenre = genre;
            filterBooks();
        });
        rv_genres.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        rv_genres.setAdapter(genreAdapter);

        return view;
    }

    private void filterBooks() {
        List<Book> filteredList = getFilteredBooks(currentQuery, selectedGenre);
        bookAdapter.setBooks(filteredList);
    }

    private List<Book> getFilteredBooks(String query, Genre genre) {
        List<Book> filteredList = new ArrayList<>();
        for (Book book : allBooks) {
            boolean matchesTitle = book.getTitle().toLowerCase().contains(query);
            boolean matchesGenre = (genre == null || book.getGenres().contains(genre));
            if (matchesTitle && matchesGenre) {
                filteredList.add(book);
            }
        }
        return filteredList;
    }

}