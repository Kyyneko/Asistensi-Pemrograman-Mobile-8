package com.example.tp5_h071231059.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.tp5_h071231059.R;
import com.example.tp5_h071231059.adapters.GenreAdapter;
import com.example.tp5_h071231059.adapters.ReviewAdapter;
import com.example.tp5_h071231059.databinding.ActivityDetailBookBinding;
import com.example.tp5_h071231059.datasource.BookDataSource;
import com.example.tp5_h071231059.datasource.ReviewDataSource;
import com.example.tp5_h071231059.models.Book;
import com.example.tp5_h071231059.models.Review;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class DetailBookActivity extends AppCompatActivity {
    private ActivityDetailBookBinding binding;
    private List<Review> reviews = new ArrayList<>();
    private ReviewAdapter reviewAdapter;
    private String bookId;
    private ImageButton[] ratingButtons;
    private int selectedRating = 0;
    private int rating = 0;
    private float averageRating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityDetailBookBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        bookId = getIntent().getStringExtra("BOOK_ID");

        Book book = BookDataSource.getBookById(bookId);
        if (book == null) {
            Toast.makeText(this, "Book not found", Toast.LENGTH_SHORT).show();
        }

        reviews = ReviewDataSource.getReviewsForBook(bookId);
        reviewAdapter = new ReviewAdapter(reviews);
        binding.rvReviews.setAdapter(reviewAdapter);
        binding.rvReviews.setLayoutManager(new LinearLayoutManager(this));

        GenreAdapter genreAdapter = new GenreAdapter(book.getGenres(), GenreAdapter.MODE_DISPLAY_ONLY);
        binding.rvGenres.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        binding.rvGenres.setAdapter(genreAdapter);

        binding.tvTitle.setText(book.getTitle());
        binding.tvAuthorYear.setText(book.getAuthor() + " - " + book.getYear() );

        if (book.isFromUser()) {
            binding.ivBookCover.setImageURI(book.getImageCoverUri());
        } else {
            binding.ivBookCover.setImageResource(book.getImageCover());
        }

        averageRating = ReviewDataSource.calculateAverageRating(bookId);
        binding.tvRating.setText(String.format(Locale.US, "%.1f", averageRating));
        updateStarRating(averageRating);

        binding.tvDescription.setText(book.getSynopsis());

        binding.ibBack.setOnClickListener(v -> {
            finish();
        });

        if (book.isLiked()) {
            binding.ibAddToFav.setImageResource(R.drawable.ic_addtofavtrue);
        } else {
            binding.ibAddToFav.setImageResource(R.drawable.ic_addtofav);
        }

        binding.ibAddToFav.setOnClickListener(v -> {
            boolean currentStatus = book.isLiked();
            book.setLiked(!currentStatus);

            if (book.isLiked()) {
                binding.ibAddToFav.setImageResource(R.drawable.ic_addtofavtrue);
            } else {
                binding.ibAddToFav.setImageResource(R.drawable.ic_addtofav);
            }
        });

        ratingButtons = new ImageButton[]{
                binding.ibRating1,
                binding.ibRating2,
                binding.ibRating3,
                binding.ibRating4,
                binding.ibRating5
        };

        for (int i = 0; i < ratingButtons.length; i++) {
            int index = i;
            ratingButtons[i].setOnClickListener(v -> {
                selectedRating = index + 1;
                rating = selectedRating;
                updateStarUI(selectedRating);
            });
        }


        binding.btnAddReview.setOnClickListener(v -> {
            String reviewText = binding.etReview.getText().toString();
            if (!reviewText.isEmpty() && selectedRating > 0) {
                Review newReview = new Review(bookId, reviewText, rating);
                ReviewDataSource.addReview(newReview);

                reviews.add(0, newReview);
                reviewAdapter.notifyItemInserted(0);

                float averageRatingInput = ReviewDataSource.calculateAverageRating(bookId);
                String formattedRating = String.format("%.1f", averageRatingInput);
                binding.tvRating.setText(formattedRating);
                updateStarRating(averageRatingInput);

                binding.etReview.setText("");
                selectedRating = 0;
            } else {
                Toast.makeText(this, "Please enter a review and rating.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateStarUI(int rating) {
        for (int i = 0; i < ratingButtons.length; i++) {
            if (i < rating) {
                ratingButtons[i].setImageResource(R.drawable.ic_star);
            } else {
                ratingButtons[i].setImageResource(R.drawable.ic_starfalse);
            }
        }
    }

    private void updateStarRating(float averageRating) {
        binding.ivBookRating.setVisibility(View.VISIBLE);

        if (averageRating >= 1 && averageRating < 2) {
            binding.ivBookRating.setImageResource(R.drawable.ic_rating1);
        } else if (averageRating >= 2 && averageRating < 3) {
            binding.ivBookRating.setImageResource(R.drawable.ic_rating2);
        } else if (averageRating >= 3 && averageRating < 4) {
            binding.ivBookRating.setImageResource(R.drawable.ic_rating3);
        } else if (averageRating >= 4 && averageRating < 5) {
            binding.ivBookRating.setImageResource(R.drawable.ic_rating4);
        } else if (averageRating >= 5) {
            binding.ivBookRating.setImageResource(R.drawable.ic_rating5);
        } else {
            binding.ivBookRating.setVisibility(View.GONE);
            binding.tvRating.setText("No rate");
        }
    }

}