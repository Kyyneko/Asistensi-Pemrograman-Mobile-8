package com.example.tp5_h071231059.datasource;

import com.example.tp5_h071231059.models.Review;

import java.util.ArrayList;
import java.util.List;

public class ReviewDataSource {
    public static List<Review> reviewList = new ArrayList<>();

    public static void addReview(Review review) {
        reviewList.add(0, review);
    }

    public static List<Review> getReviewsForBook(String bookId) {
        List<Review> filtered = new ArrayList<>();
        for (Review review : reviewList) {
            if (review.getBookId().equals(bookId)) {
                filtered.add(review);
            }
        }
        return filtered;
    }

    public static float calculateAverageRating(String bookId) {
        List<Review> reviews = getReviewsForBook(bookId);
        if (reviews.isEmpty()) return 0f;

        int totalRating = 0;
        for (Review r : reviews) {
            totalRating += r.getRating();
        }
        return totalRating / (float) reviews.size();
    }

    public static void generateDummyReviews() {
        if (!reviewList.isEmpty()) return;

        addReview(new Review("book1", "A charming and poetic tale that lingers in your thoughts. The symbolism might go over younger readers' heads, but it's a rewarding read for those willing to reflect.", 5));
        addReview(new Review("book1", "Absolutely beautiful. A must-read that touches the soul. The simplicity hides deep philosophical meaning.", 5));
        addReview(new Review("book1", "An emotional masterpiece. I cried at the ending. It's incredible how much wisdom is packed into such a small book.", 5));
        addReview(new Review("book1", "A heartwarming journey filled with life lessons. Perfect for both children and adults. Timeless.", 5));
        addReview(new Review("book1", "While I admire the message, it didn’t resonate with me as strongly. Perhaps I’m just not the right audience for it.", 3));

        addReview(new Review("book2","A magical and immersive start to an unforgettable series. Rowling creates a world that's easy to get lost in.", 5));
        addReview(new Review("book2","Perfect for young readers. It sparked my love for reading!", 5));
        addReview(new Review("book2","Good book, but the pacing felt a bit slow in the beginning.", 3));
        addReview(new Review("book2","I enjoyed it, but it's more fun if you're a younger reader.", 4));
        addReview(new Review("book2", "Didn’t quite live up to the hype for me. A bit too predictable and childish in parts.", 2));

        addReview(new Review("book3","Disturbing but captivating. You won’t forget this story anytime soon.", 5));
        addReview(new Review("book3","I was hooked from start to finish. The final twist was brilliant.", 5));
        addReview(new Review("book3","A bit too dark for me, but undeniably well written.", 3));
        addReview(new Review("book3","Intense psychological exploration of a twisted mind. Not for the faint-hearted.", 4));
        addReview(new Review("book3", "I just couldn’t connect with the characters. It felt too grim for my taste.", 2));

        addReview(new Review("book4","Not your usual murder mystery—more emotional, more human.", 5));
        addReview(new Review("book4","The pacing is slow but satisfying. I loved the neighborhood atmosphere.", 4));
        addReview(new Review("book4","Kaga is such a unique and likable detective. Very refreshing.", 5));
        addReview(new Review("book4","Beautifully written. Makes you think about people’s hidden stories.", 4));
        addReview(new Review("book4", "I just couldn't get into it. The story felt too slow and uneventful for my taste.", 2));

        addReview(new Review("book5","Intense and thought-provoking. The psychological tension hit hard.", 5));
        addReview(new Review("book5","Great world-building and pacing. Loved the new setting.", 4));
        addReview(new Review("book5","A bit heavy on the politics, but the emotional payoff is worth it.", 4));
        addReview(new Review("book5","Zelene is a chilling antagonist. The writing keeps getting better.", 5));
        addReview(new Review("book5", "The plot slowed down a bit in this volume. Still interesting but not as engaging as the previous ones.", 3));

        addReview(new Review("book6","This volume hit me emotionally. Shin and Lena’s relationship is so raw and real.", 5));
        addReview(new Review("book6","Slower in action, but the character development is top-tier.", 4));
        addReview(new Review("book6","A beautiful balance of despair and hope. I couldn’t put it down.", 5));
        addReview(new Review("book6","Great payoff to the arc. Lena really shined this time.", 4));
        addReview(new Review("book6", "I just couldn’t get into it. The pacing was too slow for me.", 1));

        addReview(new Review("book7", "Intriguing setting and clever heroine. Some parts drag a little, but the mysteries are satisfying.", 4));
        addReview(new Review("book7", "A refreshing take on palace intrigue with a sharp, likable protagonist. The medical elements are fascinating.", 5));
        addReview(new Review("book7", "I liked the concept but found the pacing uneven. Too much explanation at times.", 3));
        addReview(new Review("book7", "Decent start, though it didn’t hook me as much as I hoped. Might pick up in later volumes.", 3));
        addReview(new Review("book7", "Somewhat repetitive in structure. Still, Maomao is an enjoyable character to follow.", 4));

        addReview(new Review("book8", "A stronger volume than the first. The cases are more complex and the pacing improves a lot.", 4));
        addReview(new Review("book8", "Maomao continues to shine. Her banter with Jinshi is a highlight. Loving the character dynamics.", 5));
        addReview(new Review("book8", "Interesting mysteries, though one plotline felt unresolved. Still a solid read.", 3));
        addReview(new Review("book8", "The balance between humor, intrigue, and deduction is spot on in this volume. Very satisfying.", 4));
        addReview(new Review("book8", "Really enjoyed the deepening plot threads. The new characters are intriguing and add tension.", 4));

        addReview(new Review("book9", "A deeply moving and quietly powerful story. The premise is simple, but the emotions are anything but.", 5));
        addReview(new Review("book9", "I love the way time travel is treated—not as a fix, but as a mirror. The characters feel real and flawed.", 4));
        addReview(new Review("book9", "Bittersweet and contemplative. Some stories hit harder than others, but overall a lovely read.", 4));
        addReview(new Review("book9", "I enjoyed the themes, though the writing style felt a bit flat at times. Still, it left an impression.", 3));
        addReview(new Review("book9", "A quiet gem. It made me reflect on my own regrets and what I’d do with just one more moment.", 4));

        addReview(new Review("book10", "A hauntingly beautiful story that explores loneliness in a way that feels deeply personal. The twist was heartbreaking.", 5));
        addReview(new Review("book10", "Magical and melancholic. The characters felt so real, and their struggles resonated with me.", 5));
        addReview(new Review("book10", "An emotional journey, though the pacing felt a bit slow in the middle. Still, very worth it.", 4));
        addReview(new Review("book10", "I appreciated the themes and metaphors, but it took a while for me to connect with the cast.", 3));
        addReview(new Review("book10", "A tender story of trauma and recovery wrapped in a surreal fantasy setting. Quietly powerful.", 4));
    }
}


