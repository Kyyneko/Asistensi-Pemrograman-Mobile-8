package com.example.tp5_h071231059.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Review implements Parcelable {
    private String bookId;
    private String reviewText;
    private int rating;

    public Review(String bookId, String reviewText, int rating) {
        this.bookId = bookId;
        this.reviewText = reviewText;
        this.rating = rating;
    }

    protected Review(Parcel in) {
        bookId = in.readString();
        reviewText = in.readString();
        rating = in.readInt();
    }

    public static final Creator<Review> CREATOR = new Creator<Review>() {
        @Override
        public Review createFromParcel(Parcel in) {
            return new Review(in);
        }

        @Override
        public Review[] newArray(int size) {
            return new Review[size];
        }
    };

    public String getReviewText() {
        return reviewText;
    }

    public void setReviewText(String reviewText) {
        this.reviewText = reviewText;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
    public String getBookId() {
        return bookId;
    }
    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(bookId);
        dest.writeString(reviewText);
        dest.writeInt(rating);
    }
}
