package com.example.tp5_h071231059.datasource;

import com.example.tp5_h071231059.models.Genre;

import java.util.ArrayList;
import java.util.List;

public class GenreDataSource {
    public static List<Genre> generateDummyGenreList() {
        List<Genre> genreList = new ArrayList<>();

        genreList.add(new Genre(1, "Fantasy"));
        genreList.add(new Genre(2, "Sci-Fi"));
        genreList.add(new Genre(3, "Romance"));
        genreList.add(new Genre(4, "Mystery"));
        genreList.add(new Genre(5, "Thriller"));
        genreList.add(new Genre(6, "Horror"));
        genreList.add(new Genre(7, "Comedy"));
        genreList.add(new Genre(8, "Drama"));
        genreList.add(new Genre(9, "Adventure"));
        genreList.add(new Genre(10, "Action"));
        genreList.add(new Genre(11, "Psychological"));
        genreList.add(new Genre(12, "Military"));
        genreList.add(new Genre(13, "Historical"));
        genreList.add(new Genre(14, "Crime"));
        genreList.add(new Genre(15, "Philosophical"));

        return genreList;
    }
}