package com.example.tp3_h071231017;

import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserStaticData {
    private static final Map<String, User> users = new HashMap<>();
    static final Map<String, List<Feed>> userPosts = new HashMap<>();
    private static final Map<String, List<List<Integer>>> userHighlights = new HashMap<>();


    static {

        users.put("login", new User(
                "login",
                "naylazahra.a",
                "nay",
                "powwie",
                String.valueOf(R.drawable.po),
                2,
                "1",
                "1"
        ));
        List<Feed> postsLogin = new ArrayList<>();
        postsLogin.add(new Feed(R.drawable.po, R.drawable.po_feed, "naylazahra.a", "10", "1", "0", "login", "naylazahra.a", "it's me", "", false)); // imagePost berupa Integer (resource ID)
        postsLogin.add(new Feed(R.drawable.po, R.drawable.po_feed2, "naylazahra.a", "10", "3", "-", "login", "naylazahra.a", "w/ lala", "", false)); // imagePost berupa Integer (resource ID)

        Log.d("UserStaticData", "User1 Posts: " + postsLogin);
        userPosts.put("login", postsLogin);

        List<List<Integer>> highlightsLogin = new ArrayList<>();
        List<Integer> highlightLogin1 = new ArrayList<>();
        highlightLogin1.add(R.drawable.posg);
        highlightLogin1.add(R.drawable.posg2);

        List<Integer> highlightLogin2 = new ArrayList<>();
        highlightLogin2.add(R.drawable.posg3);

        highlightsLogin.add(highlightLogin1);
        highlightsLogin.add(highlightLogin2);

        userHighlights.put("login", highlightsLogin);

        users.put("user1", new User(
                "user1",
                "zhangruonannan",
                "nannan",
                "❄️",
                String.valueOf(R.drawable.ruonan),
                2,
                "100",
                "1"
        ));
        List<Feed> postsUser1 = new ArrayList<>();
        postsUser1.add(new Feed(R.drawable.ruonan, R.drawable.ruonan_feed, "zhangruonannan", "334k", "1707", "8792", "user1", "zhangruonannan", "❄️", "", false));
        postsUser1.add(new Feed(R.drawable.ruonan, R.drawable.ruonan_feed2, "zhangruonannan", "806k", "5292", "9922", "user1", "zhangruonannan", "🤍", "", false));
        Log.d("UserStaticData", "User1 Posts: " + postsUser1);
        userPosts.put("user1", postsUser1);

        List<List<Integer>> highlightsUser1 = new ArrayList<>();
        List<Integer> highlightsUser1_1 = new ArrayList<>();
        highlightsUser1_1.add(R.drawable.nansg);
        highlightsUser1_1.add(R.drawable.ruonansg2);
        highlightsUser1.add(highlightsUser1_1);
        userHighlights.put("user1", highlightsUser1);

        users.put("user2", new User(
                "user2",
                "wow_kimsohyun",
                "kimsohyun",
                "🧸",
                String.valueOf(R.drawable.sohyunprofile),
                2,
                "13,4M",
                "6,396"
        ));
        List<Feed> postsUser2 = new ArrayList<>();
        postsUser2.add(new Feed(R.drawable.sohyunprofile, R.drawable.sohyun_feed, "wow_kimsohyun", "332k", "1,545", "65", "user2", "wow_kimsohyun", "🤳", "", false)); // imagePost berupa Integer (resource ID)
        postsUser2.add(new Feed(R.drawable.sohyunprofile, R.drawable.sohyun_feed2, "wow_kimsohyun", "552k", "2,407", "82", "user2", "wow_kimsohyun", "🧏‍♀️", "", false)); // imagePost berupa Integer (resource ID)
        Log.d("UserStaticData", "User2 Posts: " + postsUser2);
        userPosts.put("user2", postsUser2);

        List<List<Integer>> highlightsUser2 = new ArrayList<>();
        List<Integer> highlightsUser2_1 = new ArrayList<>();
        highlightsUser2_1.add(R.drawable.sohyunsg);
        highlightsUser2_1.add(R.drawable.sohyunsg2);
        highlightsUser2_1.add(R.drawable.sohyunsg3);
        highlightsUser2.add(highlightsUser2_1);
        userHighlights.put("user2", highlightsUser2);

        users.put("user4", new User(
                "user4",
                "goyounjung",
                "younjung",
                "🪷",
                String.valueOf(R.drawable.younjung),
                3,
                "8,1M",
                "1"
        ));
        List<Feed> postsUser4 = new ArrayList<>();
        postsUser4.add(new Feed(R.drawable.younjung, R.drawable.younjungfeed, "goyounjung", "1M", "5,182", "24K", "user4", "goyounjung", "🌸☔🌤️", "", false)); // imagePost berupa Integer (resource ID)
        postsUser4.add(new Feed(R.drawable.younjung, R.drawable.younjungfeed2, "goyounjung", "627K", "2,587", "10,2K", "user4", "goyounjung", ":<3", "", false)); // imagePost berupa Integer (resource ID)
        postsUser4.add(new Feed(R.drawable.younjung, R.drawable.younjungfeed3, "goyounjung", "2M", "9,609", "49.5K", "user4", "goyounjung", "🎸🐰", "", false)); // imagePost berupa Integer (resource ID)
        Log.d("UserStaticData", "User2 Posts: " + postsUser2);
        userPosts.put("user4", postsUser4);

        List<List<Integer>> highlightsUser4 = new ArrayList<>();
        List<Integer> highlightsUser4_1 = new ArrayList<>();
        highlightsUser4_1.add(R.drawable.younjungsg);
        highlightsUser4_1.add(R.drawable.younjungsg2);
        highlightsUser4_1.add(R.drawable.younjungsg3);
        highlightsUser4.add(highlightsUser4_1);
        userHighlights.put("user4", highlightsUser4);



        Log.d("UserStaticData", "Initial userPosts: " + userPosts);
    }


    public static User getUser(String userId) {

        return users.get(userId);
    }
    public static List<Feed> getPosts(String userId) {

        return userPosts.get(userId);
    }
    public static List<List<Integer>> getHighlights(String userId) {

        return userHighlights.get(userId);
    }

}