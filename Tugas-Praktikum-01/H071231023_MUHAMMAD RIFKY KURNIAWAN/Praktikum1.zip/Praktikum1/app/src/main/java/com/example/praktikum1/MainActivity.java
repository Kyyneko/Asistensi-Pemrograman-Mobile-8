package com.example.praktikum1;

import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Temukan ImageView dari layout
        ImageView profileImage = findViewById(R.id.profile_image);

        // Menampilkan gambar dari drawable
        profileImage.setImageResource(R.drawable.profile_picture);
    }
}
