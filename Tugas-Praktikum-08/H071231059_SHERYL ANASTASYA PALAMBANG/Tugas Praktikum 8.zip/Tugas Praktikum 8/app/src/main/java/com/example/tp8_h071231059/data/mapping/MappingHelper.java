package com.example.tp8_h071231059.data.mapping;

import android.database.Cursor;

import com.example.tp8_h071231059.data.db.DatabaseContract;
import com.example.tp8_h071231059.data.model.Note;

import java.util.ArrayList;

public class MappingHelper {
    public static ArrayList<Note> mapCursorToArrayList(Cursor cursor) {
        ArrayList<Note> notes = new ArrayList<>();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns._ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.TITLE));
            String content = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.CONTENT));
            String createdDate = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.CREATED_DATE));
            int backgroundColor = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.BACKGROUND_COLOR));
            notes.add(new Note(id, title, content, createdDate, backgroundColor));
        }
        return notes;
    }
}
