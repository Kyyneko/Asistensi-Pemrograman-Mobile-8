package com.example.tuprak8.activities;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.tuprak8.R;
import com.example.tuprak8.database.DatabaseManager;
import com.example.tuprak8.models.Note;

public class AddEditActivity extends AppCompatActivity {

    private EditText editTextTitle, editTextContent;
    private Button buttonSave;
    private TextView timestampTextView;
    private DatabaseManager databaseManager;
    private Note noteToEdit;
    private boolean isEditMode;
    private int noteId = -1;
    
    private String originalTitle = "";
    private String originalContent = "";
    private boolean hasUnsavedChanges = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        
        editTextTitle = findViewById(R.id.editTextTitle);
        editTextContent = findViewById(R.id.editTextContent);
        buttonSave = findViewById(R.id.buttonSave);
        timestampTextView = findViewById(R.id.timestampTextView);

        databaseManager = new DatabaseManager(this);

        noteId = getIntent().getIntExtra("NOTE_ID", -1);
        isEditMode = (noteId != -1);

        if (isEditMode) {
            getSupportActionBar().setTitle(getString(R.string.title_edit));
            noteToEdit = databaseManager.getNote(noteId);
            if (noteToEdit != null) {
                originalTitle = noteToEdit.getTitle();
                originalContent = noteToEdit.getContent();
                
                editTextTitle.setText(originalTitle);
                editTextContent.setText(originalContent);

                if (noteToEdit.getUpdatedAt() != null && !noteToEdit.getUpdatedAt().isEmpty()) {
                    timestampTextView.setText(getString(R.string.updated_at) + " " + noteToEdit.getUpdatedAt());
                } else {
                    timestampTextView.setText(getString(R.string.created_at) + " " + noteToEdit.getCreatedAt());
                }
                timestampTextView.setVisibility(View.VISIBLE);

                buttonSave.setText(getString(R.string.button_update));
            }
        } else {
            getSupportActionBar().setTitle(getString(R.string.title_add));
            timestampTextView.setVisibility(View.GONE);
            buttonSave.setText(getString(R.string.button_add));
        }
        
        editTextTitle.setHint(getString(R.string.hint_title));
        editTextContent.setHint(getString(R.string.hint_content));

        setupTextWatchers();
        buttonSave.setOnClickListener(v -> saveNote());
    }

    private void setupTextWatchers() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                checkForUnsavedChanges();
            }
        };

        editTextTitle.addTextChangedListener(textWatcher);
        editTextContent.addTextChangedListener(textWatcher);
    }

    private void checkForUnsavedChanges() {
        String currentTitle = editTextTitle.getText().toString();
        String currentContent = editTextContent.getText().toString();
        
        hasUnsavedChanges = !currentTitle.equals(originalTitle) || 
                           !currentContent.equals(originalContent);
    }

    @Override
    public void onBackPressed() {
        if (hasUnsavedChanges) {
            showExitConfirmationDialog();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            if (hasUnsavedChanges) {
                showExitConfirmationDialog();
            } else {
                onBackPressed();
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showExitConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_unsaved_title)
                .setMessage(R.string.dialog_unsaved_message)
                .setPositiveButton(R.string.button_exit, (dialog, which) -> {
                    finish();
                })
                .setNegativeButton(R.string.button_stay, (dialog, which) -> dialog.dismiss())
                .setNeutralButton(R.string.button_save, (dialog, which) -> {
                    saveNote();
                })
                .show();
    }

    private void saveNote() {
        String title = editTextTitle.getText().toString().trim();
        String content = editTextContent.getText().toString().trim();

        if (title.isEmpty()) {
            editTextTitle.setError(getString(R.string.error_empty_title));
            return;
        }

        if (isEditMode) {
            databaseManager.updateNote(noteId, title, content);
            Toast.makeText(this, R.string.note_updated, Toast.LENGTH_SHORT).show();
        } else {
            databaseManager.insertNote(title, content);
            Toast.makeText(this, R.string.note_added, Toast.LENGTH_SHORT).show();
        }

        hasUnsavedChanges = false;
        finish();
    }
}