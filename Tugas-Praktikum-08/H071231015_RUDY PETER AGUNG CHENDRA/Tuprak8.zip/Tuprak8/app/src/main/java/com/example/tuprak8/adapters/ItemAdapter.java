package com.example.tuprak8.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak8.R;
import com.example.tuprak8.models.Note;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private List<Note> noteList;
    private Context context;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Note note);
        void onDeleteClick(Note note);
        void onEditClick(Note note);
    }

    public ItemAdapter(List<Note> noteList, Context context, OnItemClickListener listener) {
        this.noteList = noteList;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_list, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Note note = noteList.get(position);
        holder.titleTextView.setText(note.getTitle());
        holder.contentTextView.setText(note.getContent());

        if (note.getUpdatedAt() != null && !note.getUpdatedAt().isEmpty()) {
            holder.timestampTextView.setText("Updated at " + note.getUpdatedAt());
        } else {
            holder.timestampTextView.setText("Created at " + note.getCreatedAt());
        }

        holder.itemView.setOnClickListener(v -> listener.onItemClick(note));
        holder.itemView.setOnLongClickListener(v -> {
            listener.onDeleteClick(note);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return noteList != null ? noteList.size() : 0;
    }

    public void updateNoteList(List<Note> newNoteList) {
        this.noteList = newNoteList;
        notifyDataSetChanged();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView contentTextView;
        TextView timestampTextView;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.item_title);
            contentTextView = itemView.findViewById(R.id.item_content);
            timestampTextView = itemView.findViewById(R.id.item_timestamp);
        }
    }
}