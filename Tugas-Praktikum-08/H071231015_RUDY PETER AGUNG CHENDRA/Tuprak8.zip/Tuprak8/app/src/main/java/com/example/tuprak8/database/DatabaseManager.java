package com.example.tuprak8.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.tuprak8.models.Note;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseManager {
    private DatabaseHelper dbHelper;

    public DatabaseManager(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    private String getCurrentTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    // CREATE
    public long insertNote(String title, String content) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.NoteEntry.COLUMN_TITLE, title);
        values.put(DatabaseContract.NoteEntry.COLUMN_CONTENT, content);
        values.put(DatabaseContract.NoteEntry.COLUMN_CREATED_AT, getCurrentTimestamp());
        
        long id = db.insert(DatabaseContract.NoteEntry.TABLE_NAME, null, values);
        db.close();
        return id;
    }

    // UPDATE
    public int updateNote(int id, String title, String content) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.NoteEntry.COLUMN_TITLE, title);
        values.put(DatabaseContract.NoteEntry.COLUMN_CONTENT, content);
        values.put(DatabaseContract.NoteEntry.COLUMN_UPDATED_AT, getCurrentTimestamp());
        
        int rowsAffected = db.update(
            DatabaseContract.NoteEntry.TABLE_NAME, 
            values, 
            DatabaseContract.NoteEntry._ID + " = ?", 
            new String[]{String.valueOf(id)}
        );
        db.close();
        return rowsAffected;
    }

    // DELETE
    public int deleteNote(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rowsDeleted = db.delete(
            DatabaseContract.NoteEntry.TABLE_NAME, 
            DatabaseContract.NoteEntry._ID + " = ?", 
            new String[]{String.valueOf(id)}
        );
        db.close();
        return rowsDeleted;
    }

    // READ
    public List<Note> getAllNotes() {
        List<Note> notes = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        Cursor cursor = db.query(
            DatabaseContract.NoteEntry.TABLE_NAME,
            null,
            null,
            null,
            null,
            null,
            DatabaseContract.NoteEntry._ID + " DESC"
        );
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                Note note = new Note();
                note.setId(cursor.getInt(cursor.getColumnIndex(DatabaseContract.NoteEntry._ID)));
                note.setTitle(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_TITLE)));
                note.setContent(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_CONTENT)));
                note.setCreatedAt(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_CREATED_AT)));
                note.setUpdatedAt(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_UPDATED_AT)));
                
                notes.add(note);
            } while (cursor.moveToNext());
            
            cursor.close();
        }
        db.close();
        return notes;
    }

    // Search 
    public List<Note> searchNotes(String query) {
        List<Note> notes = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        String searchPattern = "%" + query + "%";
        
        Cursor cursor = db.query(
            DatabaseContract.NoteEntry.TABLE_NAME,
            null,
            DatabaseContract.NoteEntry.COLUMN_TITLE + " LIKE ?",
            new String[]{searchPattern},
            null,
            null,
            DatabaseContract.NoteEntry._ID + " DESC"
        );
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                Note note = new Note();
                note.setId(cursor.getInt(cursor.getColumnIndex(DatabaseContract.NoteEntry._ID)));
                note.setTitle(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_TITLE)));
                note.setContent(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_CONTENT)));
                note.setCreatedAt(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_CREATED_AT)));
                note.setUpdatedAt(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_UPDATED_AT)));
                
                notes.add(note);
            } while (cursor.moveToNext());
            
            cursor.close();
        }
        db.close();
        return notes;
    }
    

    public Note getNote(int id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
            DatabaseContract.NoteEntry.TABLE_NAME,
            null,
            DatabaseContract.NoteEntry._ID + " = ?",
            new String[]{String.valueOf(id)},
            null,
            null,
            null
        );
        
        Note note = null;
        if (cursor != null && cursor.moveToFirst()) {
            note = new Note();
            note.setId(cursor.getInt(cursor.getColumnIndex(DatabaseContract.NoteEntry._ID)));
            note.setTitle(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_TITLE)));
            note.setContent(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_CONTENT)));
            note.setCreatedAt(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_CREATED_AT)));
            note.setUpdatedAt(cursor.getString(cursor.getColumnIndex(DatabaseContract.NoteEntry.COLUMN_UPDATED_AT)));
            cursor.close();
        }
        db.close();
        return note;
    }
}