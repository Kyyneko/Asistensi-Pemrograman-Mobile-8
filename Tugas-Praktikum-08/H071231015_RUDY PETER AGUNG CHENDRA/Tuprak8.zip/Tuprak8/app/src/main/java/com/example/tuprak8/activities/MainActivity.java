package com.example.tuprak8.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak8.R;
import com.example.tuprak8.adapters.ItemAdapter;
import com.example.tuprak8.database.DatabaseManager;
import com.example.tuprak8.models.Note;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ItemAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private List<Note> noteList;
    private DatabaseManager databaseManager;
    private EditText searchInput;
    private TextView emptyStateText;
    private FloatingActionButton fabAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        setTitle(R.string.title_main);
        
        recyclerView = findViewById(R.id.recycler_view);
        searchInput = findViewById(R.id.search_input);
        emptyStateText = findViewById(R.id.empty_state_text);
        fabAdd = findViewById(R.id.fab_add);
        
        databaseManager = new DatabaseManager(this);
        noteList = new ArrayList<>();

        setupRecyclerView();
        setupSearchFunctionality();
        
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
            startActivity(intent);
        });
        
        searchInput.setHint(getString(R.string.hint_search));
        emptyStateText.setText(getString(R.string.empty_state));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemAdapter = new ItemAdapter(noteList, this, this);
        recyclerView.setAdapter(itemAdapter);
    }

    private void loadNotes() {
        new Thread(() -> {
            List<Note> notes = databaseManager.getAllNotes();
            
            runOnUiThread(() -> {
                noteList.clear();
                noteList.addAll(notes);
                itemAdapter.notifyDataSetChanged();
                updateEmptyState();
            });
        }).start();
    }

    private void updateEmptyState() {
        if (noteList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            emptyStateText.setVisibility(View.VISIBLE);
            emptyStateText.setText(getString(R.string.empty_state));
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            emptyStateText.setVisibility(View.GONE);
        }
    }

    private void setupSearchFunctionality() {
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                final String query = s.toString().trim();
                // Gunakan debounce atau pindahkan ke thread terpisah
                new Thread(() -> {
                    List<Note> searchResults = databaseManager.searchNotes(query);
                    runOnUiThread(() -> {
                        noteList.clear();
                        noteList.addAll(searchResults);
                        itemAdapter.notifyDataSetChanged();
                        updateEmptyState();
                    });
                }).start();
            }
        });
    }

    @Override
    public void onItemClick(Note note) {
        Intent intent = new Intent(MainActivity.this, DetailActivity.class);
        intent.putExtra("NOTE_ID", note.getId());
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(Note note) {
        showDeleteConfirmationDialog(note);
    }
    
    @Override
    public void onEditClick(Note note) {
        Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
        intent.putExtra("NOTE_ID", note.getId());
        startActivity(intent);
    }

    private void showDeleteConfirmationDialog(Note note) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_delete_title)
                .setMessage(R.string.dialog_delete_message)
                .setPositiveButton(R.string.dialog_yes, (dialog, which) -> {
                    databaseManager.deleteNote(note.getId());
                    Toast.makeText(this, R.string.note_deleted, Toast.LENGTH_SHORT).show();
                    loadNotes();
                })
                .setNegativeButton(R.string.dialog_no, (dialog, which) -> dialog.dismiss())
                .show();
    }
}