package com.example.tuprak8.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.tuprak8.R;
import com.example.tuprak8.database.DatabaseManager;
import com.example.tuprak8.models.Note;

public class DetailActivity extends AppCompatActivity {

    private TextView titleTextView;
    private TextView contentTextView;
    private TextView timestampTextView;
    private Button editButton;
    private Button deleteButton;

    private DatabaseManager databaseManager;
    private int noteId;
    private Note note;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Setup toolbar dengan back arrow
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getString(R.string.title_detail));

        titleTextView = findViewById(R.id.textViewTitle);
        contentTextView = findViewById(R.id.textViewContent);
        timestampTextView = findViewById(R.id.textViewCreatedAt);
        editButton = findViewById(R.id.buttonEdit);
        deleteButton = findViewById(R.id.buttonDelete);

        databaseManager = new DatabaseManager(this);

        noteId = getIntent().getIntExtra("NOTE_ID", -1);
        if (noteId != -1) {
            loadNoteDetails();
        } else {
            Toast.makeText(this, R.string.note_not_found, Toast.LENGTH_SHORT).show();
            finish();
        }

        editButton.setText(getString(R.string.button_edit));
        deleteButton.setText(getString(R.string.button_delete));

        editButton.setOnClickListener(v -> {
            Intent intent = new Intent(DetailActivity.this, AddEditActivity.class);
            intent.putExtra("NOTE_ID", noteId);
            startActivity(intent);
        });

        deleteButton.setOnClickListener(v -> showDeleteConfirmationDialog());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (noteId != -1) {
            loadNoteDetails();
        }
    }

    private void loadNoteDetails() {
        note = databaseManager.getNote(noteId);
        if (note != null) {
            titleTextView.setText(note.getTitle());
            contentTextView.setText(note.getContent());

            if (note.getUpdatedAt() != null && !note.getUpdatedAt().isEmpty()) {
                timestampTextView.setText(getString(R.string.updated_at) + " " + note.getUpdatedAt());
            } else {
                timestampTextView.setText(getString(R.string.created_at) + " " + note.getCreatedAt());
            }
        }
    }

    private void showDeleteConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_delete_title)
                .setMessage(R.string.dialog_delete_message)
                .setPositiveButton(R.string.dialog_yes, (dialog, which) -> {
                    databaseManager.deleteNote(noteId);
                    Toast.makeText(this, R.string.note_deleted, Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton(R.string.dialog_no, (dialog, which) -> dialog.dismiss())
                .show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}