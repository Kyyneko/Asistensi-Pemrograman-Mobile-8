package com.example.tuprak8.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "notes_database";
    private static final int DATABASE_VERSION = 1;

    private static final String CREATE_TABLE_NOTES = "CREATE TABLE " + 
            DatabaseContract.NoteEntry.TABLE_NAME + "(" +
            DatabaseContract.NoteEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            DatabaseContract.NoteEntry.COLUMN_TITLE + " TEXT NOT NULL," +
            DatabaseContract.NoteEntry.COLUMN_CONTENT + " TEXT," +
            DatabaseContract.NoteEntry.COLUMN_CREATED_AT + " TEXT NOT NULL," +
            DatabaseContract.NoteEntry.COLUMN_UPDATED_AT + " TEXT" +
            ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_NOTES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DatabaseContract.NoteEntry.TABLE_NAME);
        onCreate(db);
    }
}