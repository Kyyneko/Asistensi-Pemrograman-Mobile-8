package com.example.tp4_h071231017;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.example.tp4_h071231017.AddBookFragment;
import com.example.tp4_h071231017.FavoritesFragment;
import com.example.tp4_h071231017.HomeFragment;
import com.example.tp4_h071231017.Book;
import com.example.tp4_h071231017.DataGenerator;
import com.example.tp4_h071231017.databinding.ActivityMainBinding;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    public static List<Book> bookList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(findViewById(R.id.toolbar));

        // Generate dummy data
        bookList = DataGenerator.generateDummyBooks();

        // Set default fragment
        loadFragment(new HomeFragment());

        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            Fragment fragment = null;

            if (item.getItemId() == R.id.nav_home) {
                fragment = new HomeFragment();
            } else if (item.getItemId() == R.id.nav_favorites) {
                fragment = new FavoritesFragment();
            } else if (item.getItemId() == R.id.nav_add) {
                fragment = new AddBookFragment();
            }

            return loadFragment(fragment);
        });
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            // Set title sesuai fragment
            if (fragment instanceof HomeFragment) {
                getSupportActionBar().setTitle("Home");
            } else if (fragment instanceof FavoritesFragment) {
                getSupportActionBar().setTitle("Favorit");
            } else if (fragment instanceof AddBookFragment) {
                getSupportActionBar().setTitle("Add Book");
            }

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

}
