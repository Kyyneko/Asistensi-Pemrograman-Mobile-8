package com.example.tuprak4.utils;

import com.example.tuprak4.models.Account;


public class AccountManager {
    private static AccountManager instance;
    private Account currentAccount;

    private AccountManager() {
        currentAccount = new Account();
    }

    public static synchronized AccountManager getInstance() {
        if (instance == null) {
            instance = new AccountManager();
        }
        return instance;
    }

    public Account getCurrentAccount() {
        return currentAccount;
    }

    public void updateAccount(String name, String email) {
        if (name != null && !name.isEmpty()) {
            currentAccount.setName(name);
        }
        
        if (email != null && !email.isEmpty()) {
            currentAccount.setEmail(email);
        }
    }

    public void updateProfileImage(String imagePath) {
        currentAccount.setProfileImagePath(imagePath);
    }

    public void resetAccount() {
        currentAccount = new Account();
    }
}