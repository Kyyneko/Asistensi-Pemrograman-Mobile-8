package com.example.tuprak4.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.activities.DetailActivity;
import com.example.tuprak4.models.Book;
import com.example.tuprak4.utils.ImageUtils;

import java.util.List;

public class CategoryBookAdapter extends RecyclerView.Adapter<CategoryBookAdapter.BookViewHolder> {

    private static final String TAG = "CategoryBookAdapter";
    private final Context context;
    private final List<Book> books;

    public CategoryBookAdapter(Context context, List<Book> books) {
        this.context = context;
        this.books = books;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_book_grid, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = books.get(position);
        
        holder.bookTitle.setText(book.getTitle());

        if (book.getAuthors() != null && !book.getAuthors().isEmpty()) {
            holder.bookAuthor.setText(book.getAuthors());
            holder.bookAuthor.setVisibility(View.VISIBLE);
        } else {
            holder.bookAuthor.setVisibility(View.GONE);
        }

        float rating = book.getRate();
        if (rating > 0) {
            holder.ratingBar.setRating(rating);
            holder.ratingBar.setVisibility(View.VISIBLE);
            if (holder.ratingCount != null) {
                holder.ratingCount.setText(String.format("(%d)", book.getRatingsCount()));
                holder.ratingCount.setVisibility(View.VISIBLE);
            }
        } else {
            holder.ratingBar.setVisibility(View.GONE);
            if (holder.ratingCount != null) {
                holder.ratingCount.setVisibility(View.GONE);
            }
        }
        
        String imageUrl = book.getImage();
        if (imageUrl != null && !imageUrl.isEmpty()) {
            ImageUtils.loadBookCover(holder.bookCover, imageUrl);
        } else {
            holder.bookCover.setImageResource(R.drawable.placeholder_book);
        }
        
        holder.cardView.setOnClickListener(v -> {
            Log.d(TAG, "Book clicked: " + book.getTitle());
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("BOOK_TITLE", book.getTitle());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    static class BookViewHolder extends RecyclerView.ViewHolder {
        ImageView bookCover;
        TextView bookTitle;
        TextView bookAuthor;
        RatingBar ratingBar;
        TextView ratingCount;
        View ratingContainer;
        CardView cardView;

        BookViewHolder(@NonNull View itemView) {
            super(itemView);
            bookCover = itemView.findViewById(R.id.book_cover);
            bookTitle = itemView.findViewById(R.id.book_title);
            bookAuthor = itemView.findViewById(R.id.book_author);
            ratingBar = itemView.findViewById(R.id.book_rating);
            ratingCount = itemView.findViewById(R.id.rating_count);
            ratingContainer = ((ViewGroup)ratingBar.getParent());
            cardView = (CardView) itemView;
        }
    }
}