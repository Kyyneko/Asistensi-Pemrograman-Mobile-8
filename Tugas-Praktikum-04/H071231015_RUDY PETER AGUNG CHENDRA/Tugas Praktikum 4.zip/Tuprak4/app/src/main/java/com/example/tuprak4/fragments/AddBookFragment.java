package com.example.tuprak4.fragments;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.models.Book;
import com.example.tuprak4.utils.BookManager;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AddBookFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int PERMISSION_REQUEST_READ_STORAGE = 2;
    private static final String TAG = "AddBookFragment";

    // Predefined categories
    private static final String[] CATEGORY_OPTIONS = {
        "Fiction", 
        "Business & Economics", 
        "Self-Help", 
        "Science", 
        "History", 
        "Health & Fitness", 
        "Computers", 
        "Biography & Autobiography", 
        "Cooking", 
        "Travel"
    };

    private ImageView coverImageView;
    private TextInputEditText titleInput;
    private TextInputEditText descriptionInput;
    private TextInputEditText publisherInput;
    private TextInputEditText publishedDateInput;
    private Button categorySelectButton;
    private TextView selectedCategoriesText;
    private Button selectImageButton;
    private Button addBookButton;
    private ChipGroup categoryChipGroup;
    private MaterialCheckBox hasPreviewLinkCheckbox;
    private MaterialCheckBox hasInfoLinkCheckbox;
    private TextInputLayout previewLinkInputLayout;
    private TextInputLayout infoLinkInputLayout;
    private TextInputEditText previewLinkInput;
    private TextInputEditText infoLinkInput;
    private Uri selectedImageUri = null;
    private List<String> selectedCategories = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_add_book, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initializeViews(view);
        setupListeners();
    }
    
    private void initializeViews(View view) {
        coverImageView = view.findViewById(R.id.add_book_image);
        selectImageButton = view.findViewById(R.id.btn_select_image);
        titleInput = view.findViewById(R.id.add_book_title);
        descriptionInput = view.findViewById(R.id.add_book_description);
        publisherInput = view.findViewById(R.id.add_book_publisher);
        publishedDateInput = view.findViewById(R.id.add_book_published_date);
        categoryChipGroup = view.findViewById(R.id.category_chip_group);
        categorySelectButton = view.findViewById(R.id.btn_select_categories);
        selectedCategoriesText = view.findViewById(R.id.text_selected_categories);
        hasPreviewLinkCheckbox = view.findViewById(R.id.checkbox_has_preview_link);
        hasInfoLinkCheckbox = view.findViewById(R.id.checkbox_has_info_link);
        previewLinkInputLayout = view.findViewById(R.id.preview_link_input_layout);
        infoLinkInputLayout = view.findViewById(R.id.info_link_input_layout);
        previewLinkInput = view.findViewById(R.id.add_book_preview_link);
        infoLinkInput = view.findViewById(R.id.add_book_info_link);
        addBookButton = view.findViewById(R.id.btn_add_book);
    }
    
    private void setupListeners() {
        selectImageButton.setOnClickListener(v -> requestStoragePermission());
        categorySelectButton.setOnClickListener(v -> showCategorySelectionDialog());
        addBookButton.setOnClickListener(v -> validateAndAddBook());
        hasPreviewLinkCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            previewLinkInputLayout.setVisibility(isChecked ? View.VISIBLE : View.GONE);
            if (!isChecked) {
                previewLinkInput.setText("");
            }
        });
        
        hasInfoLinkCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            infoLinkInputLayout.setVisibility(isChecked ? View.VISIBLE : View.GONE);
            if (!isChecked) {
                infoLinkInput.setText("");
            }
        });
    }
    
    private void addCategory(String category) {
        if (!selectedCategories.contains(category)) {
            selectedCategories.add(category);
            Chip chip = new Chip(requireContext());
            chip.setText(category);
            chip.setCloseIconVisible(true);
            chip.setCheckable(false);
            chip.setOnCloseIconClickListener(v -> {
                selectedCategories.remove(category);
                categoryChipGroup.removeView(chip);
                updateSelectedCategoriesText();
            });
            categoryChipGroup.addView(chip);
            updateSelectedCategoriesText();
        }
    }

    private void showCategorySelectionDialog() {
        boolean[] checkedItems = new boolean[CATEGORY_OPTIONS.length];
        for (int i = 0; i < CATEGORY_OPTIONS.length; i++) {
            checkedItems[i] = selectedCategories.contains(CATEGORY_OPTIONS[i]);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Select Categories");
        builder.setMultiChoiceItems(CATEGORY_OPTIONS, checkedItems, (dialog, which, isChecked) -> {
            checkedItems[which] = isChecked;
        });
        builder.setPositiveButton("OK", (dialog, which) -> {
            selectedCategories.clear();
            categoryChipGroup.removeAllViews();
            for (int i = 0; i < checkedItems.length; i++) {
                if (checkedItems[i]) {
                    addCategory(CATEGORY_OPTIONS[i]);
                }
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
    
    private void updateSelectedCategoriesText() {
        if (selectedCategories.isEmpty()) {
            selectedCategoriesText.setText("No categories selected");
            selectedCategoriesText.setVisibility(View.VISIBLE);
        } else {
            selectedCategoriesText.setVisibility(View.GONE);
        }
    }

    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) 
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(),
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_READ_STORAGE);
        } else {
            openImagePicker();
        }
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            Picasso.get()
                .load(selectedImageUri)
                .placeholder(R.drawable.placeholder_book)
                .error(R.drawable.error_book)
                .fit()
                .centerCrop()
                .into(coverImageView);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_READ_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openImagePicker();
            } else {
                Toast.makeText(requireContext(), "Permission denied. Cannot select images.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void validateAndAddBook() {
        // Check if image is selected
        if (selectedImageUri == null) {
            Toast.makeText(requireContext(), "Book cover image is required", Toast.LENGTH_SHORT).show();
            selectImageButton.requestFocus();
            return;
        }

        // Check title (already implemented)
        String title = titleInput.getText().toString().trim();
        if (TextUtils.isEmpty(title)) {
            titleInput.setError("Title is required");
            titleInput.requestFocus();
            return;
        }
        if (BookManager.getInstance().getBookByTitle(title) != null) {
            titleInput.setError("A book with this title already exists");
            titleInput.requestFocus();
            return;
        }

        // Check description
        String description = descriptionInput.getText().toString().trim();
        if (TextUtils.isEmpty(description)) {
            descriptionInput.setError("Description is required");
            descriptionInput.requestFocus();
            return;
        }

        // Check publisher
        String publisher = publisherInput.getText().toString().trim();
        if (TextUtils.isEmpty(publisher)) {
            publisherInput.setError("Publisher is required");
            publisherInput.requestFocus();
            return;
        }
        
        // Check published date
        String publishedDate = publishedDateInput.getText().toString().trim();
        if (TextUtils.isEmpty(publishedDate)) {
            publishedDateInput.setError("Published date is required");
            publishedDateInput.requestFocus();
            return;
        }
        
        // Check categories
        if (selectedCategories.isEmpty()) {
            Toast.makeText(requireContext(), "Please select at least one category", Toast.LENGTH_SHORT).show();
            categorySelectButton.requestFocus();
            return;
        }

        // Optional fields validation
        String previewLink = "";
        if (hasPreviewLinkCheckbox.isChecked()) {
            previewLink = previewLinkInput.getText().toString().trim();
            if (TextUtils.isEmpty(previewLink)) {
                previewLinkInput.setError("Preview link is required if checked");
                previewLinkInput.requestFocus();
                return;
            }
        }
        
        String infoLink = "";
        if (hasInfoLinkCheckbox.isChecked()) {
            infoLink = infoLinkInput.getText().toString().trim();
            if (TextUtils.isEmpty(infoLink)) {
                infoLinkInput.setError("Info link is required if checked");
                infoLinkInput.requestFocus();
                return;
            }
        }

        // Format categories
        String categories = "";
        List<String> formattedCategories = new ArrayList<>();
        for (String category : selectedCategories) {
            formattedCategories.add("['" + category + "']");
        }
        categories = TextUtils.join(",", formattedCategories);
        
        // Create and save book
        Book newBook = new Book();
        newBook.setTitle(title);
        newBook.setDescription(description);
        newBook.setAuthors("Rudy Peter");
        newBook.setPublisher(publisher);
        newBook.setPublishedDate(publishedDate);
        newBook.setCategories(categories);
        newBook.setPreviewLink(previewLink);
        newBook.setInfoLink(infoLink);
        newBook.setImage(selectedImageUri.toString());
        newBook.setRatingsCount(0);
        newBook.setRate(0.0f);
        
        BookManager.getInstance().addBook(newBook);
        showSuccessMessage();
        clearForm();
    }
    
    private void showSuccessMessage() {
        Toast.makeText(requireContext(), "Book added successfully!", Toast.LENGTH_SHORT).show();
    }

    private void clearForm() {
        titleInput.setText("");
        descriptionInput.setText("");
        publisherInput.setText("");
        publishedDateInput.setText("");
        selectedImageUri = null;
        coverImageView.setImageResource(R.drawable.placeholder_book);
        selectedCategories.clear();
        categoryChipGroup.removeAllViews();
        updateSelectedCategoriesText();
        hasPreviewLinkCheckbox.setChecked(false);
        hasInfoLinkCheckbox.setChecked(false);
        previewLinkInput.setText("");
        infoLinkInput.setText("");
        previewLinkInputLayout.setVisibility(View.GONE);
        infoLinkInputLayout.setVisibility(View.GONE);
    }
}