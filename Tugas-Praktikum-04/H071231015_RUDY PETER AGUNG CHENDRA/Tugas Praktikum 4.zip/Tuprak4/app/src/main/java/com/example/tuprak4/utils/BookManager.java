package com.example.tuprak4.utils;

import static androidx.fragment.app.FragmentManager.TAG;

import android.util.Log;

import com.example.tuprak4.models.Book;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookManager {
    private static BookManager instance;
    private final Map<String, Book> bookMap = new HashMap<>();
    private final List<Book> allBooks = new ArrayList<>();

    private BookManager() {
    }

    public static synchronized BookManager getInstance() {
        if (instance == null) {
            instance = new BookManager();
        }
        return instance;
    }

    public void addBook(Book book) {
        if (book != null && book.getTitle() != null) {

            Book existingBook = bookMap.get(book.getTitle());
            if (existingBook != null && existingBook.getImage() != null &&
                    !existingBook.getImage().isEmpty() &&
                    (book.getImage() == null || book.getImage().isEmpty())) {

                book.setImage(existingBook.getImage());
                Log.d(TAG, "🛠️ Restored missing image URL for: " + book.getTitle());
            }
            bookMap.put(book.getTitle(), book);
            if (!allBooks.contains(book)) {
                allBooks.add(book);
            }
            if (book.getImage() != null && !book.getImage().isEmpty()) {
                BookImageCache.getInstance().saveImageUrl(book.getTitle(), book.getImage());
            }
        }
    }

    public void addBooks(List<Book> books) {
        if (books != null) {
            for (Book book : books) {
                addBook(book);
            }
        }
    }

    public Book getBookByTitle(String title) {
        return bookMap.getOrDefault(title, null);
    }

    public void updateBook(Book book) {
        if (book != null && book.getTitle() != null) {
            bookMap.put(book.getTitle(), book);
        }
    }

    public List<Book> getAllBooks() {
        return new ArrayList<>(allBooks);
    }

    public List<Book> getLikedBooks() {
        List<Book> likedBooks = new ArrayList<>();
        for (Book book : allBooks) {
            if (book.isLiked()) {
                likedBooks.add(book);
            }
        }
        return likedBooks;
    }

    public void clearBooks() {
        bookMap.clear();
        allBooks.clear();
    }

    public List<String> getAllCategories() {
        // Return only the 10 specified categories
        return Arrays.asList(
            "['Fiction']",
            "['Business & Economics']",
            "['Self-Help']",
            "['Science']",
            "['History']",
            "['Health & Fitness']",
            "['Computers']",
            "['Biography & Autobiography']",
            "['Cooking']",
            "['Travel']"
        );
    }

    /**
     * Search books by keyword and optionally filter by category
     * 
     * @param query            The search query
     * @param selectedCategory Optional category to filter by (can be null for no
     *                         category filter)
     * @return List of books matching the criteria
     */
    public List<Book> searchBooks(String query, String selectedCategory) {
        List<Book> results = new ArrayList<>();
        String cleanCategory = null;
        if (selectedCategory != null && !selectedCategory.isEmpty()) {
            cleanCategory = selectedCategory.replaceAll("[\\[\\]']", "");
        }
        String lowerQuery = query != null ? query.toLowerCase() : "";

        for (Book book : allBooks) {
            boolean categoryMatch = cleanCategory == null ||
                    (book.getCategories() != null &&
                            book.getCategories().replaceAll("[\\[\\]']", "").equals(cleanCategory));
            if (!categoryMatch)
                continue;
            if (lowerQuery.isEmpty()) {
                results.add(book);
                continue;
            }
            boolean titleMatch = book.getTitle() != null &&
                    book.getTitle().toLowerCase().contains(lowerQuery);
            boolean authorMatch = book.getAuthors() != null &&
                    book.getAuthors().toLowerCase().contains(lowerQuery);
            boolean publisherMatch = book.getPublisher() != null &&
                    book.getPublisher().toLowerCase().contains(lowerQuery);
            if (titleMatch || authorMatch || publisherMatch) {
                results.add(book);
            }
        }
        return results;
    }

    public List<Book> getPopularBooks(int limit, String categoryFilter) {
        List<Book> allBooksCopy = new ArrayList<>(allBooks);
        List<Book> popularBooks = new ArrayList<>();
        if (categoryFilter != null && !categoryFilter.isEmpty()) {
            for (Book book : allBooksCopy) {
                if (book.getCategories() != null &&
                        book.getCategories().contains(categoryFilter)) {
                    popularBooks.add(book);
                }
            }
        } else {
            popularBooks.addAll(allBooksCopy);
        }
        Collections.sort(popularBooks,
                (book1, book2) -> Float.compare(book2.getRate(), book1.getRate()));
        int resultLimit = Math.min(limit, popularBooks.size());
        if (resultLimit > 0) {
            return popularBooks.subList(0, resultLimit);
        }
        return popularBooks;
    }

    public List<Book> getRecommendedBooks(int limit, String categoryFilter) {
        List<Book> allBooksCopy = new ArrayList<>(allBooks);
        List<Book> recommendedBooks = new ArrayList<>();
        if (categoryFilter != null && !categoryFilter.isEmpty()) {
            for (Book book : allBooksCopy) {
                if (book.getCategories() != null &&
                        book.getCategories().contains(categoryFilter)) {
                    recommendedBooks.add(book);
                }
            }
        } else {
            recommendedBooks.addAll(allBooksCopy);
        }
        Collections.sort(recommendedBooks,
                (book1, book2) -> Integer.compare(book2.getRatingsCount(), book1.getRatingsCount()));
        int resultLimit = Math.min(limit, recommendedBooks.size());
        if (resultLimit > 0) {
            return recommendedBooks.subList(0, resultLimit);
        }
        return recommendedBooks;
    }

    public List<Book> getPopularBooks(int limit) {
        return getPopularBooks(limit, null);
    }

    public List<Book> getNewReleases(int limit, String category) {
        List<Book> sortedBooks = new ArrayList<>(allBooks);
        String cleanCategory = category != null ? category.replaceAll("[\\[\\]']", "") : null;
        sortedBooks.sort((b1, b2) -> {
            String date1 = b1.getPublishedDate();
            String date2 = b2.getPublishedDate();
            if (date1 == null)
                return 1;
            if (date2 == null)
                return -1;
            int year1 = extractYear(date1);
            int year2 = extractYear(date2);
            return Integer.compare(year2, year1);
        });

        List<Book> result = new ArrayList<>();
        for (Book book : sortedBooks) {
            if (cleanCategory != null) {
                String bookCategory = book.getCategories();
                if (bookCategory == null || !bookCategory.replaceAll("[\\[\\]']", "").equals(cleanCategory)) {
                    continue;
                }
            }
            result.add(book);
            if (result.size() >= limit) {
                break;
            }
        }
        return result;
    }

    public List<Book> getNewReleases(int limit) {
        return getNewReleases(limit, null);
    }

    private int extractYear(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) {
            return 0;
        }
        for (int i = 0; i <= dateStr.length() - 4; i++) {
            String substr = dateStr.substring(i, i + 4);
            try {
                int year = Integer.parseInt(substr);
                if (year >= 1800 && year <= 2100) {
                    return year;
                }
            } catch (NumberFormatException e) {
            }
        }
        return 0;
    }
}
