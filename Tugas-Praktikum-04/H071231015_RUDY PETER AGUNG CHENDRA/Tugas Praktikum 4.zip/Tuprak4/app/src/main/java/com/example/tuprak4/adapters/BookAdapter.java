package com.example.tuprak4.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.activities.DetailActivity;
import com.example.tuprak4.models.Book;
import com.example.tuprak4.utils.BookImageCache;
import com.example.tuprak4.utils.BookManager;
import com.example.tuprak4.utils.ImageUtils;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;

import java.util.ArrayList;
import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> implements Filterable {
    
    private List<Book> books;
    private List<Book> allBooks;
    private Context context;
    private boolean searchMode = false; 
    
    public BookAdapter(Context context, List<Book> books) {
        this.context = context;
        this.books = books;
        this.allBooks = new ArrayList<>(books);
    }
    
    public BookAdapter(Context context, List<Book> books, boolean searchMode) {
        this.context = context;
        this.books = books;
        this.allBooks = new ArrayList<>(books);
        this.searchMode = searchMode;
    }
    
    public void setSearchMode(boolean searchMode) {
        this.searchMode = searchMode;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_book_horizontal, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = books.get(position);
        String bookTitle = book.getTitle();
        Book managerBook = BookManager.getInstance().getBookByTitle(bookTitle);
        
        holder.titleTextView.setText(bookTitle);
        holder.authorTextView.setText(book.getAuthors());
        if (searchMode) {
            createPlaceholder(holder.coverImageView, book, position);
            ViewGroup.LayoutParams params = holder.coverImageView.getLayoutParams();
            params.width = context.getResources().getDimensionPixelSize(R.dimen.search_result_image_width);
            params.height = context.getResources().getDimensionPixelSize(R.dimen.search_result_image_height);
            holder.coverImageView.setLayoutParams(params);
        } else {
            ImageView coverView = holder.coverImageView;
            String imageUrl = book.getImage();
            boolean cacheHit = false;
            if ((imageUrl == null || imageUrl.isEmpty()) && 
                BookImageCache.getInstance().hasImageUrl(bookTitle)) {
                imageUrl = BookImageCache.getInstance().getImageUrl(bookTitle);
                book.setImage(imageUrl);
                cacheHit = true;
            }
            coverView.setTag(R.id.tag_book_position, position);
            coverView.setImageResource(R.drawable.placeholder_book);
            coverView.setBackgroundResource(android.R.color.transparent);
            
            if (imageUrl != null && !imageUrl.isEmpty()) {
                String finalUrl = ImageUtils.validateImageUrl(imageUrl);
                if (!finalUrl.isEmpty()) {
                    BookImageCache.getInstance().saveImageUrl(bookTitle, finalUrl);
                    Picasso.get().cancelRequest(coverView);
                    int targetHeight = coverView.getHeight() > 0 ? coverView.getHeight() : 200;
                    int targetWidth = coverView.getWidth() > 0 ? coverView.getWidth() : (int)(targetHeight * 0.67);
                    Picasso.get()
                        .load(finalUrl)
                        .networkPolicy(NetworkPolicy.OFFLINE)
                        .resize(targetWidth, targetHeight)
                        .centerCrop()
                        .placeholder(R.drawable.placeholder_book)
                        .error(R.drawable.error_book)
                        .into(coverView, new Callback() {
                            @Override
                            public void onSuccess() {
                                Integer viewPosition = (Integer) coverView.getTag(R.id.tag_book_position);
                                if (viewPosition != null && viewPosition == position) {
                                    coverView.setBackgroundResource(android.R.color.transparent);
                                }
                            }
                            
                            @Override
                            public void onError(Exception e) {
                                Picasso.get()
                                    .load(finalUrl)
                                    .resize(targetWidth, targetHeight)
                                    .centerCrop()
                                    .placeholder(R.drawable.placeholder_book)
                                    .error(R.drawable.error_book)
                                    .into(coverView, new Callback() {
                                        @Override
                                        public void onSuccess() {
                                            Integer viewPosition = (Integer) coverView.getTag(R.id.tag_book_position);
                                            if (viewPosition != null && viewPosition == position) {
                                                coverView.setBackgroundResource(android.R.color.transparent);
                                                book.setImage(finalUrl);
                                                BookImageCache.getInstance().saveImageUrl(bookTitle, finalUrl);
                                            }
                                        }
                                        
                                        @Override
                                        public void onError(Exception e) {
                                            Log.e("BookAdapter", "❌ Error loading image: " + e.getMessage() + " for: " + bookTitle);
                                            createPlaceholder(coverView, book, position);
                                        }
                                    });
                            }
                        });
                    return; 
                }
            }
            createPlaceholder(coverView, book, position);
        }
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("BOOK_TITLE", bookTitle);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return books != null ? books.size() : 0;
    }

    @Override
    public Filter getFilter() {
        return booksFilter;
    }

    private Filter booksFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Book> filteredList = new ArrayList<>();
            
            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(allBooks);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                
                for (Book book : allBooks) {
                    if (book.getTitle().toLowerCase().contains(filterPattern) ||
                        book.getAuthors().toLowerCase().contains(filterPattern) ||
                        book.getCategories().toLowerCase().contains(filterPattern)) {
                        filteredList.add(book);
                    }
                }
            }
            
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            books.clear();
            books.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };
    
    public void updateData(List<Book> newBooks) {
        this.books = newBooks;
        this.allBooks = new ArrayList<>(newBooks);
        notifyDataSetChanged();
    }

    private void createPlaceholder(ImageView coverView, Book book, int position) {
        String placeholderSeed = book.getTitle() != null ? book.getTitle() : "book" + position;
        int hashCode = Math.abs(placeholderSeed.hashCode());
        int[] coverColors = {
            R.color.book_cover_blue, R.color.book_cover_green, 
            R.color.book_cover_red, R.color.book_cover_purple,
            R.color.book_cover_orange
        };
        int colorResId = coverColors[hashCode % coverColors.length];
        coverView.setBackgroundResource(colorResId);
    }

    static class BookViewHolder extends RecyclerView.ViewHolder {
        ImageView coverImageView;
        TextView titleTextView;
        TextView authorTextView;

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            coverImageView = itemView.findViewById(R.id.image_book_cover); // was book_image
            titleTextView = itemView.findViewById(R.id.text_book_title);   // was book_title
            authorTextView = itemView.findViewById(R.id.text_book_author); // was book_authors
        }
    }
}