package com.example.tuprak4.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.adapters.RecommendationAdapter;
import com.example.tuprak4.models.Book;
import com.example.tuprak4.utils.BookManager;
import com.example.tuprak4.utils.ImageUtils;
import com.example.tuprak4.utils.RecommendationManager;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DetailActivity extends AppCompatActivity {

    private ImageView bookCoverImage;
    private TextView bookTitle, bookAuthors, bookPublisher, bookPublishedDate;
    private TextView bookRatingValue, bookRatingsCountSmall, bookRatingsCount;
    private TextView bookDescription;
    private RatingBar bookRatingBar;
    private ChipGroup categoryChipGroup;
    private MaterialButton buttonLike, buttonPreview, buttonMoreInfo, buttonReadMore, buttonSeeAll;
    private RecyclerView recyclerViewRecommendations;
    private FloatingActionButton fabLike;
    private MaterialCardView recommendationsCard;
    private Book book;
    private boolean isLiked = false;
    private boolean isDescriptionExpanded = false;
    private List<Book> recommendedBooks = new ArrayList<>();
    private RecommendationAdapter recommendationAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        
        String bookTitle = getIntent().getStringExtra("BOOK_TITLE");
        if (bookTitle == null) {
            Toast.makeText(this, "Error: Book not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        
        book = BookManager.getInstance().getBookByTitle(bookTitle);
        if (book == null) {
            Toast.makeText(this, "Error: Book not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        initViews();
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        
        displayBookDetails();
        setupButtonListeners();
        loadRecommendations();
    }
    
    private void initViews() {
        bookCoverImage = findViewById(R.id.book_cover_image);
        bookRatingValue = findViewById(R.id.book_rating_value);
        bookRatingsCountSmall = findViewById(R.id.book_ratings_count_small);
        bookTitle = findViewById(R.id.book_title);
        bookAuthors = findViewById(R.id.book_authors);
        buttonLike = findViewById(R.id.button_like);
        buttonPreview = findViewById(R.id.button_preview);
        bookPublisher = findViewById(R.id.book_publisher);
        bookPublishedDate = findViewById(R.id.book_published_date);
        categoryChipGroup = findViewById(R.id.category_chip_group);
        bookRatingBar = findViewById(R.id.book_rating_bar);
        bookRatingsCount = findViewById(R.id.book_ratings_count);
        buttonMoreInfo = findViewById(R.id.button_more_info);
        bookDescription = findViewById(R.id.book_description);
        buttonReadMore = findViewById(R.id.button_read_more);
        recommendationsCard = findViewById(R.id.recommendations_card);
        recyclerViewRecommendations = findViewById(R.id.recycler_view_recommendations);
        buttonSeeAll = findViewById(R.id.button_see_all);
        fabLike = findViewById(R.id.fab_like);
    }
    
    private void displayBookDetails() {
        CollapsingToolbarLayout collapsingToolbar = findViewById(R.id.collapsing_toolbar);
        collapsingToolbar.setTitle("");
        bookTitle.setText(book.getTitle());
        bookAuthors.setText("By " + book.getAuthors());
        bookPublisher.setText(book.getPublisher());
        bookPublishedDate.setText(book.getPublishedDate());
        setupCategoryChips();
        setupRatings();
        String description = book.getDescription();
        if (description != null && !description.isEmpty()) {
            bookDescription.setText(description);
            bookDescription.setMaxLines(4); 
            isDescriptionExpanded = false; 
            buttonReadMore.setVisibility(description.length() > 150 ? View.VISIBLE : View.GONE);
            buttonReadMore.setText("Read more"); 
        } else {
            bookDescription.setText("No description available");
            buttonReadMore.setVisibility(View.GONE);
        }
        String imageUrl = book.getImage();
        if (imageUrl != null && !imageUrl.isEmpty()) {
            ImageUtils.loadBookCover(bookCoverImage, imageUrl);
        } else {
            bookCoverImage.setImageResource(R.drawable.placeholder_book);
        }
        isLiked = book.isLiked();
        updateLikeButton();
    }
    
    private void setupCategoryChips() {
        categoryChipGroup.removeAllViews();
        String categoriesStr = book.getCategories();
        if (categoriesStr != null && !categoriesStr.isEmpty()) {
            categoriesStr = categoriesStr.replaceAll("[\\[\\]']", "");
            String[] categoryArray = categoriesStr.split(",");
            for (String category : categoryArray) {
                String trimmedCategory = category.trim();
                if (!trimmedCategory.isEmpty()) {
                    Chip chip = new Chip(this);
                    chip.setText(trimmedCategory);
                    chip.setClickable(false);
                    chip.setCheckable(false);
                    categoryChipGroup.addView(chip);
                }
            }
        } else {
            Chip chip = new Chip(this);
            chip.setText("Not categorized");
            chip.setClickable(false);
            chip.setCheckable(false);
            categoryChipGroup.addView(chip);
        }
    }
    
    private void setupRatings() {
        float rating = book.getRate();
        int ratingsCount = book.getRatingsCount();
        bookRatingBar.setRating(rating);
        if (ratingsCount > 0) {
            bookRatingValue.setText(String.format("%.1f", rating));
            bookRatingsCountSmall.setText(String.valueOf(ratingsCount));
            bookRatingsCount.setText(String.format("%.1f (%d ratings)", rating, ratingsCount));
        } else {
            bookRatingValue.setVisibility(View.GONE);
            bookRatingsCountSmall.setVisibility(View.GONE);
            bookRatingsCount.setText("No ratings yet");
        }
    }
    
    private void setupButtonListeners() {
        buttonLike.setOnClickListener(v -> toggleLike());
        fabLike.setOnClickListener(v -> toggleLike());
        buttonPreview.setOnClickListener(v -> {
            if (book.getPreviewLink() != null && !book.getPreviewLink().isEmpty()) {
                openUrl(book.getPreviewLink());
            } else {
                Toast.makeText(this, "No preview available", Toast.LENGTH_SHORT).show();
            }
        });
        buttonMoreInfo.setOnClickListener(v -> {
            if (book.getInfoLink() != null && !book.getInfoLink().isEmpty()) {
                openUrl(book.getInfoLink());
            } else {
                Toast.makeText(this, "No additional info available", Toast.LENGTH_SHORT).show();
            }
        });
        buttonReadMore.setOnClickListener(v -> {
            isDescriptionExpanded = !isDescriptionExpanded;
            if (isDescriptionExpanded) {
                bookDescription.setMaxLines(Integer.MAX_VALUE);
                buttonReadMore.setText(R.string.read_less);
            } else {
                bookDescription.setMaxLines(4);
                buttonReadMore.setText(R.string.read_more);
            }
        });
        buttonSeeAll.setOnClickListener(v -> {
            Toast.makeText(this, "Showing all recommendations", Toast.LENGTH_SHORT).show();
        });
    }
    
    private void toggleLike() {
        isLiked = !isLiked;
        book.setLiked(isLiked);
        BookManager.getInstance().updateBook(book);
        updateLikeButton();
        Toast.makeText(this, 
            isLiked ? "Added to favorites" : "Removed from favorites", 
            Toast.LENGTH_SHORT).show();
    }
    
    private void updateLikeButton() {
        if (isLiked) {
            buttonLike.setText(R.string.liked);
            buttonLike.setIcon(getDrawable(R.drawable.ic_favorite));
            fabLike.setImageDrawable(getDrawable(R.drawable.ic_favorite));
        } else {
            buttonLike.setText(R.string.like);
            buttonLike.setIcon(getDrawable(R.drawable.ic_favorite_border));
            fabLike.setImageDrawable(getDrawable(R.drawable.ic_favorite_border));
        }
    }
    
    private void loadRecommendations() {
        List<String> recommendedTitles = RecommendationManager.getInstance(this)
                .getRecommendations(book.getTitle());
        recommendedBooks.clear();
        for (String title : recommendedTitles) {
            Book recommendedBook = BookManager.getInstance().getBookByTitle(title);
            if (recommendedBook != null) {
                recommendedBooks.add(recommendedBook);
            }
        }
        if (!recommendedBooks.isEmpty()) {
            recommendationAdapter = new RecommendationAdapter(this, recommendedBooks);
            recyclerViewRecommendations.setAdapter(recommendationAdapter);
            recyclerViewRecommendations.setLayoutManager(
                    new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        } else {
            View recommendationsCard = findViewById(R.id.recommendations_card);
            if (recommendationsCard != null) {
                recommendationsCard.setVisibility(View.GONE);
            }
        }
    }
    
    private void openUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}