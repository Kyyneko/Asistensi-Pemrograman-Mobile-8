package com.example.tuprak4.utils;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RecommendationManager {
    private static final String TAG = "RecommendationManager";
    private static final String RECOMMENDATIONS_FILE = "recommendations.json";

    private static RecommendationManager instance;
    private final Map<String, List<String>> recommendationsMap = new HashMap<>();

    private RecommendationManager(Context context) {
        loadRecommendations(context);
    }

    public static synchronized RecommendationManager getInstance(Context context) {
        if (instance == null) {
            instance = new RecommendationManager(context.getApplicationContext());
        }
        return instance;
    }

    public List<String> getRecommendations(String bookTitle) {
        if (bookTitle != null && recommendationsMap.containsKey(bookTitle)) {
            return new ArrayList<>(recommendationsMap.get(bookTitle));
        }
        return new ArrayList<>();
    }

    private void loadRecommendations(Context context) {
        AssetManager assetManager = context.getAssets();
        try {
            InputStream is = assetManager.open(RECOMMENDATIONS_FILE);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder jsonString = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonString.append(line);
            }
            reader.close();

            Gson gson = new Gson();
            Type type = new TypeToken<Map<String, List<String>>>() {
            }.getType();
            Map<String, List<String>> recommendations = gson.fromJson(jsonString.toString(), type);

            if (recommendations != null) {
                recommendationsMap.putAll(recommendations);
                Log.d(TAG, "Loaded " + recommendationsMap.size() + " book recommendations");
            }
        } catch (IOException e) {
            Log.e(TAG, "Error loading recommendations: " + e.getMessage());
        }
    }
}