package com.example.tuprak4.utils;

import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.example.tuprak4.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

public class ImageUtils {
    private static final String TAG = "ImageUtils";
    private static final boolean isEmulator = isEmulator();

    /**
     * @param imageView Target ImageView
     * @param url       Source image URL
     */
    public static void loadBookCover(ImageView imageView, String url) {
        if (imageView == null) {
            Log.e(TAG, "💥 ERROR: ImageView is null!");
            return;
        }

        String validatedUrl = validateImageUrl(url);

        if (validatedUrl.isEmpty()) {
            imageView.setImageResource(R.drawable.placeholder_book);
            imageView.setVisibility(View.VISIBLE);
            return;
        }

        int width = imageView.getLayoutParams().width;
        int height = imageView.getLayoutParams().height;


        String debugTag = "book_" + System.currentTimeMillis() % 10000;
        imageView.setTag(debugTag);

        imageView.setImageResource(R.drawable.placeholder_book);
        imageView.setVisibility(View.VISIBLE);

        Picasso.get()
                .load(validatedUrl)
                .placeholder(R.drawable.placeholder_book)
                .error(R.drawable.error_book)
                .into(imageView, new Callback() {
                    @Override
                    public void onSuccess() {
                        if (imageView.getDrawable() != null) {
                            Drawable drawable = imageView.getDrawable();
                        } else {
                            Log.e(TAG, "💥 Drawable is null after successful load!");
                        }
                    }

                    @Override
                    public void onError(Exception e) {
                        if (validatedUrl.contains("books.google") && validatedUrl.contains("zoom=1")) {
                            String fallbackUrl = validatedUrl.replace("zoom=1", "zoom=0");
                            Picasso.get()
                                    .load(fallbackUrl)
                                    .placeholder(R.drawable.placeholder_book)
                                    .error(R.drawable.error_book)
                                    .into(imageView);
                        }
                    }
                });
    }

    public static String validateImageUrl(String url) {
        if (url == null || url.isEmpty()) {
            return "";
        }


        if (url.startsWith("http:")) {
            url = url.replaceFirst("http:", "https:");
        }
        if (url.contains("books.google") &&
                (!url.contains("printsec=frontcover") || !url.contains("img=1"))) {
            try {
                String bookId = null;
                int idStart = url.indexOf("id=");
                if (idStart != -1) {
                    idStart += 3; // Skip "id="
                    int idEnd = url.indexOf("&", idStart);
                    if (idEnd != -1) {
                        bookId = url.substring(idStart, idEnd);
                    } else {
                        bookId = url.substring(idStart);
                    }

                    if (bookId != null && !bookId.isEmpty()) {
                        String newUrl = "https://books.google.com/books/content?id=" + bookId +
                                "&printsec=frontcover&img=1&zoom=1&source=gbs_api";
                        url = newUrl;
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "❌ Error reformatting Google Books URL: " + e.getMessage());
            }
        }

        return url;
    }

    public static String truncateUrl(String url, int maxLength) {
        if (url == null)
            return "";
        if (url.length() <= maxLength) {
            return url;
        }
        return url.substring(0, maxLength) + "...";
    }

    private static boolean isEmulator() {
        return (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.HARDWARE.contains("goldfish")
                || Build.HARDWARE.contains("ranchu")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || Build.PRODUCT.contains("sdk_google")
                || Build.PRODUCT.contains("google_sdk")
                || Build.PRODUCT.contains("sdk")
                || Build.PRODUCT.contains("sdk_x86")
                || Build.PRODUCT.contains("sdk_gphone64_arm64");
    }
}
