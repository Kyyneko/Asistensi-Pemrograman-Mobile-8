package com.example.tuprak4.adapters;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder> {

    public interface CategoryClickListener {
        void onCategoryClicked(String category);
    }

    private final Context context;
    private final List<String> categories;
    private final Random random = new Random();
    private int selectedPosition = -1; 
    private CategoryClickListener listener; 
    private final int[] categoryColors = new int[] {
        Color.parseColor("#EF5350"), // Red
        Color.parseColor("#42A5F5"), // Blue
        Color.parseColor("#66BB6A"), // Green
        Color.parseColor("#FFA726"), // Orange
        Color.parseColor("#AB47BC"), // Purple
        Color.parseColor("#26A69A"), // Teal
        Color.parseColor("#EC407A"), // Pink
        Color.parseColor("#7E57C2")  // Deep Purple
    };

    public CategoryAdapter(Context context, List<String> categories) {
        this.context = context;
        this.categories = cleanCategoryStrings(categories);
    }

    public void setCategoryClickListener(CategoryClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_category, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        String category = categories.get(position);
        holder.categoryName.setText(category);
        
        int colorIndex = Math.abs(category.hashCode()) % categoryColors.length;
        int backgroundColor = categoryColors[colorIndex];
        
        holder.cardView.setCardBackgroundColor(adjustAlpha(backgroundColor, 0.2f));
        holder.categoryName.setTextColor(backgroundColor);
        if (position == selectedPosition) {
            holder.cardView.setStrokeWidth(4);
            holder.cardView.setStrokeColor(backgroundColor);
        } else {
            holder.cardView.setStrokeWidth(0);
        }
        holder.itemView.setOnClickListener(v -> {
            int previousSelected = selectedPosition;
            selectedPosition = position == selectedPosition ? -1 : position;
            notifyItemChanged(previousSelected);
            notifyItemChanged(selectedPosition);
            if (listener != null) {
                listener.onCategoryClicked(category);
            }
        });
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }
    
    private List<String> cleanCategoryStrings(List<String> rawCategories) {
        List<String> cleaned = new ArrayList<>();
        for (String raw : rawCategories) {
            // Remove the [''] characters
            String clean = raw.replaceAll("[\\[\\]']", "");
            if (!clean.isEmpty() && !cleaned.contains(clean)) {
                cleaned.add(clean);
            }
        }
        return cleaned;
    }

    private int adjustAlpha(int color, float factor) {
        int alpha = Math.round(Color.alpha(color) * factor);
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        return Color.argb(alpha, red, green, blue);
    }

    static class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView categoryName;
        MaterialCardView cardView;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            categoryName = itemView.findViewById(R.id.category_name);
            cardView = (MaterialCardView) itemView;
        }
    }
}
