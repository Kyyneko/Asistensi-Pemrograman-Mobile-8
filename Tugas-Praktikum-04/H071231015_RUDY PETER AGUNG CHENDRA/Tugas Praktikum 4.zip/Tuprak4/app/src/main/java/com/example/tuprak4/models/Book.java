package com.example.tuprak4.models;

import android.util.Log;

public class Book {
    private String title;
    private String description;
    private String authors;
    private String image;
    private String previewLink;
    private String publisher;
    private String publishedDate;
    private String infoLink;
    private String categories;
    private int ratingsCount;
    private float rate; 
    private boolean liked;

    public Book() {
        this.liked = false;
        this.rate = 0.0f;
    }

    public Book(String title, String description, String authors, String image,
                String previewLink, String publisher, String publishedDate,
                String infoLink, String categories, int ratingsCount, float rate) {
        this.title = title;
        this.description = description;
        this.authors = authors;
        this.image = image;
        this.previewLink = previewLink;
        this.publisher = publisher;
        this.publishedDate = publishedDate;
        this.infoLink = infoLink;
        this.categories = categories;
        this.ratingsCount = ratingsCount;
        this.rate = rate;
        this.liked = false;
    }

    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getAuthors() { return authors; }
    public void setAuthors(String authors) { this.authors = authors; }

    public String getImage() {
        return image;
    }

    public void setImage(String image) { 
        this.image = image; 
    }
    public String getPreviewLink() { return previewLink; }
    public void setPreviewLink(String previewLink) { this.previewLink = previewLink; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    public String getPublishedDate() { return publishedDate; }
    public void setPublishedDate(String publishedDate) { this.publishedDate = publishedDate; }

    public String getInfoLink() { return infoLink; }
    public void setInfoLink(String infoLink) { this.infoLink = infoLink; }

    public String getCategories() { return categories; }
    public void setCategories(String categories) { this.categories = categories; }

    public int getRatingsCount() {
        return ratingsCount;
    }

    public void setRatingsCount(int ratingsCount) {
        this.ratingsCount = ratingsCount;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    public boolean isLiked() { return liked; }
    public void setLiked(boolean liked) { this.liked = liked; }
}