package com.example.tuprak4.utils;

import android.util.Log;
import java.util.HashMap;
import java.util.Map;

public class BookImageCache {
    private static final String TAG = "BookImageCache";
    private static BookImageCache instance;
    private final Map<String, String> imageUrlCache = new HashMap<>();
    
    private BookImageCache() {
        // Private constructor for singleton
    }
    
    public static synchronized BookImageCache getInstance() {
        if (instance == null) {
            instance = new BookImageCache();
        }
        return instance;
    }
    
    public String getImageUrl(String bookTitle) {
        if (bookTitle == null) return null;
        return imageUrlCache.get(bookTitle);
    }
    
    public void saveImageUrl(String bookTitle, String imageUrl) {
        if (bookTitle == null || imageUrl == null) return;
        
        if (!imageUrlCache.containsKey(bookTitle)) {
        }
        
        imageUrlCache.put(bookTitle, imageUrl);
    }
    

    public boolean hasImageUrl(String bookTitle) {
        if (bookTitle == null) return false;
        return imageUrlCache.containsKey(bookTitle) && 
               imageUrlCache.get(bookTitle) != null && 
               !imageUrlCache.get(bookTitle).isEmpty();
    }
}