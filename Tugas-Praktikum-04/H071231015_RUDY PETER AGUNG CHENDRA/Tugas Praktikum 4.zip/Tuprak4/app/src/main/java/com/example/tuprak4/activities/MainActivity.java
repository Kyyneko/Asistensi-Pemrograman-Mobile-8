package com.example.tuprak4.activities;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import androidx.navigation.Navigation;

import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.example.tuprak4.R;
import com.example.tuprak4.models.Book;
import com.example.tuprak4.utils.BookImageCache;
import com.example.tuprak4.utils.BookManager;
import com.example.tuprak4.utils.CSVParser;
import com.example.tuprak4.utils.ImageUtils;
import com.squareup.picasso.LruCache;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Callback;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import okhttp3.OkHttpClient;
import com.squareup.picasso.OkHttp3Downloader;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private ExecutorService executorService;
    private Handler mainHandler;
    private boolean isEmulator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);
        if (navHostFragment != null) {
            NavController navController = navHostFragment.getNavController();
            BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
            NavigationUI.setupWithNavController(bottomNavigationView, navController);
        } else {
            Log.e(TAG, "NavHostFragment not found! Check your layout file.");
        }

        BookImageCache.getInstance();
        isEmulator = isEmulator();
        int threadCount = isEmulator ? 2 : 4;
        executorService = Executors.newFixedThreadPool(threadCount);
        mainHandler = new Handler(Looper.getMainLooper());
        Picasso.Builder builder = new Picasso.Builder(this);
        builder.listener((picasso, uri, exception) -> {
            Log.e(TAG, "Picasso Error: " + exception.getMessage() + " for " + uri);
        });
        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS);
        int cacheSize = 50 * 1024 * 1024; // 50 MB
        File cacheDir = new File(getCacheDir(), "picasso-cache");
        if (!cacheDir.exists()) cacheDir.mkdirs();

        builder.downloader(new OkHttp3Downloader(cacheDir, cacheSize));
        builder.memoryCache(new LruCache(cacheSize / 4));
        
        try {
            Picasso picasso = builder.build();
            picasso.setIndicatorsEnabled(false);
            picasso.setLoggingEnabled(true);
            Picasso.setSingletonInstance(picasso);
        } catch (IllegalStateException e) {
            Picasso.get().setIndicatorsEnabled(false);
            Picasso.get().setLoggingEnabled(true);
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            StrictMode.VmPolicy.Builder vmPolicyBuilder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(vmPolicyBuilder.build());
        }
        
        loadBooksInBackground();
        
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }
    
    private boolean isEmulator() {
        return (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.HARDWARE.contains("goldfish")
                || Build.HARDWARE.contains("ranchu")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || Build.PRODUCT.contains("sdk_google")
                || Build.PRODUCT.contains("google_sdk")
                || Build.PRODUCT.contains("sdk")
                || Build.PRODUCT.contains("sdk_x86")
                || Build.PRODUCT.contains("sdk_gphone64_arm64");
    }
    
    private void loadBooksInBackground() {
        executorService.execute(() -> {
            try {
                new CSVParser(getApplicationContext()).parseBooks(); // Just parse and add to BookManager
                List<Book> books = BookManager.getInstance().getAllBooks(); // Get from manager
                
                if (isEmulator) {
                    processBookChunksForEmulator(books);
                } else {
                    processBookChunks(books);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error loading books: " + e.getMessage());
            }
        });
    }
    
    private void processBookChunksForEmulator(List<Book> books) {
        if (books == null || books.isEmpty()) return;
        
        final int CHUNK_SIZE = 10;
        final int totalBooks = books.size();
        int processedCount = 0;
        
        while (processedCount < totalBooks) {
            final int startIdx = processedCount;
            final int endIdx = Math.min(processedCount + CHUNK_SIZE, totalBooks);
            final List<Book> chunk = books.subList(startIdx, endIdx);
            
            for (Book book : chunk) {
                if (book.getImage() != null && !book.getImage().isEmpty()) {
                    String validatedUrl = ImageUtils.validateImageUrl(book.getImage());
                    if (validatedUrl.contains("books.google")) {
                        book.setImage("");
                    } else {
                        book.setImage(validatedUrl);
                    }
                }
            }
            
            final int chunkNumber = processedCount / CHUNK_SIZE;
            mainHandler.postDelayed(() -> {
                try {
                    if (chunkNumber == 0) {
                        preloadTopImages(chunk, 1);
                    }
                } catch (Exception e) {
                    Log.d(TAG, "Emulator image loading note: " + e.getMessage());
                }
            }, chunkNumber * 100);
            processedCount = endIdx;
        }
    }
    
    private void processBookChunks(List<Book> books) {
        if (books == null || books.isEmpty()) return;
        final int CHUNK_SIZE = 20;
        final int totalBooks = books.size();
        int processedCount = 0;
        
        while (processedCount < totalBooks) {
            final int startIdx = processedCount;
            final int endIdx = Math.min(processedCount + CHUNK_SIZE, totalBooks);
            final List<Book> chunk = books.subList(startIdx, endIdx);
            for (Book book : chunk) {
                if (book.getImage() != null && !book.getImage().isEmpty()) {
                    String validatedUrl = ImageUtils.validateImageUrl(book.getImage());
                    book.setImage(validatedUrl);
                }
            }
            final int chunkNumber = processedCount / CHUNK_SIZE;
            mainHandler.postDelayed(() -> {
                try {
                    if (chunkNumber == 0) {
                        preloadTopImages(chunk, 3);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error preloading images: " + e.getMessage());
                }
            }, chunkNumber * 50);
            processedCount = endIdx;
        }
    }
    
    private void preloadTopImages(List<Book> books, int count) {
        if (books == null || books.isEmpty()) return;
        int preloadCount = Math.min(count, books.size());
        for (int i = 0; i < preloadCount; i++) {
            final Book book = books.get(i);
            final int index = i;
            
            if (book.getImage() != null && !book.getImage().isEmpty()) {
                try {
                    int delay = isEmulator ? index * 350 : index * 100;
                    mainHandler.postDelayed(() -> {
                        try {
                            if (isEmulator && book.getImage().contains("books.google")) {
                                return;
                            }
                            
                            Picasso.get()
                                .load(book.getImage())
                                .error(R.drawable.placeholder_book)
                                .fetch(new Callback() {
                                    @Override
                                    public void onSuccess() {
                                        // Preload successful
                                    }
                                    
                                    @Override
                                    public void onError(Exception e) {
                                        if (!isEmulator) {
                                            Log.e(TAG, "Error preloading: " + e.getMessage());
                                        }
                                    }
                                });
                        } catch (Exception e) {
                            if (!isEmulator) {
                                Log.e(TAG, "Picasso error: " + e.getMessage());
                            }
                        }
                    }, delay);
                } catch (Exception e) {
                    // Suppressed
                }
            }
        }
    }
    
    @Override
    protected void onDestroy() {
        try {
            executorService.shutdown();
            executorService.awaitTermination(500, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Log.e(TAG, "Error shutting down executor: " + e.getMessage());
        } finally {
            super.onDestroy();
        }
    }
}