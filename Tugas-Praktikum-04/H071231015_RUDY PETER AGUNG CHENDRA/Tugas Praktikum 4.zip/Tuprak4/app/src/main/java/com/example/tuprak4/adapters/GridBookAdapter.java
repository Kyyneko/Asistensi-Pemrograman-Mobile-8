package com.example.tuprak4.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.activities.DetailActivity;
import com.example.tuprak4.models.Book;
import com.squareup.picasso.Picasso;

import java.util.List;

public class GridBookAdapter extends RecyclerView.Adapter<GridBookAdapter.GridViewHolder> {

    private final Context context;
    private final List<Book> books;

    public GridBookAdapter(Context context, List<Book> books) {
        this.context = context;
        this.books = books;
    }

    @NonNull
    @Override
    public GridViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_book_grid, parent, false);
        return new GridViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GridViewHolder holder, int position) {
        Book book = books.get(position);
        holder.bookTitle.setText(book.getTitle());
        holder.bookAuthor.setText(book.getAuthors());
        float rating = book.getRate();
        holder.bookRating.setRating(rating);
        String imageUrl = book.getImage();
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Picasso.get()
                .load(imageUrl)
                .placeholder(R.drawable.placeholder_book)
                .error(R.drawable.error_book)
                .into(holder.bookCover);
        } else {
            holder.bookCover.setImageResource(R.drawable.placeholder_book);
        }
        holder.itemView.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("BOOK_TITLE", book.getTitle());
                context.startActivity(intent);
            } catch (Exception e) {
                Log.e("GridBookAdapter", "Navigation error: " + e.getMessage());
                Toast.makeText(context, "Unable to open book details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    static class GridViewHolder extends RecyclerView.ViewHolder {
        ImageView bookCover;
        TextView bookTitle;
        TextView bookAuthor;
        RatingBar bookRating;

        GridViewHolder(@NonNull View itemView) {
            super(itemView);
            bookCover = itemView.findViewById(R.id.book_cover);
            bookTitle = itemView.findViewById(R.id.book_title);
            bookAuthor = itemView.findViewById(R.id.book_author);
            bookRating = itemView.findViewById(R.id.book_rating);
        }
    }
}