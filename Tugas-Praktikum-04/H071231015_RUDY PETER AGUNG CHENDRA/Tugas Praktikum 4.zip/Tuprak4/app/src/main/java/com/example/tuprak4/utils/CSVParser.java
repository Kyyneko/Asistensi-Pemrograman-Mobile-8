package com.example.tuprak4.utils;

import android.content.Context;
import android.util.Log;

import com.example.tuprak4.models.Book;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class CSVParser {
    private static final String TAG = "CSVParser";
    private static final String BOOKS_CSV_FILE = "books_sampled.csv";
    
    private final Context context;
    
    public CSVParser(Context context) {
        this.context = context;
    }
    
    public List<Book> parseBooks() {
        List<Book> books = new ArrayList<>();
        
        try {
            InputStream is = context.getAssets().open(BOOKS_CSV_FILE);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            
            String line = reader.readLine();
            
            while ((line = reader.readLine()) != null) {
                Book book = parseBookFromCSVLine(line);
                if (book != null) {
                    books.add(book);
                    BookManager.getInstance().addBook(book);
                }
            }
            
            reader.close();
        } catch (IOException e) {
            Log.e(TAG, "Error reading CSV file: " + e.getMessage());
        }
        
        return books;
    }
    
    private void analyzeCSVLine(String line) {
        if (line.contains("Sunday in the park") || 
            line.contains("Severe Food Allergies") ||
            line.contains("New shoes")) {
            
            Log.e(TAG, "🔍 ANALYZING PROBLEMATIC ROW: " + line);
            String[] simpleColumns = line.split(",");
            for (int i = 0; i < simpleColumns.length; i++) {
                Log.e(TAG, "Column " + i + ": " + simpleColumns[i]);
            }
        }
    }

    private Book parseBookFromCSVLine(String line) {
        if (line == null || line.isEmpty()) {
            return null;
        }
        
        analyzeCSVLine(line);
        
        List<String> tokens = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean inQuotes = false;
        
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            
            if (c == '\"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                tokens.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        
        tokens.add(sb.toString());
        
        try {
            if (tokens.size() < 4) {
                return null;
            }
            
            String title = getValueOrEmpty(tokens, 0);
            String description = getValueOrEmpty(tokens, 1);
            String authors = getValueOrEmpty(tokens, 2);
            String imageUrl = getValueOrEmpty(tokens, 3);
            
            imageUrl = imageUrl.replaceAll("^\"|\"$", "").trim();
            if (imageUrl != null && !imageUrl.isEmpty()) {
                BookImageCache.getInstance().saveImageUrl(title, imageUrl);
            }
            
            Book book = new Book();
            book.setTitle(title);
            book.setDescription(description);
            book.setAuthors(authors);
            book.setImage(imageUrl);
            
            if (tokens.size() > 4) book.setPreviewLink(getValueOrEmpty(tokens, 4));
            if (tokens.size() > 5) book.setPublisher(getValueOrEmpty(tokens, 5));
            if (tokens.size() > 6) book.setPublishedDate(getValueOrEmpty(tokens, 6));
            if (tokens.size() > 7) book.setInfoLink(getValueOrEmpty(tokens, 7));
            if (tokens.size() > 8) book.setCategories(getValueOrEmpty(tokens, 8));
            
            if (tokens.size() > 9) {
                try {
                    book.setRatingsCount(parseIntSafely(getValueOrEmpty(tokens, 9)));
                } catch (Exception e) {
                    book.setRatingsCount(0);
                }
            }
            
            if (tokens.size() > 10) {
                try {
                    book.setRate(parseFloatSafely(getValueOrEmpty(tokens, 10)));
                } catch (Exception e) {
                    book.setRate(0.0f);
                }
            }
            
            if (tokens.size() > 11) {
                try {
                    book.setLiked(Boolean.parseBoolean(getValueOrEmpty(tokens, 11)));
                } catch (Exception e) {
                    book.setLiked(false);
                }
            }
            
            return book;
        } catch (Exception e) {
            Log.e(TAG, "Error parsing CSV line: " + e.getMessage());
            return null;
        }
    }
    
    private String getValueOrEmpty(List<String> tokens, int index) {
        if (index < tokens.size()) {
            String value = tokens.get(index).trim();
            if (value.startsWith("\"") && value.endsWith("\"")) {
                value = value.substring(1, value.length() - 1);
            }
            return value;
        }
        return "";
    }
    
    private int parseIntSafely(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    
    private float parseFloatSafely(String value) {
        try {
            return Float.parseFloat(value);
        } catch (NumberFormatException e) {
            return 0.0f;
        }
    }
}