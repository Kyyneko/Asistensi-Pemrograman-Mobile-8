package com.example.tuprak4.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.activities.DetailActivity;
import com.example.tuprak4.models.Book;

import java.util.ArrayList;
import java.util.List;

public class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.SearchResultViewHolder> {
    
    private List<Book> books;
    private Context context;
    private int layoutResId;

    public SearchResultAdapter(Context context, List<Book> books, int layoutResId) {
        this.context = context;
        this.books = books;
        this.layoutResId = layoutResId;
    }

    public SearchResultAdapter(Context context, List<Book> books) {
        this(context, books, R.layout.item_search_result);
    }
    
    @NonNull
    @Override
    public SearchResultViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(layoutResId, parent, false);
        return new SearchResultViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull SearchResultViewHolder holder, int position) {
        Book book = books.get(position);
        holder.titleTextView.setText(book.getTitle());
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("BOOK_TITLE", book.getTitle());
            context.startActivity(intent);
        });
    }
    
    @Override
    public int getItemCount() {
        return books.size();
    }
    
    public void updateData(List<Book> newBooks) {
        this.books = newBooks != null ? newBooks : new ArrayList<>();
        notifyDataSetChanged();
    }
    
    static class SearchResultViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        
        public SearchResultViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.book_title);
        }
    }
}