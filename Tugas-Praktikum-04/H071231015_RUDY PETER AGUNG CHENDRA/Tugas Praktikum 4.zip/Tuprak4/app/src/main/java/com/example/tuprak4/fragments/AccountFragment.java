package com.example.tuprak4.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.adapters.BookAdapter;
import com.example.tuprak4.models.Book;
import com.example.tuprak4.utils.AccountManager;
import com.example.tuprak4.utils.BookManager;
import com.example.tuprak4.models.Account;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.List;

public class AccountFragment extends Fragment {

    private ShapeableImageView profileImageView;
    private TextView userNameTextView;
    private TextView userEmailTextView;
    private MaterialButton editProfileButton;
    private MaterialButton viewAllLikedButton;
    private MaterialButton exploreButton;
    private RecyclerView likedBooksRecyclerView;
    private ConstraintLayout emptyStateLayout;
    private MaterialCardView likedBooksCard;

    private Account account;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        account = AccountManager.getInstance().getCurrentAccount();
        displayAccountInfo();
        setupClickListeners();
        loadLikedBooks();
    }

    private void initViews(View view) {
        profileImageView = view.findViewById(R.id.image_profile);
        userNameTextView = view.findViewById(R.id.text_user_name);
        userEmailTextView = view.findViewById(R.id.text_user_email);
        editProfileButton = view.findViewById(R.id.button_edit_profile);
        likedBooksRecyclerView = view.findViewById(R.id.recycler_view_liked_books);
        emptyStateLayout = view.findViewById(R.id.layout_empty_liked_books);
        likedBooksCard = view.findViewById(R.id.card_liked_books);
        viewAllLikedButton = view.findViewById(R.id.button_view_all_liked);
        exploreButton = view.findViewById(R.id.button_explore_books);
        likedBooksRecyclerView.setLayoutManager(
                new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false));
    }

    private void displayAccountInfo() {
        userNameTextView.setText(account.getName());
        userEmailTextView.setText(account.getEmail());
    }

    private void setupClickListeners() {
        editProfileButton.setOnClickListener(v -> showEditProfileDialog());
        viewAllLikedButton.setOnClickListener(v -> {
            try {
                Bundle args = new Bundle();
                args.putString("CATEGORY", "Liked");
                Log.d("AccountFragment", "Navigating to liked books view with " + 
                    BookManager.getInstance().getLikedBooks().size() + " books");
                Navigation.findNavController(v).navigate(R.id.categoryFragment, args);
            } catch (Exception e) {
                Log.e("AccountFragment", "Error navigating to liked books: " + e.getMessage(), e);
                Toast.makeText(requireContext(), "Could not open liked books: " + e.getMessage(), 
                    Toast.LENGTH_SHORT).show();
            }
        });
        exploreButton.setOnClickListener(v -> {
            Navigation.findNavController(v).navigate(R.id.homeFragment);
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadLikedBooks();
    }

    private void loadLikedBooks() {
        List<Book> likedBooks = BookManager.getInstance().getLikedBooks();
        if (likedBooks.isEmpty()) {
            emptyStateLayout.setVisibility(View.VISIBLE);
            likedBooksCard.setVisibility(View.GONE);
            viewAllLikedButton.setVisibility(View.GONE);
        } else {
            emptyStateLayout.setVisibility(View.GONE);
            likedBooksCard.setVisibility(View.VISIBLE);
            viewAllLikedButton.setVisibility(View.VISIBLE);
            int previewCount = Math.min(likedBooks.size(), 5);
            List<Book> previewBooks = likedBooks.subList(0, previewCount);
            BookAdapter adapter = new BookAdapter(requireContext(), previewBooks);
            likedBooksRecyclerView.setAdapter(adapter);
        }
    }

    private void showEditProfileDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_profile, null);
        builder.setView(dialogView);
        EditText nameInput = dialogView.findViewById(R.id.edit_profile_name);
        EditText emailInput = dialogView.findViewById(R.id.edit_profile_email);
        nameInput.setText(account.getName());
        emailInput.setText(account.getEmail());
        builder.setTitle("Edit Profile")
                .setPositiveButton("Save", (dialog, which) -> {
                    String newName = nameInput.getText().toString().trim();
                    String newEmail = emailInput.getText().toString().trim();
                    AccountManager.getInstance().updateAccount(newName, newEmail);
                    account = AccountManager.getInstance().getCurrentAccount();
                    displayAccountInfo();
                })
                .setNegativeButton("Cancel", null);
        builder.create().show();
    }
}