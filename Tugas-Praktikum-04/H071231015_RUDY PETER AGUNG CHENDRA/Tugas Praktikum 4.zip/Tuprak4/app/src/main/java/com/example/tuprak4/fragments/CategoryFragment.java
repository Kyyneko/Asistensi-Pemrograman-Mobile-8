package com.example.tuprak4.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.adapters.CategoryBookAdapter;
import com.example.tuprak4.models.Book;
import com.example.tuprak4.utils.BookManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CategoryFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_category, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        String category = getArguments() != null ? getArguments().getString("CATEGORY") : null;
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view_category_books);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(requireContext(), 2);
        recyclerView.setLayoutManager(gridLayoutManager);
        List<Book> books = new ArrayList<>();
        if (category != null) {
            if (category.equals("Liked")) {
                books = BookManager.getInstance().getLikedBooks();
                Log.d("CategoryFragment", "Found " + books.size() + " liked books");
                for (Book book : books) {
                    Log.d("CategoryFragment", "Liked book: " + book.getTitle());
                }
            } else if (category.equals("Popular")) {
                books = BookManager.getInstance().getAllBooks();
                Collections.sort(books, 
                    (book1, book2) -> Integer.compare(book2.getRatingsCount(), book1.getRatingsCount()));
                Log.d("CategoryFragment", "Loaded " + books.size() + " popular books");
            } else if (category.equals("New Releases")) {
                books = BookManager.getInstance().getNewReleases(50);
                Log.d("CategoryFragment", "Loaded " + books.size() + " new releases");
            } else if (category.equals("Recommended")) {
                books = new ArrayList<>(BookManager.getInstance().getAllBooks());
                Collections.shuffle(books);
                Log.d("CategoryFragment", "Loaded " + books.size() + " recommended books");
            }
        }
        
        View emptyStateContainer = view.findViewById(R.id.empty_state_container);
        if (books.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            emptyStateContainer.setVisibility(View.VISIBLE);
            
            TextView emptyStateText = view.findViewById(R.id.text_empty_state);
            if (category != null && category.equals("Liked")) {
                emptyStateText.setText("You haven't liked any books yet");
            } else {
                emptyStateText.setText("No books found in this category");
            }
            
            Log.d("CategoryFragment", "Showing empty state for category: " + category);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            emptyStateContainer.setVisibility(View.GONE);
        }
        
        CategoryBookAdapter adapter = new CategoryBookAdapter(requireContext(), books);
        recyclerView.setAdapter(adapter);
        TextView titleTextView = view.findViewById(R.id.text_category_title);
        if (titleTextView != null) {
            titleTextView.setText(category != null ? category : "Books");
        }
        view.findViewById(R.id.button_explore_books).setOnClickListener(v -> {
            Navigation.findNavController(v).navigate(R.id.homeFragment);
        });
    }
}