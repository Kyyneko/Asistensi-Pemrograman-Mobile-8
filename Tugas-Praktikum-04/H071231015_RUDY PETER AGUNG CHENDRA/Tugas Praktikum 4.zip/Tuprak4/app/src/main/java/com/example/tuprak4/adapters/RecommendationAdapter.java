package com.example.tuprak4.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.activities.DetailActivity;
import com.example.tuprak4.models.Book;
import com.example.tuprak4.utils.ImageUtils;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;

public class RecommendationAdapter extends RecyclerView.Adapter<RecommendationAdapter.RecommendationViewHolder> {
    
    private final List<Book> books;
    private final Context context;

    public RecommendationAdapter(Context context, List<Book> books) {
        this.context = context;
        this.books = books;
    }

    @NonNull
    @Override
    public RecommendationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_recommendation, parent, false);
        return new RecommendationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecommendationViewHolder holder, int position) {
        Book book = books.get(position);
        
        holder.titleTextView.setText(book.getTitle());
        
        if (book.getImage() != null && !book.getImage().isEmpty()) {
            String imageUrl = ImageUtils.validateImageUrl(book.getImage());
            holder.bookImageView.setImageResource(R.drawable.placeholder_book);
            
            if (!imageUrl.isEmpty()) {
                Picasso.get()
                    .load(imageUrl)
                    .placeholder(R.drawable.placeholder_book)
                    .error(R.drawable.placeholder_book)
                    .fit()
                    .centerCrop()
                    .into(holder.bookImageView, new Callback() {
                        @Override
                        public void onSuccess() {
                            Log.d("ImageLoading", "Success loading: " + imageUrl);
                        }
                        
                        @Override
                        public void onError(Exception e) {
                            Log.e("ImageLoading", "Failed to load: " + imageUrl + " Error: " + e.getMessage());
                        }
                    });
            }
        } else {
            holder.bookImageView.setImageResource(R.drawable.placeholder_book);
        }
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("BOOK_TITLE", book.getTitle());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return books != null ? books.size() : 0;
    }

    static class RecommendationViewHolder extends RecyclerView.ViewHolder {
        ImageView bookImageView;
        TextView titleTextView;

        public RecommendationViewHolder(@NonNull View itemView) {
            super(itemView);
            bookImageView = itemView.findViewById(R.id.recommendation_image);
            titleTextView = itemView.findViewById(R.id.recommendation_title);
        }
    }
}