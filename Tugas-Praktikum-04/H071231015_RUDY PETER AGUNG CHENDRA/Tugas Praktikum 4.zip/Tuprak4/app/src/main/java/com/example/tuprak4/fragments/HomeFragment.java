package com.example.tuprak4.fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak4.R;
import com.example.tuprak4.adapters.BookAdapter;
import com.example.tuprak4.adapters.SearchResultAdapter;
import com.example.tuprak4.models.Book;
import com.example.tuprak4.utils.BookManager;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HomeFragment extends Fragment {

    private RecyclerView popularBooksRecyclerView;
    private RecyclerView newReleasesRecyclerView;
    private RecyclerView recommendedRecyclerView;
    private SearchView searchView;
    private ImageButton filterButton;
    private ChipGroup filterChips;
    private String currentQuery = "";
    private TextView searchResultsTitle;
    private View searchResultsSection;
    private RecyclerView searchResultsRecyclerView;
    private View mainContent;
    private static final String TAG = "HomeFragment";

    private String titleFilter = "";
    private String authorsFilter = "";
    private String publishedYearFilter = "";
    private String categoryFilter = "";
    private int minRatingsFilter = 0;
    private float minRatingFilter = 0.0f;
    private boolean likedOnlyFilter = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        popularBooksRecyclerView = view.findViewById(R.id.popular_books_recycler_view);
        newReleasesRecyclerView = view.findViewById(R.id.recycler_view_new_releases);
        recommendedRecyclerView = view.findViewById(R.id.recycler_view_recommended);
        searchResultsRecyclerView = view.findViewById(R.id.recycler_view_search_results);
        searchView = view.findViewById(R.id.search_view);
        filterButton = view.findViewById(R.id.btn_filter);
        filterChips = view.findViewById(R.id.filter_chips);
        searchResultsTitle = view.findViewById(R.id.search_results_title);
        searchResultsSection = view.findViewById(R.id.search_results_section);
        mainContent = view.findViewById(R.id.main_content);
        searchResultsSection.setVisibility(View.GONE);

        setupPopularBooks();
        setupNewReleases();
        setupRecommendedBooks();
        setupShowAllButtons(view);
        setupSearchView();
    }

    private void setupPopularBooks() {
        List<Book> allBooks = BookManager.getInstance().getAllBooks();
        List<Book> popularBooks = new ArrayList<>();
        for (Book book : allBooks) {
            if (book.getRatingsCount() > 0) {
                popularBooks.add(book);
            }
        }
        if (popularBooks.isEmpty() && !allBooks.isEmpty()) {
            popularBooks = new ArrayList<>(allBooks);
            Collections.shuffle(popularBooks);
        }
        if (!popularBooks.isEmpty()) {
            Collections.sort(popularBooks,
                    (book1, book2) -> Integer.compare(book2.getRatingsCount(), book1.getRatingsCount()));
        }
        int limit = Math.min(popularBooks.size(), 10);
        if (limit > 0) {
            popularBooks = popularBooks.subList(0, limit);
        }
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                requireContext(), LinearLayoutManager.HORIZONTAL, false);
                
        popularBooksRecyclerView.setLayoutManager(layoutManager);
        if (!popularBooks.isEmpty()) {
            BookAdapter popularAdapter = new BookAdapter(requireContext(), popularBooks);
            popularBooksRecyclerView.setAdapter(popularAdapter);
            popularBooksRecyclerView.setVisibility(View.VISIBLE);
            popularAdapter.notifyDataSetChanged();
        } else {
            popularBooksRecyclerView.setVisibility(View.GONE);
        }
    }

    private void setupNewReleases() {
        List<Book> newReleases = BookManager.getInstance().getNewReleases(10);
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                requireContext(), LinearLayoutManager.HORIZONTAL, false);
        newReleasesRecyclerView.setLayoutManager(layoutManager);
        BookAdapter newReleasesAdapter = new BookAdapter(requireContext(), newReleases);
        newReleasesRecyclerView.setAdapter(newReleasesAdapter);
        newReleasesRecyclerView.setVisibility(View.VISIBLE);
        newReleasesAdapter.notifyDataSetChanged();
    }

    private void setupRecommendedBooks() {
        List<Book> allBooks = BookManager.getInstance().getAllBooks();
        List<Book> recommendedBooks = new ArrayList<>(allBooks);
        
        Collections.shuffle(recommendedBooks);
        
        int limit = Math.min(recommendedBooks.size(), 10);
        if (limit > 0) {
            recommendedBooks = recommendedBooks.subList(0, limit);
        }
        
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                requireContext(), LinearLayoutManager.HORIZONTAL, false);
        recommendedRecyclerView.setLayoutManager(layoutManager);
        BookAdapter recommendedAdapter = new BookAdapter(requireContext(), recommendedBooks);
        recommendedRecyclerView.setAdapter(recommendedAdapter);
        recommendedRecyclerView.setVisibility(View.VISIBLE);
        recommendedAdapter.notifyDataSetChanged();
    }

    private void setupShowAllButtons(View view) {
        view.findViewById(R.id.button_show_all_popular).setOnClickListener(v -> {
            try {
                Bundle args = new Bundle();
                args.putString("CATEGORY", "Popular");
                Navigation.findNavController(v).navigate(R.id.categoryFragment, args);
            } catch (Exception e) {
                Log.e(TAG, "Error navigating to Popular category", e);
                Toast.makeText(requireContext(), "Unable to open category: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        
        view.findViewById(R.id.button_show_all_new_releases).setOnClickListener(v -> {
            try {
                Bundle args = new Bundle();
                args.putString("CATEGORY", "New Releases");
                Navigation.findNavController(v).navigate(R.id.categoryFragment, args);
            } catch (Exception e) {
                Log.e(TAG, "Error navigating to New Releases category", e);
                Toast.makeText(requireContext(), "Unable to open category: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        
        view.findViewById(R.id.button_show_all_recommended).setOnClickListener(v -> {
            try {
                Bundle args = new Bundle();
                args.putString("CATEGORY", "Recommended");
                Navigation.findNavController(v).navigate(R.id.categoryFragment, args);
            } catch (Exception e) {
                Log.e(TAG, "Error navigating to Recommended category", e);
                Toast.makeText(requireContext(), "Unable to open category: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupSearchView() {
        ImageView closeButton = searchView.findViewById(androidx.appcompat.R.id.search_close_btn);
        if (closeButton != null) {
            closeButton.setImageResource(R.drawable.ic_clear);
        }
        View searchPlate = searchView.findViewById(androidx.appcompat.R.id.search_plate);
        if (searchPlate != null) {
            searchPlate.setBackgroundResource(android.R.color.transparent);
        }
        EditText searchEditText = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
        if (searchEditText != null) {
            searchEditText.setCursorVisible(true);
            searchEditText.setTextColor(getResources().getColor(android.R.color.black));
            searchEditText.setHintTextColor(getResources().getColor(android.R.color.darker_gray));
        }
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                currentQuery = query;
                performSearch();
                searchView.clearFocus();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                currentQuery = newText;
                if (newText.isEmpty()) {
                    searchResultsSection.setVisibility(View.GONE);
                    mainContent.setVisibility(View.VISIBLE);
                } else {
                    performSearch();
                }
                return true;
            }
        });
        searchView.setOnClickListener(v -> {
            searchView.setIconified(false);
            searchView.requestFocus();
        });
        filterButton.setOnClickListener(v -> showFilterDialog());
    }

    private void performSearch() {
        Set<String> addedBookTitles = new HashSet<>();
        List<Book> searchResults = new ArrayList<>();
        for (Book book : BookManager.getInstance().getAllBooks()) {
            if (matchesFilters(book)) {
                String bookTitle = book.getTitle();
                if (!addedBookTitles.contains(bookTitle)) {
                    addedBookTitles.add(bookTitle);
                    searchResults.add(book);
                }
            }
        }
        searchResultsRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        searchResultsTitle.setText("Search Results: " + searchResults.size() + " books found");
        SearchResultAdapter adapter = new SearchResultAdapter(
                requireContext(),
                searchResults);
        searchResultsRecyclerView.setAdapter(adapter);
        searchResultsSection.setVisibility(View.VISIBLE);
        mainContent.setVisibility(View.GONE);
    }

    private void showFilterDialog() {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
            View dialogView = getLayoutInflater().inflate(R.layout.dialog_filter_books, null);
            builder.setView(dialogView);
            
            TextInputEditText titleInput = dialogView.findViewById(R.id.edit_title);
            TextInputEditText authorsInput = dialogView.findViewById(R.id.edit_authors);
            TextInputEditText publishedDateInput = dialogView.findViewById(R.id.edit_published_date);
            Spinner categoriesSpinner = dialogView.findViewById(R.id.spinner_categories);
            SeekBar ratingSeekBar = dialogView.findViewById(R.id.seekbar_rating);
            TextView ratingValueText = dialogView.findViewById(R.id.text_rating_value);
            RatingBar ratingIndicator = dialogView.findViewById(R.id.rating_indicator);
            SeekBar ratingsSeekBar = dialogView.findViewById(R.id.seekbar_ratings);
            TextView ratingsValueText = dialogView.findViewById(R.id.text_ratings_value);
            CheckBox likedCheckbox = dialogView.findViewById(R.id.checkbox_liked);
            Button clearButton = dialogView.findViewById(R.id.btn_clear);
            Button applyButton = dialogView.findViewById(R.id.btn_apply);
            
            titleInput.setText(titleFilter);
            authorsInput.setText(authorsFilter);
            publishedDateInput.setText(publishedYearFilter);
            ratingsSeekBar.setProgress(minRatingsFilter);
            ratingsValueText.setText(String.valueOf(minRatingsFilter));
            likedCheckbox.setChecked(likedOnlyFilter);
            
            ratingSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    float ratingValue = progress;
                    ratingValueText.setText(String.format("%.1f", ratingValue));
                    ratingIndicator.setRating(ratingValue);
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
            
            ratingsSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    ratingsValueText.setText(String.valueOf(progress));
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });

            Set<String> uniqueCategories = new HashSet<>();
            List<String> categoryOptions = new ArrayList<>();
            categoryOptions.add("All Categories");
            
            for (Book book : BookManager.getInstance().getAllBooks()) {
                String categories = book.getCategories();
                if (categories != null && !categories.isEmpty()) {
                    String[] categoryArray = categories.split(",");
                    for (String category : categoryArray) {
                        // Clean up the category format ['Fiction'] -> Fiction
                        String cleanCategory = category.trim().replace("['", "").replace("']", "");
                        if (!cleanCategory.isEmpty() && !uniqueCategories.contains(cleanCategory)) {
                            uniqueCategories.add(cleanCategory);
                            categoryOptions.add(cleanCategory);
                        }
                    }
                }
            }
            
            ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(
                    requireContext(), 
                    android.R.layout.simple_spinner_item,
                    categoryOptions);
            categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            categoriesSpinner.setAdapter(categoryAdapter);
            
            if (!categoryFilter.isEmpty()) {
                int position = categoryOptions.indexOf(categoryFilter);
                if (position >= 0) {
                    categoriesSpinner.setSelection(position);
                }
            }
            
            AlertDialog dialog = builder.create();
            
            clearButton.setOnClickListener(v -> {
                titleInput.setText("");
                authorsInput.setText("");
                publishedDateInput.setText("");
                categoriesSpinner.setSelection(0);
                ratingsSeekBar.setProgress(0);
                likedCheckbox.setChecked(false);
            });
            
            applyButton.setOnClickListener(v -> {
                titleFilter = titleInput.getText().toString().trim();
                authorsFilter = authorsInput.getText().toString().trim();
                publishedYearFilter = publishedDateInput.getText().toString().trim();
                
                int selectedCategoryPos = categoriesSpinner.getSelectedItemPosition();
                if (selectedCategoryPos > 0) {
                    String displayCategory = categoriesSpinner.getSelectedItem().toString();
                    categoryFilter = displayCategory;
                } else {
                    categoryFilter = "";
                }
                
                minRatingsFilter = ratingsSeekBar.getProgress();
                minRatingFilter = ratingSeekBar.getProgress();  
                likedOnlyFilter = likedCheckbox.isChecked();
                performSearch();
                updateFilterChips();
                dialog.dismiss();
            });
            
            dialog.show();
        } catch (Exception e) {
            Log.e(TAG, "Error showing filter dialog: " + e.getMessage(), e);
            Toast.makeText(requireContext(), "Could not show filter dialog", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateFilterChips() {
        filterChips.removeAllViews();
        if (titleFilter.isEmpty() && authorsFilter.isEmpty() && publishedYearFilter.isEmpty()
                && categoryFilter.isEmpty() && minRatingsFilter == 0 && minRatingFilter == 0.0f && !likedOnlyFilter) {
            filterChips.setVisibility(View.GONE);
            return;
        }
        filterChips.setVisibility(View.VISIBLE);
        Chip clearAllChip = new Chip(requireContext());
        clearAllChip.setText("Clear All");
        clearAllChip.setCloseIconVisible(true);
        clearAllChip.setOnCloseIconClickListener(v -> {
            clearAllFilters();
            updateFilterChips();
            performSearch();
        });
        filterChips.addView(clearAllChip);
        if (!titleFilter.isEmpty()) {
            addFilterChip("Title: " + titleFilter, () -> {
                titleFilter = "";
                updateFilterChips();
                performSearch();
            });
        }
        if (!authorsFilter.isEmpty()) {
            addFilterChip("Authors: " + authorsFilter, () -> {
                authorsFilter = "";
                updateFilterChips();
                performSearch();
            });
        }
        if (!publishedYearFilter.isEmpty()) {
            addFilterChip("Year: " + publishedYearFilter, () -> {
                publishedYearFilter = "";
                updateFilterChips();
                performSearch();
            });
        }
        if (!categoryFilter.isEmpty()) {
            addFilterChip("Category: " + categoryFilter, () -> {
                categoryFilter = "";
                updateFilterChips();
                performSearch();
            });
        }
        if (minRatingsFilter > 0) {
            addFilterChip("Min Ratings: " + minRatingsFilter, () -> {
                minRatingsFilter = 0;
                updateFilterChips();
                performSearch();
            });
        }
        if (minRatingFilter > 0) {
            addFilterChip("Min Rating: " + String.format("%.1f", minRatingFilter), () -> {
                minRatingFilter = 0.0f;
                updateFilterChips();
                performSearch();
            });
        }
        if (likedOnlyFilter) {
            addFilterChip("Liked Only", () -> {
                likedOnlyFilter = false;
                updateFilterChips();
                performSearch();
            });
        }
    }

    private void addFilterChip(String text, Runnable onCloseAction) {
        Chip chip = new Chip(requireContext());
        chip.setText(text);
        chip.setCloseIconVisible(true);
        chip.setOnCloseIconClickListener(v -> onCloseAction.run());
        filterChips.addView(chip);
    }

    private void clearAllFilters() {
        titleFilter = "";
        authorsFilter = "";
        publishedYearFilter = "";
        categoryFilter = "";
        minRatingsFilter = 0;
        minRatingFilter = 0.0f; 
        likedOnlyFilter = false;
    }

    private boolean matchesFilters(Book book) {
        if (!currentQuery.isEmpty()) {
            boolean matchesSearch = book.getTitle().toLowerCase().contains(currentQuery.toLowerCase());
            if (!matchesSearch && book.getAuthors() != null) {
                String authors = book.getAuthors();
                if (authors != null && !authors.isEmpty()) {
                    String[] authorArray = authors.split(",");
                    for (String author : authorArray) {
                        if (author.trim().toLowerCase().contains(currentQuery.toLowerCase())) {
                            matchesSearch = true;
                            break;
                        }
                    }
                }
            }
            if (!matchesSearch) {
                return false;
            }
        }
        if (!titleFilter.isEmpty() && !book.getTitle().toLowerCase().contains(titleFilter.toLowerCase())) {
            return false;
        }
        if (!authorsFilter.isEmpty() && book.getAuthors() != null) {
            String authors = book.getAuthors();
            boolean authorMatch = false;
            if (authors != null && !authors.isEmpty()) {
                String[] authorArray = authors.split(",");
                for (String author : authorArray) {
                    if (author.trim().toLowerCase().contains(authorsFilter.toLowerCase())) {
                        authorMatch = true;
                        break;
                    }
                }
            }
            if (!authorMatch) {
                return false;
            }
        }
        if (!publishedYearFilter.isEmpty() && book.getPublishedDate() != null) {
            if (!book.getPublishedDate().contains(publishedYearFilter)) {
                return false;
            }
        }
        if (!categoryFilter.isEmpty() && book.getCategories() != null) {
            String categories = book.getCategories();
            boolean categoryMatch = false;
            if (categories != null && !categories.isEmpty()) {
                String[] categoryArray = categories.split(",");
                for (String category : categoryArray) {
                    String cleanCategory = category.trim().replace("['", "").replace("']", "");
                    if (cleanCategory.equals(categoryFilter)) {
                        categoryMatch = true;
                        break;
                    }
                }
            }
            if (!categoryMatch) {
                return false;
            }
        }
        if (minRatingsFilter > 0 && book.getRatingsCount() < minRatingsFilter) {
            return false;
        }
        if (minRatingFilter > 0 && book.getRate() < minRatingFilter) {
            return false;
        }
        if (likedOnlyFilter && !book.isLiked()) {
            return false;
        }
        return true;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (currentQuery.isEmpty()) {
            setupPopularBooks();
            setupNewReleases();
            setupRecommendedBooks();
        } else {
            performSearch();
        }
    }
}