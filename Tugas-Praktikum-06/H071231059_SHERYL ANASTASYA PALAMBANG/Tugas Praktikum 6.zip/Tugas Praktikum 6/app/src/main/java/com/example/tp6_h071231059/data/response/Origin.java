package com.example.tp6_h071231059.data.response;

import com.google.gson.annotations.SerializedName;

public class Origin {
    @SerializedName("name")
    private String name;

    public String getName() {
        return name;
    }
}
