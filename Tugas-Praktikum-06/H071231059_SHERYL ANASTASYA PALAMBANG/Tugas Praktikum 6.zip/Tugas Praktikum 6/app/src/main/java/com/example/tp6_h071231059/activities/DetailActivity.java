package com.example.tp6_h071231059.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.example.tp6_h071231059.R;
import com.example.tp6_h071231059.data.network.ApiConfig;
import com.example.tp6_h071231059.data.network.ApiService;
import com.example.tp6_h071231059.data.response.CharacterResponse;
import com.example.tp6_h071231059.data.response.Character;
import com.example.tp6_h071231059.databinding.ActivityDetailBinding;


import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailActivity extends AppCompatActivity {

    private ActivityDetailBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        int characterId = getIntent().getIntExtra("CHARACTER_ID", -1);

        binding.progressBar.setVisibility(View.VISIBLE);
        binding.nestedScrollView.setVisibility(View.GONE);

        binding.ibBack.setOnClickListener(v -> {
            finish();
        });

        ApiService apiService = ApiConfig.getApiService();
        Call<Character> call = apiService.getCharacterById(characterId);
        call.enqueue(new Callback<Character>(){
            @Override
            public void onResponse(Call<Character> call, Response<Character> response) {
                binding.progressBar.setVisibility(View.GONE);
                binding.nestedScrollView.setVisibility(View.VISIBLE);

                if (response.isSuccessful() && response.body() != null) {
                    Character character = response.body();

                    binding.tvName.setText(character.getName());
                    binding.tvSpecies.setText(character.getSpecies());
                    binding.tvGender.setText(character.getGender());
                    binding.tvOrigin.setText(character.getOrigin().getName());
                    binding.tvLocation.setText(character.getLocation().getName());


                    binding.tvStatus.setText(character.getStatus());
                    if (character.getStatus().equals("Alive")) {
                        binding.ivProfileFrame.setImageResource(R.drawable.img_borderalive);
                    } else if (character.getStatus().equals("Dead")) {
                        binding.ivProfileFrame.setImageResource(R.drawable.img_borderdead);
                    } else {
                        binding.ivProfileFrame.setImageResource(R.drawable.img_border);
                    }

                    if (character.getType().isEmpty()) {
                        binding.tvType.setText("-");
                    } else {
                        binding.tvType.setText(character.getType());
                    }

                    if (!character.getImage().isEmpty()) {
                        Glide.with(DetailActivity.this)
                                .load(character.getImage())
                                .into(binding.ivProfile);
                    } else {
                        binding.ivProfile.setImageResource(R.drawable.ic_launcher_background);
                    }

                    String featuredEpisodes = "";
                    List<String> episodes = character.getEpisode();

                    if (!episodes.isEmpty()) {
                        String firstUrl = episodes.get(0);
                        String firstEpisode = firstUrl.substring(firstUrl.lastIndexOf("/") + 1);

                        if (episodes.size() == 1) {
                            featuredEpisodes = firstEpisode;
                        } else {
                            String lastUrl = episodes.get(episodes.size() - 1);
                            String lastEpisode = lastUrl.substring(lastUrl.lastIndexOf("/") + 1);
                            featuredEpisodes = firstEpisode + " - " + lastEpisode;
                        }
                    }
                    binding.tvEpisodes.setText(featuredEpisodes);

                }
            }
            @Override
            public void onFailure(Call<Character> call, Throwable t) {
                binding.progressBar.setVisibility(View.VISIBLE);
//                binding.tvFailedToLoad.setVisibility(View.VISIBLE);

                Toast.makeText(DetailActivity.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });

    }
}