package com.example.tp6_h071231059.data.network;

import com.example.tp6_h071231059.data.response.Character;
import com.example.tp6_h071231059.data.response.CharacterResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    @GET("character")
    Call<CharacterResponse> getCharacters(@Query("page") int page);

    @GET("character/{id}")
    Call<Character> getCharacterById(@Path("id") int id);
}
