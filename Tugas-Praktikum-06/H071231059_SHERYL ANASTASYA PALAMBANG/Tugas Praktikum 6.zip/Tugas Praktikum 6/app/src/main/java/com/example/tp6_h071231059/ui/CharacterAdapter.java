package com.example.tp6_h071231059.ui;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.tp6_h071231059.R;
import com.example.tp6_h071231059.activities.DetailActivity;
import com.example.tp6_h071231059.databinding.ItemCharacterBinding;
import com.example.tp6_h071231059.data.response.Character;


import java.util.List;

public class CharacterAdapter extends  RecyclerView.Adapter<CharacterAdapter.ViewHolder>{
    private final List<Character> charactersList;

    private Context context;

    public CharacterAdapter(Context context, List<Character> charactersList) {
        this.context = context;
        this.charactersList = charactersList;
    }

    @NonNull
    @Override
    public CharacterAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ItemCharacterBinding binding = ItemCharacterBinding.inflate(inflater, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CharacterAdapter.ViewHolder holder, int position) {
        Character character = charactersList.get(position);
        Glide.with(holder.itemView.getContext())
                .load(character.getImage())
                .into(holder.binding.ivProfile);
        holder.binding.tvName.setText(character.getName());
        holder.binding.tvSpecies.setText(character.getSpecies());

        if (character.getStatus().equals("Alive")) {
            holder.binding.ivStatus.setImageResource(R.drawable.ic_dotgreen);
        } else if (character.getStatus().equals("Dead")) {
            holder.binding.ivStatus.setImageResource(R.drawable.ic_dotred);
        } else {
            holder.binding.ivStatus.setVisibility(View.GONE);
        }

        if (character.getGender().equals("Male")) {
            holder.binding.ivGender.setImageResource(R.drawable.ic_male);
        } else if (character.getGender().equals("Female")) {
            holder.binding.ivGender.setImageResource(R.drawable.ic_female);
        } else {
            holder.binding.ivGender.setVisibility(View.GONE);
        }

        holder.binding.tvStatus.setText(character.getStatus());
        holder.binding.tvGender.setText(character.getGender());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("CHARACTER_ID", character.getId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return charactersList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ItemCharacterBinding binding;
        public ViewHolder(ItemCharacterBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
