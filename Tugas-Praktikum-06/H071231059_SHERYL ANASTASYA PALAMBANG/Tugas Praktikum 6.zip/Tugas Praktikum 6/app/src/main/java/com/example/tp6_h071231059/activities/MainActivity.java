package com.example.tp6_h071231059.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.tp6_h071231059.R;
import com.example.tp6_h071231059.data.network.ApiConfig;
import com.example.tp6_h071231059.data.response.CharacterResponse;
import com.example.tp6_h071231059.databinding.ActivityMainBinding;
import com.example.tp6_h071231059.ui.CharacterAdapter;
import com.example.tp6_h071231059.data.response.Character;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private CharacterAdapter adapter;
    private List<Character> characterList = new ArrayList<>();
    private int currentPage = 1;
    private int totalPages = Integer.MAX_VALUE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        adapter = new CharacterAdapter(this, characterList);
        binding.rvCharacter.setLayoutManager(new LinearLayoutManager(this));
        binding.rvCharacter.setAdapter(adapter);

        loadCharacters(currentPage);

        binding.btnLoadMore.setOnClickListener(v -> {
            if (currentPage < totalPages) {
                int nextPage = currentPage + 1;
                loadCharacters(nextPage);
            }
        });
    }

    private void loadCharacters(int page) {
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.btnLoadMore.setEnabled(false);
        binding.llFailedToLoad.setVisibility(View.GONE);

        Call<CharacterResponse> call = ApiConfig.getApiService().getCharacters(page);
        call.enqueue(new Callback<CharacterResponse>() {
            @Override
            public void onResponse(Call<CharacterResponse> call, Response<CharacterResponse> response) {
                binding.progressBar.setVisibility(View.GONE);
                binding.btnLoadMore.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    CharacterResponse characterResponse = response.body();

                    if (characterResponse.getInfo() != null) {
                        totalPages = characterResponse.getInfo().getPages();
                    }

                    characterList.addAll(characterResponse.getResults());
                    adapter.notifyDataSetChanged();

                    currentPage = page;

                    if (currentPage >= totalPages) {
                        binding.btnLoadMore.setVisibility(View.GONE);
                    } else {
                        binding.btnLoadMore.setVisibility(View.VISIBLE);
                    }

                }
            }
            @Override
            public void onFailure(Call<CharacterResponse> call, Throwable t) {
                binding.progressBar.setVisibility(View.VISIBLE);
                binding.btnLoadMore.setEnabled(true);

                Toast.makeText(MainActivity.this, "Failed to load data", Toast.LENGTH_SHORT).show();

            }
        });
    }
}