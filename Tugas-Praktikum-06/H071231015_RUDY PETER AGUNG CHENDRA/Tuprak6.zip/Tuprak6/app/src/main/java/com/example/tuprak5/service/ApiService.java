package com.example.tuprak5.service;

import android.os.Handler;
import android.os.Looper;

import com.example.tuprak5.model.Character;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ApiService {
    private static final String BASE_URL = "https://rickandmortyapi.com/api/character";
    private final OkHttpClient client = new OkHttpClient();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface ApiCallback {
        void onSuccess(List<Character> characters, int nextPage);
        void onError(String errorMessage);
    }

    public void getCharacters(int page, final ApiCallback callback) {
        String url = BASE_URL + "?page=" + page;
        
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Network error: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    mainHandler.post(() -> 
                        callback.onError("API error: " + response.code()));
                    return;
                }

                try {
                    String jsonData = response.body().string();
                    JSONObject jsonObject = new JSONObject(jsonData);
                    JSONObject info = jsonObject.getJSONObject("info");
                    
                    int nextPage = -1;
                    if (!info.isNull("next")) {
                        String nextUrl = info.getString("next");
                        if (nextUrl != null && !nextUrl.isEmpty()) {
                            String[] parts = nextUrl.split("page=");
                            if (parts.length > 1) {
                                nextPage = Integer.parseInt(parts[1]);
                            }
                        }
                    }
                    
                    final int finalNextPage = nextPage;
                    
                    JSONArray results = jsonObject.getJSONArray("results");
                    List<Character> characters = new ArrayList<>();
                    
                    for (int i = 0; i < results.length(); i++) {
                        JSONObject characterObj = results.getJSONObject(i);
                        int id = characterObj.getInt("id");
                        String name = characterObj.getString("name");
                        String status = characterObj.getString("status");
                        String species = characterObj.getString("species");
                        String image = characterObj.getString("image");
                        
                        Character character = new Character(id, name, status, species, image);
                        characters.add(character);
                    }
                    
                    mainHandler.post(() -> callback.onSuccess(characters, finalNextPage));
                    
                } catch (JSONException e) {
                    mainHandler.post(() -> 
                        callback.onError("JSON parsing error: " + e.getMessage()));
                }
            }
        });
    }

    public interface SingleCharacterCallback {
        void onSuccess(Character character);
        void onError(String errorMessage);
    }

    public void getCharacterById(int id, final SingleCharacterCallback callback) {
        String url = BASE_URL + "/" + id;
        
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Network error: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    mainHandler.post(() -> 
                        callback.onError("API error: " + response.code()));
                    return;
                }

                try {
                    String jsonData = response.body().string();
                    JSONObject characterObj = new JSONObject(jsonData);
                    
                    int characterId = characterObj.getInt("id");
                    String name = characterObj.getString("name");
                    String status = characterObj.getString("status");
                    String species = characterObj.getString("species");
                    String image = characterObj.getString("image");
                    
                    Character character = new Character(characterId, name, status, species, image);
                    
                    mainHandler.post(() -> callback.onSuccess(character));
                    
                } catch (JSONException e) {
                    mainHandler.post(() -> 
                        callback.onError("JSON parsing error: " + e.getMessage()));
                }
            }
        });
    }
}