package com.example.tuprak5;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.tuprak5.model.Character;
import com.example.tuprak5.service.ApiService;
import com.example.tuprak5.ui.CharacterAdapter;
import com.example.tuprak5.utils.NetworkUtils;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CharacterAdapter adapter;
    private ApiService apiService;
    private Button loadMoreButton;
    private ProgressBar progressBar;
    private TextView offlineMessageView;
    private SwipeRefreshLayout swipeRefreshLayout;

    private int currentPage = 1;
    private int nextPage = -1;

    private List<Character> characters = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        loadMoreButton = findViewById(R.id.load_more_button);
        progressBar = findViewById(R.id.progress_bar);
        offlineMessageView = findViewById(R.id.offline_message);
        swipeRefreshLayout = findViewById(R.id.swipe_refresh_layout);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CharacterAdapter(characters);
        recyclerView.setAdapter(adapter);

        apiService = new ApiService();

        loadMoreButton.setOnClickListener(v -> {
            if (nextPage > 0) {
                currentPage = nextPage;
                loadCharacters(currentPage);
            }
        });

        swipeRefreshLayout.setColorSchemeResources(
                android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light
        );

        swipeRefreshLayout.setOnRefreshListener(() -> {
            if (NetworkUtils.isNetworkAvailable(MainActivity.this)) {
                currentPage = 1;
                characters.clear();
                adapter.notifyDataSetChanged();
                loadCharacters(currentPage);
            } else {
                swipeRefreshLayout.setRefreshing(false);
                showOfflineMessage();
            }
        });

        checkNetworkAndLoadData();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkNetworkAndLoadData();
    }

    private void checkNetworkAndLoadData() {
        if (NetworkUtils.isNetworkAvailable(this)) {
            // Online mode
            offlineMessageView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);

            if (adapter.getItemCount() == 0) {
                loadCharacters(currentPage);
            }
        } else {
            progressBar.setVisibility(View.GONE);
            recyclerView.setVisibility(View.GONE);
            loadMoreButton.setVisibility(View.GONE);
            offlineMessageView.setVisibility(View.VISIBLE);
        }
    }

    private void loadCharacters(int page) {
        if (!swipeRefreshLayout.isRefreshing()) {
            progressBar.setVisibility(View.VISIBLE);
        }

        recyclerView.setVisibility(View.VISIBLE);
        offlineMessageView.setVisibility(View.GONE);

        apiService.getCharacters(page, new ApiService.ApiCallback() {
            @Override
            public void onSuccess(List<Character> newCharacters, int nextPageNum) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);

                // Add new characters to the list
                characters.addAll(newCharacters);
                adapter.notifyDataSetChanged();

                // Show or hide load more button based on if there's a next page
                loadMoreButton.setVisibility(nextPageNum > 0 ? View.VISIBLE : View.GONE);
                currentPage = page;
                nextPage = nextPageNum;
            }

            @Override
            public void onError(String errorMessage) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);

                // Show error message
                Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_SHORT).show();

                if (characters.isEmpty()) {
                    showOfflineMessage();
                }
            }
        });
    }

    private void showOfflineMessage() {
        recyclerView.setVisibility(View.GONE);
        loadMoreButton.setVisibility(View.GONE);
        offlineMessageView.setVisibility(View.VISIBLE);
    }
}