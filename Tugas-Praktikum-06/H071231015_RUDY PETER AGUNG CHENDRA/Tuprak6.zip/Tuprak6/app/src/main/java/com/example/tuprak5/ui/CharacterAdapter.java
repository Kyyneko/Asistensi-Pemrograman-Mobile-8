package com.example.tuprak5.ui;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuprak5.CharacterDetailActivity;
import com.example.tuprak5.R;
import com.example.tuprak5.model.Character;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CharacterAdapter extends RecyclerView.Adapter<CharacterAdapter.CharacterViewHolder> {

    private List<Character> characters;

    public CharacterAdapter(List<Character> characters) {
        this.characters = characters;
    }

    @NonNull
    @Override
    public CharacterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.character_item, parent, false);
        return new CharacterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CharacterViewHolder holder, int position) {
        Character character = characters.get(position);
        holder.nameTextView.setText(character.getName());
        holder.statusTextView.setText("Status: " + character.getStatus());
        holder.speciesTextView.setText("Species: " + character.getSpecies());
        
        Picasso.get()
                .load(character.getImage())
                .placeholder(R.drawable.ic_launcher_foreground)
                .error(R.drawable.ic_launcher_background)
                .into(holder.characterImageView);
                
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), CharacterDetailActivity.class);
            intent.putExtra("CHARACTER_ID", character.getId());
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return characters.size();
    }

    static class CharacterViewHolder extends RecyclerView.ViewHolder {
        ImageView characterImageView;
        TextView nameTextView, statusTextView, speciesTextView;

        public CharacterViewHolder(@NonNull View itemView) {
            super(itemView);
            characterImageView = itemView.findViewById(R.id.character_image);
            nameTextView = itemView.findViewById(R.id.character_name);
            statusTextView = itemView.findViewById(R.id.character_status);
            speciesTextView = itemView.findViewById(R.id.character_species);
        }
    }
}