package com.example.tuprak5;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.tuprak5.model.Character;
import com.example.tuprak5.service.ApiService;
import com.example.tuprak5.utils.NetworkUtils;
import com.squareup.picasso.Picasso;

public class CharacterDetailActivity extends AppCompatActivity {

    private ImageView characterImage;
    private TextView nameTextView, statusTextView, speciesTextView;
    private TextView offlineMessageView;
    private ProgressBar progressBar;
    private ScrollView scrollView;
    private SwipeRefreshLayout swipeRefreshLayout;

    private int characterId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_detail);

        characterImage = findViewById(R.id.detail_character_image);
        nameTextView = findViewById(R.id.detail_character_name);
        statusTextView = findViewById(R.id.detail_character_status);
        speciesTextView = findViewById(R.id.detail_character_species);
        offlineMessageView = findViewById(R.id.detail_offline_message);
        progressBar = findViewById(R.id.detail_progress_bar);
        scrollView = findViewById(R.id.scroll_view);
        swipeRefreshLayout = findViewById(R.id.detail_swipe_refresh);

        characterId = getIntent().getIntExtra("CHARACTER_ID", -1);

        // Set up swipe refresh layout
        swipeRefreshLayout.setColorSchemeResources(
                android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light
        );

        swipeRefreshLayout.setOnRefreshListener(() -> {
            if (NetworkUtils.isNetworkAvailable(this)) {
                // Refresh character data
                loadCharacterDetails(characterId);
            } else {
                // Stop refreshing animation
                swipeRefreshLayout.setRefreshing(false);

                // Show offline message
                scrollView.setVisibility(View.GONE);
                offlineMessageView.setVisibility(View.VISIBLE);

                Toast.makeText(this, "No internet connection available",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Load character details
        loadCharacterDetails(characterId);
    }

    private void loadCharacterDetails(int characterId) {
        ApiService apiService = new ApiService();

        // Show loading indicator if not refreshing
        if (!swipeRefreshLayout.isRefreshing()) {
            progressBar.setVisibility(View.VISIBLE);
        }

        apiService.getCharacterById(characterId, new ApiService.SingleCharacterCallback() {
            @Override
            public void onSuccess(Character character) {
                // Hide loading indicators
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);

                // Hide error UI if it was visible
                offlineMessageView.setVisibility(View.GONE);

                // Show content view
                scrollView.setVisibility(View.VISIBLE);

                // Update UI with character details
                nameTextView.setText(character.getName());
                statusTextView.setText("Status: " + character.getStatus());
                speciesTextView.setText("Species: " + character.getSpecies());

                Picasso.get()
                        .load(character.getImage())
                        .placeholder(R.drawable.ic_launcher_foreground)
                        .error(R.drawable.ic_launcher_background)
                        .into(characterImage);
            }

            @Override
            public void onError(String errorMessage) {
                // Hide loading indicators
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);

                // Hide content view
                scrollView.setVisibility(View.GONE);

                // Show error UI
                offlineMessageView.setVisibility(View.VISIBLE);

                // Log error
                Log.e("CharacterDetailActivity", "Error loading character: " + errorMessage);
            }
        });
    }
}